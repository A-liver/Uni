<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'cashier' && $_SESSION['role'] != 'finance') {
    exit("Access denied");
}

$message = '';
$messageType = '';

if (isset($_POST['report'])) {
    $from = mysqli_real_escape_string($conn, $_POST['from']);
    $to = mysqli_real_escape_string($conn, $_POST['to']);

    $res = mysqli_query($conn, "
        SELECT p.*, s.fname, s.lname, bm.billing_id
        FROM payments p
        LEFT JOIN students s ON s.student_id = p.student_id
        LEFT JOIN billing_master bm ON bm.billing_id = p.billing_id
        WHERE DATE(p.payment_date) BETWEEN '$from' AND '$to'
        ORDER BY p.payment_date DESC
    ");

    if (!$res) {
        $message = "Error generating report: " . mysqli_error($conn);
        $messageType = 'error';
    }
}

if (isset($_GET['export']) && $_GET['export'] == 'excel') {

    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=collection_report.xls");

    echo "Payment ID\tStudent ID\tName\tBilling ID\tAmount\tDate\n";

    $res = mysqli_query($conn, "
        SELECT p.*, s.fname, s.lname
        FROM payments p
        LEFT JOIN students s ON s.student_id = p.student_id
    ");

    while ($r = mysqli_fetch_assoc($res)) {
        echo $r['payment_id'] . "\t";
        echo $r['student_id'] . "\t";
        echo $r['lname'] . ', ' . $r['fname'] . "\t";
        echo $r['billing_id'] . "\t";
        echo $r['amount_paid'] . "\t";
        echo $r['payment_date'] . "\n";
    }

    exit();
}

// Get today's collections for quick stats
$todayQuery = mysqli_query($conn, "
    SELECT COUNT(*) as today_count, SUM(amount_paid) as today_total
    FROM payments 
    WHERE DATE(payment_date) = CURDATE()
");
$todayStats = mysqli_fetch_assoc($todayQuery);

// Get month's collections for quick stats
$monthQuery = mysqli_query($conn, "
    SELECT COUNT(*) as month_count, SUM(amount_paid) as month_total
    FROM payments 
    WHERE MONTH(payment_date) = MONTH(CURDATE()) 
    AND YEAR(payment_date) = YEAR(CURDATE())
");
$monthStats = mysqli_fetch_assoc($monthQuery);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-chart-line"></i> Cash Collection Report
            </h1>
            <p class="text-secondary">Generate and analyze payment collection reports</p>
        </div>
        <div class="flex gap-2">
            <a href="cashier_dashboard.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
            <a href="student_billing.php" class="btn btn-primary">
                <i class="fas fa-user-graduate"></i> Student Billing
            </a>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?> mb-6">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Quick Statistics -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value">₱<?= number_format($todayStats['today_total'] ?? 0, 2) ?></div>
            <div class="stat-label">
                <i class="fas fa-calendar-day"></i> Today's Collection
            </div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $todayStats['today_count'] ?? 0 ?></div>
            <div class="stat-label">
                <i class="fas fa-receipt"></i> Today's Transactions
            </div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value">₱<?= number_format($monthStats['month_total'] ?? 0, 2) ?></div>
            <div class="stat-label">
                <i class="fas fa-calendar-alt"></i> Monthly Collection
            </div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= $monthStats['month_count'] ?? 0 ?></div>
            <div class="stat-label">
                <i class="fas fa-chart-bar"></i> Monthly Transactions
            </div>
        </div>
    </div>

    <!-- Report Generator Form -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">📊 Generate Collection Report</h2>
            <p class="text-sm text-secondary">Select date range to generate payment collection report</p>
        </div>
        <div class="card-body">
            <form method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="form-label">From Date <span class="required">*</span></label>
                    <input type="date" name="from" class="form-input" required>
                </div>
                <div>
                    <label class="form-label">To Date <span class="required">*</span></label>
                    <input type="date" name="to" class="form-input" required>
                </div>
                <div class="flex items-end">
                    <button type="submit" name="report" class="btn btn-primary">
                        📊 Generate Report
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Report Results -->
    <?php if (isset($_POST['report']) && isset($res)): ?>
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">📋 Collection Report Results</h2>
                <p class="text-sm text-secondary">Payment collections from <?= htmlspecialchars($from) ?> to <?= htmlspecialchars($to) ?></p>
            </div>
            <div class="card-body">
                <?php if (mysqli_num_rows($res) > 0): ?>
                    <!-- Summary Statistics -->
                    <?php 
                    $total_collection = 0;
                    $payment_count = 0;
                    while ($r = mysqli_fetch_assoc($res)) {
                        $total_collection += $r['amount_paid'];
                        $payment_count++;
                    }
                    mysqli_data_seek($res, 0); // Reset pointer for table display
                    ?>

                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                        <div class="text-center p-4 bg-blue-50 rounded-lg">
                            <div class="text-2xl font-bold text-blue-600"><?= $payment_count ?></div>
                            <div class="text-sm text-blue-500">Total Payments</div>
                        </div>
                        <div class="text-center p-4 bg-green-50 rounded-lg">
                            <div class="text-2xl font-bold text-green-600">₱<?= number_format($total_collection, 2) ?></div>
                            <div class="text-sm text-green-500">Total Collection</div>
                        </div>
                        <div class="text-center p-4 bg-purple-50 rounded-lg">
                            <div class="text-2xl font-bold text-purple-600">₱<?= number_format($total_collection / $payment_count, 2) ?></div>
                            <div class="text-sm text-purple-500">Average Payment</div>
                        </div>
                        <div class="text-center p-4 bg-orange-50 rounded-lg">
                            <div class="text-2xl font-bold text-orange-600"><?= number_format(($total_collection / $monthStats['month_total']) * 100, 1) ?>%</div>
                            <div class="text-sm text-orange-500">Monthly Progress</div>
                        </div>
                    </div>

                    <!-- Payment Details Table -->
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Payment ID</th>
                                    <th>Student ID</th>
                                    <th>Student Name</th>
                                    <th>Billing ID</th>
                                    <th>Amount Paid</th>
                                    <th>Payment Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($r = mysqli_fetch_assoc($res)): ?>
                                    <tr>
                                        <td><span class="badge badge-primary"><?= $r['payment_id'] ?></span></td>
                                        <td><?= $r['student_id'] ?></td>
                                        <td>
                                            <div class="font-semibold"><?= htmlspecialchars($r['lname'] . ', ' . $r['fname']) ?></div>
                                        </td>
                                        <td><?= $r['billing_id'] ?></td>
                                        <td>
                                            <span class="badge badge-success">₱<?= number_format($r['amount_paid'], 2) ?></span>
                                        </td>
                                        <td><?= date('M d, Y h:i A', strtotime($r['payment_date'])) ?></td>
                                        <td>
                                            <div class="flex gap-2">
                                                <a href="receipt.php?id=<?= $r['payment_id'] ?>" target="_blank" class="btn btn-primary btn-sm">
                                                    🖨️ Print Receipt
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Export Options -->
                    <div class="mt-6 flex gap-4">
                        <button onclick="window.print()" class="btn btn-primary">
                            🖨️ Print Report
                        </button>
                        <a href="?export=excel" class="btn btn-outline">
                            📥 Export to Excel
                        </a>
                        <button onclick="window.print()" class="btn btn-outline">
                            📄 Export to PDF
                        </button>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        <strong>No payments found.</strong> There were no payment collections in the selected date range.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="student_billing.php" class="btn btn-primary">
                    💳 Process Payments
                </a>
                </button>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Collection Report Guidelines</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Report Features:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Generate reports for any date range</li>
                        <li>• View detailed payment information</li>
                        <li>• Calculate total collections and averages</li>
                        <li>• Export reports in multiple formats</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Financial Tracking:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Monitor daily and monthly collections</li>
                        <li>• Track payment trends and patterns</li>
                        <li>• Identify peak collection periods</li>
                        <li>• Generate reports for accounting purposes</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@media print {
    .card-header button, .flex.gap-4, .grid.grid-cols-2.md\\:grid-cols-4.gap-4 {
        display: none !important;
    }
    
    .card {
        break-inside: avoid;
        page-break-inside: avoid;
    }
    
    .table-responsive {
        overflow: visible !important;
    }
    
    body {
        background: white !important;
        padding: 20px !important;
    }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>