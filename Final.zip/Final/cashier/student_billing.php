<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cashier') {
    exit("Access denied");
}

$message = '';
$messageType = '';

// Handle student search
if (isset($_POST['search'])) {
    $key = mysqli_real_escape_string($conn, $_POST['student']);
    
    // Debug: Show what we're searching for
    $message = "Searching for: " . htmlspecialchars($key);
    $messageType = 'info';
    
    // Check if the search key is numeric (likely student_id)
    $isNumeric = is_numeric($key);
    
    // Build search query based on input type
    if ($isNumeric) {
        $studentQuery = mysqli_query($conn, "
            SELECT * FROM students
            WHERE student_id = $key
            LIMIT 1
        ");
    } else {
        $studentQuery = mysqli_query($conn, "
            SELECT * FROM students
            WHERE email = '$key'
               OR CONCAT(IFNULL(fname,''),' ',IFNULL(lname,'')) LIKE '%$key%'
               OR fname LIKE '%$key%'
               OR lname LIKE '%$key%'
            LIMIT 1
        ");
    }
    
    if (!$studentQuery) {
        $message = "Database error: " . mysqli_error($conn);
        $messageType = 'error';
    } else {
        $resultCount = mysqli_num_rows($studentQuery);
        $message .= " - Found $resultCount result(s)";
        
        $student = mysqli_fetch_assoc($studentQuery);
        
        if (!$student) {
            // Show sample students for reference
            $sampleQuery = mysqli_query($conn, "SELECT student_id, fname, lname, email FROM students LIMIT 3");
            $message .= "<br><br><strong>Sample students:</strong><br>";
            while ($sample = mysqli_fetch_assoc($sampleQuery)) {
                $message .= "ID: {$sample['student_id']}, Name: {$sample['fname']} {$sample['lname']}, Email: {$sample['email']}<br>";
            }
            $messageType = 'error';
        }
    }
}

// Handle billing load
if (isset($_POST['load_billing'])) {
    $sid = mysqli_real_escape_string($conn, $_POST['student_id']);
    $bid = mysqli_real_escape_string($conn, $_POST['billing_id']);
    
    $billingQuery = mysqli_query($conn, "
        SELECT * FROM billing_master WHERE billing_id='$bid' AND student_id='$sid'
    ");
    $billing = mysqli_fetch_assoc($billingQuery);
}

// Handle payment success redirect from student_details.php
if (isset($_GET['payment_success']) && isset($_GET['student_id']) && isset($_GET['amount'])) {
    $studentId = mysqli_real_escape_string($conn, $_GET['student_id']);
    $amount = mysqli_real_escape_string($conn, $_GET['amount']);
    
    echo "<div class='alert alert-success'>";
    echo "✅ Payment of ₱" . number_format($amount, 2) . " processed successfully!";
    echo "<br><a href='student_billing.php?student_id=" . urlencode($studentId) . "' class='btn btn-primary'>View Billing Details</a>";
    echo "</div>";
}

// Handle billing ID redirect from student_details.php
if (isset($_GET['student_id']) && isset($_GET['billing_id']) && !isset($_GET['payment_success'])) {
    $studentId = mysqli_real_escape_string($conn, $_GET['student_id']);
    $billingId = mysqli_real_escape_string($conn, $_GET['billing_id']);
    
    $studentQuery = mysqli_query($conn, "SELECT * FROM students WHERE student_id = '$studentId'");
    $student = mysqli_fetch_assoc($studentQuery);
    
    $billingQuery = mysqli_query($conn, "SELECT * FROM billing_master WHERE billing_id = '$billingId' AND student_id = '$studentId'");
    $billing = mysqli_fetch_assoc($billingQuery);
    
    $sy = $billing['sy'] ?? '';
    $sem = $billing['sem'] ?? '';
    
    echo "<div class='alert alert-info'>";
    echo "👤 Student: " . htmlspecialchars($student['fname'] . ' ' . $student['lname']) . " (ID: $studentId)";
    echo "<br>📋 Billing: " . htmlspecialchars($billing['sy']) . " Semester " . htmlspecialchars($billing['sem']);
    echo "</div>";
}

// Handle payment processing
if (isset($_POST['process_payment'])) {
    $bid = mysqli_real_escape_string($conn, $_POST['billing_id']);
    $sid = mysqli_real_escape_string($conn, $_POST['student_id']);
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    
    // Validate amount
    if (!is_numeric($amount) || $amount <= 0) {
        $message = "Invalid payment amount.";
        $messageType = 'error';
    } else {
        // Insert payment
        $insert = mysqli_query($conn, "
            INSERT INTO payments (billing_id, student_id, amount_paid, payment_date)
            VALUES ('$bid', '$sid', '$amount', NOW())
        ");
        
        if ($insert) {
            $paymentId = mysqli_insert_id($conn);
            $message = "Payment processed successfully!";
            $messageType = 'success';
            
            // Update billing status
            $paidQuery = mysqli_query($conn, "
                SELECT SUM(amount_paid) as total_paid FROM payments WHERE billing_id='$bid'
            ");
            $paid = mysqli_fetch_assoc($paidQuery)['total_paid'] ?? 0;
            
            $billingQuery = mysqli_query($conn, "SELECT total_amount FROM billing_master WHERE billing_id='$bid'");
            $total = mysqli_fetch_assoc($billingQuery)['total_amount'];
            
            $status = ($paid >= $total) ? 'paid' : 'partial';
            mysqli_query($conn, "UPDATE billing_master SET status='$status' WHERE billing_id='$bid'");
        } else {
            $message = "Payment processing failed: " . mysqli_error($conn);
            $messageType = 'error';
        }
    }
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-user-graduate"></i> Student Billing
            </h1>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?> mb-6">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Student Information (when loaded from redirect) -->
    <?php if (isset($student) && $student): ?>
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-user"></i> Student Information
                </h2>
                <p class="text-sm text-secondary">Current student details and billing period</p>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="bg-blue-50 p-3 rounded-lg border border-blue-200">
                        <span class="text-secondary text-sm text-blue-600">Student ID</span>
                        <div class="font-semibold text-blue-800"><?= $student['student_id'] ?></div>
                    </div>
                    <div class="bg-green-50 p-3 rounded-lg border border-green-200">
                        <span class="text-secondary text-sm text-green-600">Full Name</span>
                        <div class="font-semibold text-green-800"><?= htmlspecialchars($student['lname'] . ', ' . $student['fname']) ?></div>
                    </div>
                    <div class="bg-purple-50 p-3 rounded-lg border border-purple-200">
                        <span class="text-secondary text-sm text-purple-600">Course</span>
                        <div class="font-semibold text-purple-800"><?= htmlspecialchars($student['course']) ?></div>
                    </div>
                    <div class="bg-orange-50 p-3 rounded-lg border border-orange-200">
                        <span class="text-secondary text-sm text-orange-600">Period</span>
                        <div class="font-semibold text-orange-800"><?= htmlspecialchars($sy ?? 'N/A') ?> - Semester <?= htmlspecialchars($sem ?? 'N/A') ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Billing Period Selection -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-calendar-alt"></i> Select Billing Period
                </h2>
                <p class="text-sm text-secondary">Choose the billing period to view details</p>
            </div>
            <div class="card-body">
                <?php
                // Debug: Check if billing records exist
                $billingList = mysqli_query($conn, "
                    SELECT billing_id, sy, sem, status, total_amount
                    FROM billing_master
                    WHERE student_id='{$student['student_id']}'
                    ORDER BY sy DESC, sem DESC
                ");
                
                $billingCount = mysqli_num_rows($billingList);
                
                if ($billingList === false) {
                    echo "<div class='alert alert-error'>Billing query error: " . mysqli_error($conn) . "</div>";
                } else {
                    echo "<div class='alert alert-info'>Found $billingCount billing record(s) for student ID: {$student['student_id']}</div>";
                }
                
                if ($billingCount > 0):
                ?>
                    <form method="POST">
                        <input type="hidden" name="student_id" value="<?= $student['student_id'] ?>">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>School Year</th>
                                        <th>Semester</th>
                                        <th>Total Amount</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($b = mysqli_fetch_assoc($billingList)): ?>
                                        <tr>
                                            <td><?= $b['sy'] ?></td>
                                            <td><?= $b['sem'] ?></td>
                                            <td>₱<?= number_format($b['total_amount'], 2) ?></td>
                                            <td>
                                                <span class="badge badge-<?= $b['status'] == 'paid' ? 'success' : ($b['status'] == 'partial' ? 'warning' : 'danger') ?>">
                                                    <?= ucfirst($b['status']) ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="alert alert-info">
                        <strong>No billing records found.</strong> This student has no billing periods available.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Billing Details (when billing is loaded) -->
    <?php if (isset($billing) && $billing): ?>
        <?php
        $sid = $billing['student_id'];
        $bid = $billing['billing_id'];
        $sy = $billing['sy'];
        $sem = $billing['sem'];
        
        // Get enrolled subjects
        $subjects = mysqli_query($conn, "
            SELECT subject_code, units
            FROM student_subjects
            WHERE student_id='$sid' AND sy='$sy' AND sem='$sem'
        ");
        
        $totalUnits = 0;
        while ($s = mysqli_fetch_assoc($subjects)) {
            $totalUnits += $s['units'];
        }
        mysqli_data_seek($subjects, 0);
        
        // Get billing details - try different approaches
        $details = mysqli_query($conn, "
            SELECT * FROM billing_details WHERE billing_id='$bid'
        ");
        
        // If no billing_details, try to get from fee_schedules directly
        if (mysqli_num_rows($details) == 0) {
            $details = mysqli_query($conn, "
                SELECT * FROM fee_schedules
            ");
        }
        
        // Calculate total and paid amounts
        $totalAmount = $billing['total_amount'];
        $paidQuery = mysqli_query($conn, "
            SELECT SUM(amount_paid) as total_paid FROM payments WHERE billing_id='$bid'
        ");
        $paidAmount = mysqli_fetch_assoc($paidQuery)['total_paid'] ?? 0;
        $balance = $totalAmount - $paidAmount;
        ?>
        
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">🧾 Billing Details - <?= $sy ?> Semester <?= $sem ?></h2>
            </div>
            <div class="card-body">
                <!-- Summary -->
                <div class="grid grid-cols-4 gap-4 mb-6">
                    <div class="text-center p-4 bg-blue-50 rounded">
                        <div class="text-2xl font-bold text-blue-600">₱<?= number_format($totalAmount, 2) ?></div>
                        <div class="text-sm text-blue-500">Total Amount</div>
                    </div>
                    <div class="text-center p-4 bg-green-50 rounded">
                        <div class="text-2xl font-bold text-green-600">₱<?= number_format($paidAmount, 2) ?></div>
                        <div class="text-sm text-green-500">Amount Paid</div>
                    </div>
                    <div class="text-center p-4 bg-red-50 rounded">
                        <div class="text-2xl font-bold text-red-600">₱<?= number_format($balance, 2) ?></div>
                        <div class="text-sm text-red-500">Balance</div>
                    </div>
                    <div class="text-center p-4 bg-purple-50 rounded">
                        <div class="text-2xl font-bold text-purple-600"><?= $totalUnits ?></div>
                        <div class="text-sm text-purple-500">Total Units</div>
                    </div>
                </div>

                <!-- Enrolled Subjects -->
                <div class="mb-6">
                    <h4 class="font-semibold mb-3">📚 Enrolled Subjects</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Subject Code</th>
                                    <th>Units</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($s = mysqli_fetch_assoc($subjects)): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($s['subject_code']) ?></td>
                                        <td><span class="badge badge-info"><?= $s['units'] ?></span></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Fee Breakdown -->
                <div class="mb-6">
                    <h4 class="font-semibold mb-3">💰 Fee Breakdown</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Fee Name</th>
                                    <th>Category</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $detailsCount = 0;
                                while ($d = mysqli_fetch_assoc($details)): 
                                    $detailsCount++;
                                ?>
                                    <tr>
                                        <td><?= htmlspecialchars($d['fee_name'] ?? $d['description'] ?? 'Fee ' . $detailsCount) ?></td>
                                        <td><span class="badge badge-secondary"><?= htmlspecialchars($d['category'] ?? 'General') ?></span></td>
                                        <td>₱<?= number_format($d['amount'] ?? $d['fee_amount'] ?? 0, 2) ?></td>
                                    </tr>
                                <?php endwhile; ?>
                                
                                    <tr>
                                        <td>Tuition Fee</td>
                                        <td><span class="badge badge-primary">Academic</span></td>
                                        <td>₱<?= number_format($totalUnits * 300, 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td>Registration Fee</td>
                                        <td><span class="badge badge-secondary">Administrative</span></td>
                                        <td>₱500.00</td>
                                    </tr>
                                    <tr>
                                        <td>Library Fee</td>
                                        <td><span class="badge badge-info">Facility</span></td>
                                        <td>₱200.00</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Payment Form -->
                <?php if (isset($balance) && $balance > 0): ?>
                    <form method="POST">
                        <input type="hidden" name="billing_id" value="<?= $bid ?>">
                        <input type="hidden" name="student_id" value="<?= $sid ?>">
                        
                        <label class="form-label">Payment Amount (₱)</label>
                        <?php if ($paidAmount > 0): ?>
                            <input type="number" name="amount" class="form-input" step="0.01" min="0.01" required>
                            <small class="text-secondary">Enter any amount to continue payment</small>
                        <?php else: ?>
                            <input type="number" name="amount" class="form-input" step="0.01" min="0.01" required>
                            <small class="text-secondary">Minimum payment: ₱0.01</small>
                        <?php endif; ?>
                        
                        <button type="submit" name="process_payment" class="btn btn-success">
                            💰 Process Payment
                        </button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-success">
                        <strong>✅ Fully Paid!</strong> This billing has been completely paid.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <!-- Recent Payments (for current student) -->
    <?php if (isset($student) && $student): ?>
        <?php
        $recentPayments = mysqli_query($conn, "
            SELECT DISTINCT * FROM payments 
            WHERE student_id='{$student['student_id']}' 
            ORDER BY payment_date DESC 
            LIMIT 5
        ");
        ?>
        <?php if (mysqli_num_rows($recentPayments) > 0): ?>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">📋 Recent Payments</h2>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Receipt</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($payment = mysqli_fetch_assoc($recentPayments)): ?>
                                    <tr>
                                        <td><?= date('M d, Y h:i A', strtotime($payment['payment_date'])) ?></td>
                                        <td>₱<?= number_format($payment['amount_paid'], 2) ?></td>
                                        <td>
                                            <a href="receipt.php?id=<?= $payment['payment_id'] ?>" class="btn btn-outline btn-sm" target="_blank">
                                                🧾 View
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
