<?php

require_once __DIR__ . '/../includes/header.php';



/* 🔒 SECURITY */

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {

    header("Location: ../auth/login.php");

    exit();

}



/* ✅ USE REAL STUDENT ID */

if (!isset($_SESSION['student_id'])) {

    die("Session error: student_id not found. Please login again.");

}



$student_id = $_SESSION['student_id'];



/* =========================

   GET STUDENT INFO

========================= */

$result = mysqli_query($conn, "

    SELECT * FROM students WHERE student_id='$student_id'

");



if (!$result) {

    die("Query error: " . mysqli_error($conn));

}



$student = mysqli_fetch_assoc($result);



if (!$student) {

    die("Student record not found.");

}



/* =========================

   OPTIONAL: USER INFO

========================= */

$username = $_SESSION['username'];



$result2 = mysqli_query($conn, "

    SELECT * FROM users WHERE username='$username'

");



$user = mysqli_fetch_assoc($result2);

?>



<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-user"></i> Student Dashboard
            </h1>
            <p class="text-secondary">Welcome back, <?= htmlspecialchars($student['fname']) ?>!</p>
        </div>
        <div class="flex gap-2">
            <a href="../auth/logout.php" class="btn btn-outline">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <!-- Student Information Card -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-user-circle"></i> Student Information
            </h2>
            <p class="text-sm text-secondary">Your academic details and current status</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="bg-blue-50 p-3 rounded-lg border border-blue-200">
                    <span class="text-secondary text-sm text-blue-600">Student ID</span>
                    <div class="font-semibold text-blue-800"><?= $student_id ?></div>
                </div>
                <div class="bg-green-50 p-3 rounded-lg border border-green-200">
                    <span class="text-secondary text-sm text-green-600">Full Name</span>
                    <div class="font-semibold text-green-800"><?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?></div>
                </div>
                <div class="bg-purple-50 p-3 rounded-lg border border-purple-200">
                    <span class="text-secondary text-sm text-purple-600">Course</span>
                    <div class="font-semibold text-purple-800"><?= htmlspecialchars($student['course']) ?></div>
                </div>
                <div class="bg-orange-50 p-3 rounded-lg border border-orange-200">
                    <span class="text-secondary text-sm text-orange-600">Period</span>
                    <div class="font-semibold text-orange-800"><?= htmlspecialchars($student['sy']) ?> | SEM <?= htmlspecialchars($student['sem']) ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-th-large"></i> Quick Actions
            </h2>
            <p class="text-sm text-secondary">Access your student services and tools</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <a href="student_subjects.php" class="btn btn-primary">
                    <i class="fas fa-book"></i> View Subjects
                </a>
                <a href="add_subjects.php" class="btn btn-success">
                    <i class="fas fa-plus"></i> Add Subject
                </a>
                <a href="grade.php" class="btn btn-secondary">
                    <i class="fas fa-chart-line"></i> My Grades
                </a>
                <a href="student.php" class="btn btn-outline">
                    <i class="fas fa-user-cog"></i> View Account
                </a>
                <a href="billing.php" class="btn btn-warning">
                    <i class="fas fa-file-invoice"></i> Billing
                </a>
                <a href="exam_permit.php" class="btn btn-info">
                    <i class="fas fa-certificate"></i> Exam Permit
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>