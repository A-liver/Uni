<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] !== 'student') {
    exit("Access denied");
}

$student_id = $_SESSION['student_id'];

$cn = $_GET['id'] ?? null;
if (!$cn) {
    header("Location: add_subjects.php?error=no_subject");
    exit;
}

/* =========================
   GET STUDENT INFO FIRST
========================= */
$studentQuery = mysqli_query($conn, "
    SELECT sy, sem, course, fname, lname
    FROM students
    WHERE student_id='$student_id'
    LIMIT 1
");

if (!$studentQuery) {
    die("Student query failed: " . mysqli_error($conn));
}

$student = mysqli_fetch_assoc($studentQuery);

$sy = $student['sy'];
$sem = $student['sem'];
$course = $student['course'];

/* =========================
   GET SUBJECT
========================= */
$subjectQuery = mysqli_query($conn, "
    SELECT * 
    FROM subjectssem120182019 
    WHERE CN='$cn'
");

if (!$subjectQuery) {
    die("Subject query failed: " . mysqli_error($conn));
}

$subject = mysqli_fetch_assoc($subjectQuery);

if (!$subject) {
    header("Location: add_subjects.php?error=subject_not_found");
    exit;
}

$subject_code = $subject['SUBJECT'];
$description  = $subject['DESC'];
$units        = (int)$subject['UNIT'];
$room         = $subject['ROOM'];
$instructor   = $subject['INSTRUCTOR'];
$term         = $subject['TERM'];

/* =========================
   CHECK DUPLICATE
========================= */
$check = mysqli_query($conn, "
    SELECT id FROM student_subjects 
    WHERE student_id='$student_id'
    AND subject_code='$subject_code'
    AND sy='$sy'
    AND sem='$sem'
");

if (mysqli_num_rows($check) > 0) {
    header("Location: add_subjects.php?error=already_enrolled&subject=" . urlencode($subject_code));
    exit;
}

/* =========================
   INSERT SUBJECT
========================= */
$insert = mysqli_query($conn, "
INSERT INTO student_subjects (
    student_id, cn, course,
    subject_code, description,
    units, room, instructor,
    term, sem, sy
) VALUES (
    '$student_id',
    '$cn',
    '$course',
    '$subject_code',
    '$description',
    '$units',
    '$room',
    '$instructor',
    '$term',
    '$sem',
    '$sy'
)
");

if (!$insert) {
    header("Location: add_subjects.php?error=insert_failed&subject=" . urlencode($subject_code));
    exit;
}

/* =========================
   UPDATE BILLING AFTER INSERT
========================= */

/* 1. GET TOTAL UNITS */
$unitQ = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT SUM(units) AS total_units
    FROM student_subjects
    WHERE student_id='$student_id'
    AND sy='$sy'
    AND sem='$sem'
"));

$total_units = $unitQ['total_units'] ?? 0;

/* 2. RATE */
$rate_per_3_units = 300;

/* 3. TUITION */
$tuition = ($total_units / 3) * $rate_per_3_units;

/* 4. GET BILLING MASTER */
$bm = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT billing_id 
    FROM billing_master
    WHERE student_id='$student_id'
    AND sy='$sy'
    AND sem='$sem'
    LIMIT 1
"));

if ($bm) {
    $billing_id = $bm['billing_id'];

    /* 5. UPDATE BILLING */
    mysqli_query($conn, "
        UPDATE billing_master
        SET total_units='$total_units',
            total_amount='$tuition'
        WHERE billing_id='$billing_id'
    ");
}

/* =========================
   SUCCESS PAGE
========================= */
?>

<div class="fade-in">
    <div class="max-w-2xl mx-auto mt-8">
        <div class="card">
            <div class="card-body text-center py-12">
                <div class="text-6xl mb-4">✅</div>
                <h1 class="text-3xl font-bold text-green-600 mb-4">Subject Enrolled Successfully!</h1>
                
                <div class="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
                    <h2 class="text-xl font-semibold mb-4">Enrollment Details</h2>
                    <div class="grid grid-cols-2 gap-4 text-left">
                        <div>
                            <span class="text-secondary text-sm">Subject Code:</span>
                            <div class="font-semibold"><?= htmlspecialchars($subject_code) ?></div>
                        </div>
                        <div>
                            <span class="text-secondary text-sm">Description:</span>
                            <div class="font-semibold"><?= htmlspecialchars($description) ?></div>
                        </div>
                        <div>
                            <span class="text-secondary text-sm">Units:</span>
                            <div class="font-semibold"><?= $units ?></div>
                        </div>
                        <div>
                            <span class="text-secondary text-sm">Instructor:</span>
                            <div class="font-semibold"><?= htmlspecialchars($instructor) ?></div>
                        </div>
                        <div>
                            <span class="text-secondary text-sm">Room:</span>
                            <div class="font-semibold"><?= htmlspecialchars($room) ?></div>
                        </div>
                        <div>
                            <span class="text-secondary text-sm">Term:</span>
                            <div class="font-semibold"><?= htmlspecialchars($term) ?></div>
                        </div>
                    </div>
                </div>

                <div class="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
                    <h3 class="text-lg font-semibold mb-2">Updated Information</h3>
                    <p class="text-secondary">
                        Your total units for this semester: <strong><?= $total_units ?></strong><br>
                        Updated tuition fee: <strong>₱<?= number_format($tuition, 2) ?></strong>
                    </p>
                </div>

                <div class="flex gap-4 justify-center">
                    <a href="student_subjects.php" class="btn btn-primary">
                        📚 View My Subjects
                    </a>
                    <a href="add_subjects.php" class="btn btn-secondary">
                        ➕ Add Another Subject
                    </a>
                    <a href="student_dashboard.php" class="btn btn-outline">
                        🏠 Back to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Auto-redirect after 5 seconds
setTimeout(function() {
    window.location.href = 'student_subjects.php';
}, 5000);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>