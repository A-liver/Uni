<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

$message = '';
$messageType = '';

/* ADD */
if (isset($_POST['add'])) {
    $course = mysqli_real_escape_string($conn, $_POST['course']);
    $desc = mysqli_real_escape_string($conn, $_POST['desc']);
    $major = mysqli_real_escape_string($conn, $_POST['major']);

    // Check if courses table exists
    $tableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'courses'");
    if (mysqli_num_rows($tableCheck) == 0) {
        $message = "Error: The 'courses' table does not exist in the database.";
        $messageType = 'error';
    } else {
        $sy = isset($_POST['sy']) ? mysqli_real_escape_string($conn, $_POST['sy']) : '';
        $sem = isset($_POST['sem']) ? mysqli_real_escape_string($conn, $_POST['sem']) : '';

        $result = mysqli_query($conn, "
            INSERT INTO courses (COURSE, `DESC`, MAJOR, SY, SEM)
            VALUES ('$course', '$desc', '$major', '$sy', '$sem')
        ");

        if ($result) {
            $message = "Course '$course' added successfully!";
            $messageType = 'success';
        } else {
            $message = "Error adding course: " . mysqli_error($conn);
            $messageType = 'error';
        }
    }
}

/* DELETE */
if (isset($_GET['del'])) {
    $id = intval($_GET['del']);
    $course = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COURSE FROM courses WHERE id = $id"));

    $result = mysqli_query($conn, "DELETE FROM courses WHERE id = $id");

    if ($result) {
        if ($course) {
            $message = "Course '{$course['COURSE']}' deleted successfully!";
        } else {
            $message = "Course deleted successfully!";
        }
        $messageType = 'warning';
    } else {
        $message = "Error deleting course: " . mysqli_error($conn);
        $messageType = 'error';
    }
}

$data = mysqli_query($conn, "SELECT * FROM courses ORDER BY COURSE ASC");
$totalCourses = mysqli_num_rows($data);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>📚 Course Management</h1>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?> mb-6">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Statistics -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= $totalCourses ?></div>
            <div class="stat-label">Total Courses</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= mysqli_num_rows(mysqli_query($conn, "SELECT COUNT(*) as count FROM courses WHERE MAJOR != ''")) ?></div>
            <div class="stat-label">With Majors</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= mysqli_num_rows(mysqli_query($conn, "SELECT COUNT(*) as count FROM courses WHERE MAJOR = ''")) ?></div>
            <div class="stat-label">Without Majors</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value">Active</div>
            <div class="stat-label">System Status</div>
        </div>
    </div>

 <!-- Add New Course -->
<div class="card mb-6">
    <div class="card-header">
        <h2 class="card-title">➕ Add New Course</h2>
    </div>

    <div class="card-body">

        <form method="POST" class="grid grid-cols-6 gap-4">

            <div>
                <label class="form-label">
                    Course Code <span class="required">*</span>
                </label>

                <input
                    type="text"
                    name="course"
                    class="form-input"
                    placeholder="e.g., BSIT"
                    required
                    minlength="2"
                    maxlength="50"
                >
            </div>

            <div>
                <label class="form-label">
                    Description <span class="required">*</span>
                </label>

                <input
                    type="text"
                    name="desc"
                    class="form-input"
                    placeholder="e.g., Bachelor of Science in Information Technology"
                    required
                    minlength="5"
                    maxlength="255"
                >
            </div>

            <div>
                <label class="form-label">
                    Major (Optional)
                </label>

                <input
                    type="text"
                    name="major"
                    class="form-input"
                    placeholder="e.g., Web Development"
                    maxlength="100"
                >
            </div>

            <div>
                <label class="form-label">
                    School Year
                </label>

                <input
                    type="text"
                    name="sy"
                    class="form-input"
                    placeholder="e.g., 2025-2026"
                    maxlength="20"
                >
            </div>

            <div>
                <label class="form-label">
                    Semester
                </label>

                <select name="sem" class="form-input">
                    <option value="">Select Semester</option>
                    <option value="1st Semester">1st Semester</option>
                    <option value="2nd Semester">2nd Semester</option>
                    <option value="Summer">Summer</option>
                </select>
            </div>

            <div class="flex items-end">
                <button type="submit" name="add" class="btn btn-primary">
                    ➕ Add Course
                </button>
            </div>

        </form>

    </div>
</div>

    <!-- Courses List -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 Existing Courses</h2>
            <p class="text-sm text-secondary">Manage all academic courses offered by the university</p>
        </div>
        <div class="card-body">
            <?php if ($totalCourses > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Course Code</th>
                                <th>Description</th>
                                <th>Major</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($c = mysqli_fetch_assoc($data)) { ?>
                                <tr>
                                    <td>
                                        <span class="badge badge-primary">
                                            <?= htmlspecialchars($c['COURSE']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($c['DESC']) ?></div>
                                    </td>
                                    <td>
                                        <?php if ($c['MAJOR']): ?>
                                            <span class="badge badge-success">
                                                <?= htmlspecialchars($c['MAJOR']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">No Major</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-success">✓ Active</span>
                                    </td>
                                    <td>
                                        <div class="flex gap-2">
                                            <button onclick="editCourse(<?= $c['id'] ?>)" class="btn btn-outline btn-sm">
                                                ✏️ Edit
                                            </button>
                                            <a href="?del=<?= $c['id'] ?>" 
                                               onclick="return confirm('Are you sure you want to delete this course? This action cannot be undone.')" 
                                               class="btn btn-danger btn-sm">
                                                🗑️ Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No courses found.</strong> Start by adding your first course using the form above.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-3 gap-4">
                <a href="subjects.php" class="btn btn-primary">
                    📖 Manage Subjects
                </a>
                <a href="enrollment.php" class="btn btn-secondary">
                    👥 Student Enrollment
                </a>
                <a href="dean_dashboard.php" class="btn btn-outline">
                    ← Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Course Management Guidelines</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Adding Courses:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Use standard course codes (e.g., BSIT, BSCS, BSED)</li>
                        <li>• Provide clear, descriptive course names</li>
                        <li>• Major is optional for specialized programs</li>
                        <li>• Ensure course codes are unique</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Important Notes:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Deleting a course will remove all associated data</li>
                        <li>• Courses are used in student enrollment</li>
                        <li>• Regular review of course offerings recommended</li>
                        <li>• Coordinate with department heads for updates</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function editCourse(courseId) {
    // This would open an edit modal or redirect to edit page
    alert('Edit functionality would be implemented here for course ID: ' + courseId);
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>