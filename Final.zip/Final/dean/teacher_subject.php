<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

$message = '';
$messageType = '';

/* TEACHERS */
$teachers = mysqli_query($conn,"
    SELECT username 
    FROM users 
    WHERE role='teacher'
");

if (!$teachers) {
    die("Teacher query error: " . mysqli_error($conn));
}

/* CLASSES */
$classes = mysqli_query($conn,"
    SELECT DISTINCT cn, subject_code, sy, sem
    FROM student_subjects
    ORDER BY sy DESC
");

if (!$classes) {
    die("Class query error: " . mysqli_error($conn));
}

/* ASSIGN TEACHER */
if (isset($_POST['assign'])) {
    $cn = mysqli_real_escape_string($conn, $_POST['cn']);
    $teacher = mysqli_real_escape_string($conn, $_POST['teacher']);

    $update = mysqli_query($conn,"
        UPDATE student_subjects
        SET instructor='$teacher'
        WHERE cn='$cn'
    ");

    if ($update) {
        $message = "Teacher assigned successfully!";
        $messageType = 'success';
    } else {
        $message = "Error assigning teacher: " . mysqli_error($conn);
        $messageType = 'error';
    }
}

/* GET STATISTICS */
$statsQuery = mysqli_query($conn, "
    SELECT 
        COUNT(*) as total_classes,
        COUNT(DISTINCT instructor) as assigned_classes,
        COUNT(CASE WHEN instructor IS NULL OR instructor = '' THEN 1 END) as unassigned_classes
    FROM student_subjects
");
$stats = mysqli_fetch_assoc($statsQuery);

/* GET CURRENT ASSIGNMENTS */
$assignments = mysqli_query($conn, "
    SELECT DISTINCT cn, subject_code, sy, sem, instructor
    FROM student_subjects
    WHERE instructor IS NOT NULL AND instructor != ''
    ORDER BY sy DESC, sem DESC, subject_code ASC
");
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>👨‍🏫 Teacher Assignment Management</h1>
            <p class="text-secondary">Assign teachers to classes and manage teaching assignments</p>
        </div>
        <a href="dean_dashboard.php" class="btn btn-outline">
            ← Back to Dashboard
        </a>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?> mb-6">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= $stats['total_classes'] ?? 0 ?></div>
            <div class="stat-label">Total Classes</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $stats['assigned_classes'] ?? 0 ?></div>
            <div class="stat-label">Assigned Classes</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= $stats['unassigned_classes'] ?? 0 ?></div>
            <div class="stat-label">Unassigned Classes</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= mysqli_num_rows($teachers) ?></div>
            <div class="stat-label">Available Teachers</div>
        </div>
    </div>

    <!-- Assign Teacher Form -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">➕ Assign Teacher to Class</h2>
            <p class="text-sm text-secondary">Assign a teacher to a specific class</p>
        </div>
        <div class="card-body">
            <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="form-label">Select Class <span class="required">*</span></label>
                    <select name="cn" class="form-input" required>
                        <option value="">-- Select Class --</option>
                        <?php 
                        mysqli_data_seek($classes, 0); // Reset pointer
                        while($c=mysqli_fetch_assoc($classes)){ 
                        ?>
                            <option value="<?= $c['cn'] ?>">
                                <?= htmlspecialchars($c['subject_code']) ?> | SY <?= htmlspecialchars($c['sy']) ?> - <?= htmlspecialchars($c['sem']) ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div>
                    <label class="form-label">Select Teacher <span class="required">*</span></label>
                    <select name="teacher" class="form-input" required>
                        <option value="">-- Select Teacher --</option>
                        <?php 
                        mysqli_data_seek($teachers, 0); // Reset pointer
                        while($t=mysqli_fetch_assoc($teachers)){ 
                        ?>
                            <option value="<?= htmlspecialchars($t['username']) ?>">
                                <?= htmlspecialchars($t['username']) ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="md:col-span-2">
                    <button type="submit" name="assign" class="btn btn-primary">
                        👨‍🏫 Assign Teacher
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Current Assignments -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 Current Teacher Assignments</h2>
            <p class="text-sm text-secondary">View all current teacher assignments</p>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($assignments) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Class #</th>
                                <th>Subject Code</th>
                                <th>School Year</th>
                                <th>Semester</th>
                                <th>Assigned Teacher</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($a=mysqli_fetch_assoc($assignments)){ ?>
                                <tr>
                                    <td><span class="badge badge-primary"><?= $a['cn'] ?></span></td>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($a['subject_code']) ?></div>
                                    </td>
                                    <td><?= htmlspecialchars($a['sy']) ?></td>
                                    <td><?= htmlspecialchars($a['sem']) ?></td>
                                    <td>
                                        <span class="badge badge-success"><?= htmlspecialchars($a['instructor']) ?></span>
                                    </td>
                                    <td>
                                        <div class="flex gap-2">
                                            <button class="btn btn-outline btn-sm">
                                                ✏️ Reassign
                                            </button>
                                            <button class="btn btn-danger btn-sm">
                                                🗑️ Remove
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No teacher assignments found.</strong> Start by assigning teachers to classes using the form above.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="assign_teacher.php" class="btn btn-primary">
                    👨‍🏫 Assign Teachers
                </a>
                <a href="subjects.php" class="btn btn-secondary">
                    📖 Manage Subjects
                </a>
                <a href="schedule.php" class="btn btn-outline">
                    📅 View Schedule
                </a>
                <a href="dean_dashboard.php" class="btn btn-outline">
                    ← Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Teacher Assignment Guidelines</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Assignment Process:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Verify teacher qualifications for subject area</li>
                        <li>• Check teacher availability and schedule</li>
                        <li>• Consider teaching load balance across faculty</li>
                        <li>• Document assignment changes and reasons</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Important Notes:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• All classes must have assigned instructors</li>
                        <li>• Teachers can handle multiple classes</li>
                        <li>• Coordinate with department heads for assignments</li>
                        <li>• Review assignments before each semester</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>