<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

$data = mysqli_query($conn, "SELECT * FROM students ORDER BY lname ASC");

/* GET STATISTICS */
$statsQuery = mysqli_query($conn, "
    SELECT
        COUNT(*) as total_students,
        COUNT(DISTINCT course) as unique_courses,
        COUNT(DISTINCT sy) as academic_years,
        COUNT(DISTINCT sem) as semesters
    FROM students
");
$stats = mysqli_fetch_assoc($statsQuery);

/* GET PENDING APPLICATIONS */
$pendingApps = mysqli_query($conn, "SELECT * FROM applications WHERE status='pending' OR status IS NULL ORDER BY created_at DESC");
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-users"></i> Student Management
            </h1>
            <p class="text-secondary">View and manage all registered students and applications</p>
        </div>
        <div class="flex gap-2">
            <a href="dean_dashboard.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Dashboard
            </a>
        </div>
    </div>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?> mb-6">
            <i class="fas fa-info-circle"></i> <?php
            echo htmlspecialchars($_SESSION['message']);
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
            ?>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?php echo $stats['total_students'] ?? 0; ?></div>
            <div class="stat-label">
                <i class="fas fa-user-graduate"></i> Total Students
            </div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?php echo $stats['unique_courses'] ?? 0; ?></div>
            <div class="stat-label">
                <i class="fas fa-book"></i> Unique Courses
            </div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?php echo $stats['academic_years'] ?? 0; ?></div>
            <div class="stat-label">
                <i class="fas fa-calendar"></i> Academic Years
            </div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?php echo mysqli_num_rows($pendingApps); ?></div>
            <div class="stat-label">
                <i class="fas fa-clock"></i> Pending Applications
            </div>
        </div>
    </div>

    <!-- Pending Applications Section -->
    <?php if (mysqli_num_rows($pendingApps) > 0): ?>
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-user-clock"></i> Pending Student Applications
            </h2>
            <p class="text-sm text-secondary">Review and approve new student enrollment applications</p>
        </div>
        <div class="card-body">
            <?php while ($app = mysqli_fetch_assoc($pendingApps)): ?>
                <div class="user-item">
                    <div class="user-info">
                        <div class="user-name"><?php echo htmlspecialchars($app['fname'] . ' ' . $app['lname']); ?></div>
                        <div class="user-role">
                            Course: <span class="badge badge-primary"><?php echo htmlspecialchars($app['course']); ?></span>
                            <?php if ($app['major']): ?>
                                • Major: <span class="badge badge-secondary"><?php echo htmlspecialchars($app['major']); ?></span>
                            <?php endif; ?>
                            <?php if (isset($app['created_at'])): ?>
                                • Applied: <?php echo date('M j, Y', strtotime($app['created_at'])); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="user-actions">
                        <a href="approve_student.php?id=<?php echo $app['app_id']; ?>" class="btn btn-success btn-sm">
                            <i class="fas fa-check-circle"></i> Approve
                        </a>
                        <a href="reject_student.php?id=<?php echo $app['app_id']; ?>" class="btn btn-danger btn-sm">
                            <i class="fas fa-times-circle"></i> Reject
                        </a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Students List -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-list"></i> All Students
            </h2>
            <p class="text-sm text-secondary">Complete list of registered students</p>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($data) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Full Name</th>
                                <th>Course</th>
                                <th>Major</th>
                                <th>School Year</th>
                                <th>Semester</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($s = mysqli_fetch_assoc($data)) { ?>
                                <tr>
                                    <td>
                                        <span class="badge badge-primary"><?php echo $s['student_id']; ?></span>
                                    </td>
                                    <td>
                                        <div class="font-semibold"><?php echo htmlspecialchars($s['lname'] . ', ' . $s['fname']); ?></div>
                                        <?php if ($s['mname']): ?>
                                            <div class="text-sm text-secondary"><?php echo htmlspecialchars($s['mname']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-secondary"><?php echo htmlspecialchars($s['course']); ?></span>
                                    </td>
                                    <td><?php echo htmlspecialchars($s['major'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($s['sy']); ?></td>
                                    <td><?php echo htmlspecialchars($s['sem']); ?></td>
                                    <td>
                                        <div class="flex gap-2">
                                            <button class="btn btn-outline btn-sm">
                                                📊 View Records
                                            </button>
                                            <button class="btn btn-primary btn-sm">
                                                📝 Edit Info
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No students found.</strong> There are currently no registered students in the system.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="enrollment.php" class="btn btn-primary">
                    👥 Student Enrollment
                </a>
                <a href="courses.php" class="btn btn-secondary">
                    📚 Manage Courses
                </a>
                <a href="subjects.php" class="btn btn-outline">
                    📖 Manage Subjects
                </a>
                <a href="dean_dashboard.php" class="btn btn-outline">
                    ← Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Student Management Guidelines</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Student Information:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• All students must have complete profile information</li>
                        <li>• Course and major assignments should be accurate</li>
                        <li>• Academic year and semester tracking is essential</li>
                        <li>• Regular updates to student records recommended</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Academic Oversight:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Monitor student enrollment patterns</li>
                        <li>• Track academic progress and performance</li>
                        <li>• Ensure compliance with academic policies</li>
                        <li>• Coordinate with department heads for issues</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>