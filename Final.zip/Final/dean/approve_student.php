<?php
require_once __DIR__ . '/../config/db_connection.php';

$db = new Database();
$conn = $db->getConnection();

session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'dean') {
    header("Location: ../auth/login.php");
    exit();
}

$application_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($application_id <= 0) {
    $_SESSION['message'] = 'Invalid application ID';
    $_SESSION['message_type'] = 'error';
    header("Location: students.php");
    exit();
}

// Get application details
$appQuery = mysqli_query($conn, "SELECT * FROM applications WHERE app_id = $application_id");
$application = mysqli_fetch_assoc($appQuery);

if (!$application) {
    $_SESSION['message'] = 'Application not found';
    $_SESSION['message_type'] = 'error';
    header("Location: students.php");
    exit();
}

// Insert into students table
$stmt = $conn->prepare("
    INSERT INTO students (
        app_id, sy, sem, course, major,
        fname, mname, lname,
        bdate, gender,
        phone, email,
        region, city, barangay,
        image_path
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

/* 16 VALUES → 16 TYPES */
$stmt->bind_param(
    "isssssssssssssss",
    $application_id,
    $application['sy'],
    $application['sem'],
    $application['course'],
    $application['major'],
    $application['fname'],
    $application['mname'],
    $application['lname'],
    $application['bdate'],
    $application['gender'],
    $application['phone'],
    $application['email'],
    $application['region'],
    $application['city'],
    $application['barangay'],
    $application['image_path']
);

if ($stmt->execute()) {
    $new_student_id = $conn->insert_id;

    // Create user account for the student
    $user_password = md5($application['email']); // Default password: email hash
    $user_stmt = $conn->prepare("
        INSERT INTO users (username, password, role, status, student_id)
        VALUES (?, ?, 'student', 'pending', ?)
    ");
    $user_stmt->bind_param("ssi", $application['email'], $user_password, $new_student_id);

    if ($user_stmt->execute()) {
        // safer update (prepared statement)
        $upd = $conn->prepare("UPDATE applications SET status='approved' WHERE app_id=?");
        $upd->bind_param("i", $application_id);
        $upd->execute();
        $upd->close();

        $_SESSION['message'] = "Student {$application['fname']} {$application['lname']} approved successfully. User account created with pending status. Admin must approve the user account.";
        $_SESSION['message_type'] = 'success';
    } else {
        $_SESSION['message'] = 'Student added but user creation failed: ' . $user_stmt->error;
        $_SESSION['message_type'] = 'warning';
    }

    $user_stmt->close();

} else {
    $_SESSION['message'] = 'Error approving application: ' . $stmt->error;
    $_SESSION['message_type'] = 'error';
}

$stmt->close();

header("Location: students.php");
exit();
?>