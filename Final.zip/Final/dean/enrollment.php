<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

$message = '';
$messageType = '';

/* ENROLL */
if (isset($_POST['enroll'])) {
    $student_id = mysqli_real_escape_string($conn, $_POST['student_id']);
    $cn = mysqli_real_escape_string($conn, $_POST['cn']);
    $course = mysqli_real_escape_string($conn, $_POST['course']);
    $code = mysqli_real_escape_string($conn, $_POST['code']);
    $desc = mysqli_real_escape_string($conn, $_POST['desc']);
    $units = mysqli_real_escape_string($conn, $_POST['units']);
    $instructor = mysqli_real_escape_string($conn, $_POST['instructor']);
    $sem = mysqli_real_escape_string($conn, $_POST['sem']);
    $sy = mysqli_real_escape_string($conn, $_POST['sy']);

    $result = mysqli_query($conn, "
        INSERT INTO student_subjects
        (student_id, cn, course, subject_code, description, units, instructor, sem, sy)
        VALUES (
            '$student_id',
            '$cn',
            '$course',
            '$code',
            '$desc',
            '$units',
            '$instructor',
            '$sem',
            '$sy'
        )
    ");

    if ($result) {
        $message = "Student enrolled successfully!";
        $messageType = 'success';
    } else {
        $message = "Error enrolling student: " . mysqli_error($conn);
        $messageType = 'error';
    }
}

/* LIST */
$data = mysqli_query($conn, "
    SELECT ss.*, s.lname, s.fname
    FROM student_subjects ss
    JOIN students s ON s.student_id = ss.student_id
    ORDER BY s.lname ASC
");

/* GET STATISTICS */
$statsQuery = mysqli_query($conn, "
    SELECT 
        COUNT(*) as total_enrollments,
        COUNT(DISTINCT student_id) as unique_students,
        COUNT(DISTINCT subject_code) as unique_subjects,
        COUNT(DISTINCT sy) as academic_years
    FROM student_subjects
");
$stats = mysqli_fetch_assoc($statsQuery);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>📚 Student Enrollment Management</h1>
            <p class="text-secondary">Manage student enrollments and academic records</p>
        </div>
        <a href="dean_dashboard.php" class="btn btn-outline">
            ← Back to Dashboard
        </a>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?> mb-6">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= $stats['total_enrollments'] ?? 0 ?></div>
            <div class="stat-label">Total Enrollments</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $stats['unique_students'] ?? 0 ?></div>
            <div class="stat-label">Unique Students</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= $stats['unique_subjects'] ?? 0 ?></div>
            <div class="stat-label">Unique Subjects</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= $stats['academic_years'] ?? 0 ?></div>
            <div class="stat-label">Academic Years</div>
        </div>
    </div>

    <!-- Enrollment Form -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">➕ Quick Enrollment</h2>
            <p class="text-sm text-secondary">Enroll a student in a subject</p>
        </div>
        <div class="card-body">
            <form method="POST" class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                    <label class="form-label">Student ID</label>
                    <input type="text" name="student_id" class="form-input" placeholder="Enter student ID" required>
                </div>
                <div>
                    <label class="form-label">Class Number</label>
                    <input type="text" name="cn" class="form-input" placeholder="Enter class number" required>
                </div>
                <div>
                    <label class="form-label">Course</label>
                    <input type="text" name="course" class="form-input" placeholder="Enter course" required>
                </div>
                <div>
                    <label class="form-label">Subject Code</label>
                    <input type="text" name="code" class="form-input" placeholder="Enter subject code" required>
                </div>
                <div>
                    <label class="form-label">Description</label>
                    <input type="text" name="desc" class="form-input" placeholder="Enter description" required>
                </div>
                <div>
                    <label class="form-label">Units</label>
                    <input type="number" name="units" class="form-input" placeholder="Enter units" required>
                </div>
                <div>
                    <label class="form-label">Instructor</label>
                    <input type="text" name="instructor" class="form-input" placeholder="Enter instructor name" required>
                </div>
                <div>
                    <label class="form-label">Semester</label>
                    <select name="sem" class="form-input" required>
                        <option value="">Select Semester</option>
                        <option value="1st">1st Semester</option>
                        <option value="2nd">2nd Semester</option>
                        <option value="Summer">Summer</option>
                    </select>
                </div>
                <div>
                    <label class="form-label">School Year</label>
                    <input type="text" name="sy" class="form-input" placeholder="e.g., 2023-2024" required>
                </div>
                <div class="md:col-span-3">
                    <button type="submit" name="enroll" class="btn btn-primary">
                        ➕ Enroll Student
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Enrollment List -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 All Enrollments</h2>
            <p class="text-sm text-secondary">Complete list of student enrollments</p>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($data) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Subject Code</th>
                                <th>Description</th>
                                <th>School Year</th>
                                <th>Semester</th>
                                <th>Instructor</th>
                                <th>Units</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($r = mysqli_fetch_assoc($data)) { ?>
                                <tr>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($r['lname'] . ', ' . $r['fname']) ?></div>
                                        <div class="text-sm text-secondary">ID: <?= $r['student_id'] ?></div>
                                    </td>
                                    <td>
                                        <span class="badge badge-primary"><?= htmlspecialchars($r['subject_code']) ?></span>
                                    </td>
                                    <td><?= htmlspecialchars($r['description']) ?></td>
                                    <td><?= htmlspecialchars($r['sy']) ?></td>
                                    <td>
                                        <span class="badge badge-secondary"><?= htmlspecialchars($r['sem']) ?></span>
                                    </td>
                                    <td><?= htmlspecialchars($r['instructor']) ?></td>
                                    <td><?= $r['units'] ?></td>
                                    <td>
                                        <div class="flex gap-2">
                                            <button class="btn btn-outline btn-sm">
                                                📊 View Grades
                                            </button>
                                            <button class="btn btn-danger btn-sm">
                                                🗑️ Remove
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No enrollments found.</strong> There are currently no student enrollments in the system.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="courses.php" class="btn btn-primary">
                    📚 Manage Courses
                </a>
                <a href="subjects.php" class="btn btn-secondary">
                    📖 Manage Subjects
                </a>
                <a href="students.php" class="btn btn-outline">
                    👥 View Students
                </a>
                <a href="assign_teacher.php" class="btn btn-outline">
                    👨‍🏫 Assign Teachers
                </a>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Enrollment Guidelines</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Enrollment Process:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Verify student eligibility before enrollment</li>
                        <li>• Check subject prerequisites and availability</li>
                        <li>• Ensure class capacity limits are not exceeded</li>
                        <li>• Update student billing after enrollment changes</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Academic Policies:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Maximum units per semester: 24 units</li>
                        <li>• Minimum units for full-time status: 12 units</li>
                        <li>• Add/drop period: First 2 weeks of classes</li>
                        <li>• Late enrollment requires dean's approval</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>