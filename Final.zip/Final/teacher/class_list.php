<?php
require_once __DIR__ . '/../includes/header.php';

// Check role
if ($_SESSION['role'] != 'teacher') exit("Access denied");



$cn  = mysqli_real_escape_string($conn, $_GET['cn']);
$sy  = mysqli_real_escape_string($conn, $_GET['sy']);
$sem = mysqli_real_escape_string($conn, $_GET['sem']);
$sub = mysqli_real_escape_string($conn, $_GET['sub']);

// 3. Use INNER JOIN to get fname from the students table
$students = mysqli_query($conn, "
    SELECT ss.*, s.fname, s.lname
    FROM student_subjects ss
    INNER JOIN students s ON ss.student_id = s.student_id
    WHERE ss.cn = '$cn'
    AND ss.sy = '$sy'
    AND ss.sem = '$sem'
    AND ss.subject_code = '$sub'
    ORDER BY s.student_id ASC
");
?>

<h2>Class List</h2>

<a href="encode_grades.php?cn=<?= $cn ?>&sy=<?= $sy ?>&sem=<?= $sem ?>&sub=<?= $sub ?>">Encode Grades</a>
|
<a href="print_grades.php?cn=<?= $cn ?>&sy=<?= $sy ?>&sem=<?= $sem ?>&sub=<?= $sub ?>">Print Grades</a>

<form method="POST" action="save_grades.php">

<table border="1">
<tr>
    <th>Student ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>CN</th>
    <th>Prelim</th>
    <th>Midterm</th>
    <th>Final</th>
    <th>General Average</th>
    <th>Remarks</th>
</tr>

<?php while($s = mysqli_fetch_assoc($students)) { ?>
<tr>
    <td><?= $s['student_id'] ?></td>
    <td><?= $s['fname'] ?></td>
    <td><?= $s['lname'] ?></td>
    <td><?= $s['cn'] ?></td>
    <td><?= $s['g1'] ?></td>
    <td><?= $s['g2'] ?></td>
    <td><?= $s['g3'] ?></td>
    <td><?= $s['final'] ?></td>
    <td><?= $s['remarks'] ?></td>



</tr>
<?php } ?>

</table>


</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>