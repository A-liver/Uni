<?php
require_once __DIR__ . '/init.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-dark: #1e40af;
            --secondary-color: #64748b;
            --success-color: #10b981;
            --danger-color: #ef4444;
            --warning-color: #f59e0b;
            --info-color: #0ea5e9;
            --dark-color: #1f2937;
            --light-color: #f8fafc;
            --border-color: #e2e8f0;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --radius: 0.5rem;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: var(--dark-color);
            line-height: 1.6;
        }

        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow-md);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logo i {
            -webkit-text-fill-color: var(--primary-color);
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--light-color);
            border-radius: var(--radius);
            border: 1px solid var(--border-color);
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: -280px;
            width: 280px;
            height: 100vh;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            transition: var(--transition);
            z-index: 1001;
            box-shadow: var(--shadow-lg);
            overflow-y: auto;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar-header {
            padding: 2rem 1.5rem;
            border-bottom: 1px solid var(--border-color);
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
        }

        .sidebar-content {
            padding: 1.5rem;
        }

        .sidebar-section {
            margin-bottom: 2rem;
        }

        .sidebar-section-title {
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--secondary-color);
            margin-bottom: 0.75rem;
            letter-spacing: 0.05em;
        }

        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            color: var(--dark-color);
            padding: 0.75rem 1rem;
            text-decoration: none;
            border-radius: var(--radius);
            margin-bottom: 0.25rem;
            transition: var(--transition);
            font-weight: 500;
        }

        .sidebar-link:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(4px);
        }

        .sidebar-link.active {
            background: var(--primary-color);
            color: white;
        }

        .mobile-menu-toggle {
            background: none;
            border: none;
            color: var(--dark-color);
            font-size: 1.25rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: var(--radius);
            transition: var(--transition);
        }

        .mobile-menu-toggle:hover {
            background: var(--light-color);
        }

        .main-content {
            margin-left: 0;
            padding: 2rem;
            transition: var(--transition);
            max-width: 1400px;
            margin: 0 auto;
        }

        .main-content.sidebar-active {
            margin-left: 280px;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--border-color);
            transition: var(--transition);
        }

        .card:hover {
            box-shadow: var(--shadow-lg);
            transform: translateY(-2px);
        }

        .card-header {
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 1rem;
            margin-bottom: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-title {
            margin: 0;
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: 0;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1.5rem;
            background: white;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }

        .table th, .table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .table th {
            background: var(--light-color);
            font-weight: 600;
            color: var(--dark-color);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .table tr:hover {
            background: var(--light-color);
        }

        .form-input {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 2px solid var(--border-color);
            border-radius: var(--radius);
            font-size: 0.875rem;
            transition: var(--transition);
            background: white;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--dark-color);
            font-size: 0.875rem;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: var(--radius);
            cursor: pointer;
            font-size: 0.875rem;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transition: var(--transition);
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            box-shadow: var(--shadow-md);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .btn-secondary {
            background: var(--secondary-color);
            color: white;
        }

        .btn-success {
            background: var(--success-color);
            color: white;
        }

        .btn-danger {
            background: var(--danger-color);
            color: white;
        }

        .btn-outline {
            background: transparent;
            border: 2px solid var(--primary-color);
            color: var(--primary-color);
        }

        .btn-outline:hover {
            background: var(--primary-color);
            color: white;
        }

        .alert {
            padding: 1rem 1.5rem;
            border-radius: var(--radius);
            margin-bottom: 1.5rem;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                transform: translateX(-100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .alert-error {
            background: #fef2f2;
            color: var(--danger-color);
            border-left-color: var(--danger-color);
        }

        .alert-success {
            background: #f0fdf4;
            color: var(--success-color);
            border-left-color: var(--success-color);
        }

        .alert-info {
            background: #f0f9ff;
            color: var(--info-color);
            border-left-color: var(--info-color);
        }

        .alert-warning {
            background: #fffbeb;
            color: var(--warning-color);
            border-left-color: var(--warning-color);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 1.5rem;
            border-radius: 1rem;
            text-align: center;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--border-color);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--primary-dark));
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card.success::before { background: var(--success-color); }
        .stat-card.warning::before { background: var(--warning-color); }
        .stat-card.danger::before { background: var(--danger-color); }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .badge-primary { background: var(--primary-color); color: white; }
        .badge-success { background: var(--success-color); color: white; }
        .badge-warning { background: var(--warning-color); color: white; }
        .badge-danger { background: var(--danger-color); color: white; }
        .badge-info { background: var(--info-color); color: white; }
        .badge-secondary { background: var(--secondary-color); color: white; }

        .fade-in {
            animation: fadeIn 0.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .grid {
            display: grid;
            gap: 1.5rem;
        }

        .grid-cols-2 { grid-template-columns: repeat(2, 1fr); }
        .grid-cols-3 { grid-template-columns: repeat(3, 1fr); }
        .grid-cols-4 { grid-template-columns: repeat(4, 1fr); }
        .grid-cols-5 { grid-template-columns: repeat(5, 1fr); }

        .flex {
            display: flex;
            align-items: center;
        }

        .flex-1 { flex: 1; }
        .justify-center { justify-content: center; }
        .justify-between { justify-content: space-between; }
        .items-center { align-items: center; }
        .items-end { align-items: flex-end; }

        .gap-2 { gap: 0.5rem; }
        .gap-4 { gap: 1rem; }

        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-secondary { color: var(--secondary-color); }
        .text-sm { font-size: 0.875rem; }

        .font-semibold { font-weight: 600; }
        .font-bold { font-weight: 700; }

        .table-responsive {
            overflow-x: auto;
        }

        @media (max-width: 768px) {
            .navbar {
                padding: 1rem;
            }

            .main-content {
                padding: 1rem;
            }

            .main-content.sidebar-active {
                margin-left: 0;
            }

            .sidebar {
                width: 100%;
                left: -100%;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .grid-cols-2,
            .grid-cols-3,
            .grid-cols-4,
            .grid-cols-5 {
                grid-template-columns: 1fr;
            }
        }

        @media print {
            body {
                background: white;
            }

            .navbar,
            .sidebar {
                display: none;
            }

            .main-content {
                margin: 0;
                padding: 0;
            }

            .card {
                box-shadow: none;
                border: 1px solid #ccc;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <i class="fas fa-graduation-cap"></i>
            University Management System
        </div>
        <div class="nav-right">
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo isset($_SESSION['role']) ? strtoupper(substr($_SESSION['role'], 0, 1)) : 'U'; ?>
                </div>
                <div>
                    <div style="font-weight: 600; font-size: 0.875rem;">
                        <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'User'; ?>
                    </div>
                    <div style="font-size: 0.75rem; color: var(--secondary-color);">
                        <?php echo isset($_SESSION['role']) ? ucfirst($_SESSION['role']) : 'Guest'; ?>
                    </div>
                </div>
            </div>
            <button class="mobile-menu-toggle" onclick="toggleSidebar()">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </nav>

    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h3 style="margin: 0; font-size: 1.125rem;">
                <i class="fas fa-user-circle"></i> Navigation
            </h3>
        </div>
        <div class="sidebar-content">
            <?php if (isset($_SESSION['role'])): ?>
                <div class="sidebar-section">
                    <div class="sidebar-section-title">Main Menu</div>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <a href="../admin/dashboard.php" class="sidebar-link">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                        <a href="../admin/users.php" class="sidebar-link">
                            <i class="fas fa-users"></i> Users
                        </a>
                        <a href="../admin/settings.php" class="sidebar-link">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    <?php elseif ($_SESSION['role'] === 'cashier'): ?>
                        <a href="../cashier/cashier_dashboard.php" class="sidebar-link">
                            <i class="fas fa-cash-register"></i> Dashboard
                        </a>
                        <a href="../cashier/student_billing.php" class="sidebar-link">
                            <i class="fas fa-user-graduate"></i> Student Billing
                        </a>
                        <a href="../cashier/collection_report.php" class="sidebar-link">
                            <i class="fas fa-chart-line"></i> Collection Report
                        </a>
                    <?php elseif ($_SESSION['role'] === 'finance'): ?>
                        <a href="../finance/finance_dashboard.php" class="sidebar-link">
                            <i class="fas fa-chart-pie"></i> Finance Dashboard
                        </a>
                        <a href="../finance/reports.php" class="sidebar-link">
                            <i class="fas fa-file-invoice"></i> Financial Reports
                        </a>
                    <?php elseif ($_SESSION['role'] === 'teacher'): ?>
                        <a href="../teacher/dashboard.php" class="sidebar-link">
                            <i class="fas fa-chalkboard-teacher"></i> Dashboard
                        </a>
                        <a href="../teacher/class_list.php" class="sidebar-link">
                            <i class="fas fa-users"></i> Class List
                        </a>
                        <a href="../teacher/grades.php" class="sidebar-link">
                            <i class="fas fa-graduation-cap"></i> Grades
                        </a>
                    <?php elseif ($_SESSION['role'] === 'student'): ?>
                        <a href="../student/dashboard.php" class="sidebar-link">
                            <i class="fas fa-user"></i> Dashboard
                        </a>
                        <a href="../student/subjects.php" class="sidebar-link">
                            <i class="fas fa-book"></i> Subjects
                        </a>
                        <a href="../student/grades.php" class="sidebar-link">
                            <i class="fas fa-chart-line"></i> Grades
                        </a>
                    <?php endif; ?>
                </div>

                <div class="sidebar-section">
                    <div class="sidebar-section-title">Quick Actions</div>
                    <a href="#" onclick="window.print()" class="sidebar-link">
                        <i class="fas fa-print"></i> Print Page
                    </a>
                    <a href="../auth/logout.php" class="sidebar-link">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            <?php else: ?>
                <div class="sidebar-section">
                    <div class="sidebar-section-title">Authentication</div>
                    <a href="../auth/login.php" class="sidebar-link">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </aside>

    <main class="main-content" id="main-content">
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('main-content');
            
            sidebar.classList.toggle('active');
            mainContent.classList.toggle('sidebar-active');
        }

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const menuToggle = document.querySelector('.mobile-menu-toggle');
            
            if (window.innerWidth <= 768 && 
                !sidebar.contains(event.target) && 
                !menuToggle.contains(event.target) &&
                sidebar.classList.contains('active')) {
                toggleSidebar();
            }
        });

        // Add active class to current page link
        document.addEventListener('DOMContentLoaded', function() {
            const currentPath = window.location.pathname;
            const sidebarLinks = document.querySelectorAll('.sidebar-link');
            
            sidebarLinks.forEach(link => {
                if (link.getAttribute('href') === currentPath) {
                    link.classList.add('active');
                }
            });
        });

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    </script>

<!-- MAIN CONTENT -->
<div class="main-content">