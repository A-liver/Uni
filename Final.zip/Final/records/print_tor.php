<?php
require_once __DIR__ . '/../config/db_connection.php';
require_once __DIR__ . '/../fpdf/fpdf.php';

$db = new Database();
$conn = $db->getConnection();

$id = mysqli_real_escape_string($conn, $_GET['id']);

$student = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT * FROM students WHERE student_id='$id'
"));

if (!$student) {
    die("Student not found");
}

$records = mysqli_query($conn, "
    SELECT *
    FROM student_subjects
    WHERE student_id='$id'
    ORDER BY sy, sem, subject_code
");

// Calculate academic statistics
$statsQuery = mysqli_query($conn, "
    SELECT
        COUNT(*) as total_subjects,
        COUNT(CASE WHEN final > 0 THEN 1 END) as completed_subjects,
        COUNT(CASE WHEN final >= 75 THEN 1 END) as passed_subjects,
        COUNT(CASE WHEN final < 75 AND final > 0 THEN 1 END) as failed_subjects,
        SUM(CASE WHEN final > 0 THEN units END) as total_units,
        AVG(CASE WHEN final > 0 THEN final END) as average_grade,
        MAX(sy) as latest_sy,
        MAX(sem) as latest_sem
    FROM student_subjects
    WHERE student_id='$id'
");
$stats = mysqli_fetch_assoc($statsQuery);

// Calculate GWA (General Weighted Average)
$gwaQuery = mysqli_query($conn, "
    SELECT SUM(final * units) / SUM(units) as gwa
    FROM student_subjects
    WHERE student_id='$id' AND final > 0
");
$gwa = mysqli_fetch_assoc($gwaQuery);

// Create PDF
class TOR_PDF extends FPDF {
    function Header() {
        // University Header
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'TRANSCRIPT OF RECORDS', 0, 1, 'C');
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 5, 'Official Academic Record', 0, 1, 'C');
        $this->Cell(0, 5, 'UNIVERSITY MANAGEMENT SYSTEM', 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer() {
        $this->SetY(-30);
        $this->SetFont('Arial', '', 8);
        $this->Cell(0, 5, 'Generated on: ' . date('F d, Y h:i A'), 0, 1, 'C');
        $this->Cell(0, 5, 'This is an official transcript of records. Any alterations must be properly documented.', 0, 1, 'C');
        $this->Cell(0, 5, 'Note: This transcript is valid only when printed on official university letterhead.', 0, 1, 'C');
        $this->SetY(-15);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

$pdf = new TOR_PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

// Student Information
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'Student Information', 0, 1);
$pdf->SetFont('Arial', '', 10);

$pdf->Cell(40, 6, 'Student ID:', 0, 0);
$pdf->Cell(60, 6, $student['student_id'], 0, 0);
$pdf->Cell(40, 6, 'Full Name:', 0, 0);
$pdf->Cell(50, 6, $student['lname'] . ', ' . $student['fname'] . ' ' . ($student['mname'] ?? ''), 0, 1);
$pdf->Ln(3);

$pdf->Cell(40, 6, 'Course:', 0, 0);
$pdf->Cell(60, 6, $student['course'], 0, 0);
$pdf->Cell(40, 6, 'Major:', 0, 0);
$pdf->Cell(50, 6, $student['major'] ?? 'N/A', 0, 1);
$pdf->Ln(3);

$pdf->Cell(40, 6, 'Birth Date:', 0, 0);
$pdf->Cell(60, 6, date('F d, Y', strtotime($student['bdate'])), 0, 0);
$pdf->Cell(40, 6, 'Address:', 0, 0);
$pdf->Cell(50, 6, $student['city'] ?? 'N/A', 0, 1);
$pdf->Ln(3);

$pdf->Cell(40, 6, 'Latest SY:', 0, 0);
$pdf->Cell(60, 6, $stats['latest_sy'] ?? 'N/A', 0, 0);
$pdf->Cell(40, 6, 'Latest Sem:', 0, 0);
$pdf->Cell(50, 6, $stats['latest_sem'] ?? 'N/A', 0, 1);
$pdf->Ln(10);

// Academic Summary
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'Academic Summary', 0, 1);
$pdf->SetFont('Arial', '', 10);

$pdf->Cell(40, 6, 'Total Subjects:', 0, 0);
$pdf->Cell(20, 6, $stats['total_subjects'] ?? 0, 0, 0);
$pdf->Cell(40, 6, 'Completed:', 0, 0);
$pdf->Cell(20, 6, $stats['completed_subjects'] ?? 0, 0, 0);
$pdf->Cell(30, 6, 'Passed:', 0, 0);
$pdf->Cell(20, 6, $stats['passed_subjects'] ?? 0, 0, 1);
$pdf->Ln(3);

$pdf->Cell(40, 6, 'GWA:', 0, 0);
$pdf->Cell(20, 6, number_format($gwa['gwa'] ?? 0, 2), 0, 0);
$pdf->Cell(40, 6, 'Total Units:', 0, 0);
$pdf->Cell(20, 6, $stats['total_units'] ?? 0, 0, 1);
$pdf->Ln(10);

// Academic Records Table
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'Academic Records', 0, 1);
$pdf->Ln(2);

// Table Header
$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell(25, 7, 'SY', 1);
$pdf->Cell(25, 7, 'Sem', 1);
$pdf->Cell(30, 7, 'Code', 1);
$pdf->Cell(50, 7, 'Description', 1);
$pdf->Cell(15, 7, 'Units', 1);
$pdf->Cell(20, 7, 'Grade', 1);
$pdf->Cell(25, 7, 'Remarks', 1);
$pdf->Ln();

// Table Content
$pdf->SetFont('Arial', '', 9);
$sy_total = 0;
$current_sy = '';

while($r = mysqli_fetch_assoc($records)) {
    // Add year separator
    if ($current_sy != $r['sy']) {
        if ($current_sy != '') {
            $pdf->Cell(190, 6, 'SY ' . $current_sy . ' Total Units: ' . $sy_total, 0, 1, 'C');
            $pdf->Ln(2);
        }
        $current_sy = $r['sy'];
        $sy_total = 0;
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->Cell(190, 6, 'SCHOOL YEAR ' . $r['sy'], 0, 1, 'C');
        $pdf->Ln(2);
        $pdf->SetFont('Arial', '', 9);
    }
    $sy_total += $r['units'];

    $pdf->Cell(25, 6, $r['sy'], 1);
    $pdf->Cell(25, 6, $r['sem'], 1);
    $pdf->Cell(30, 6, $r['subject_code'], 1);
    $pdf->Cell(50, 6, substr($r['description'], 0, 30), 1);
    $pdf->Cell(15, 6, $r['units'], 1, 0, 'C');
    $pdf->Cell(20, 6, $r['final'] > 0 ? number_format($r['final'], 2) : 'N/A', 1, 0, 'C');
    $pdf->Cell(25, 6, $r['remarks'] ?? '-', 1);
    $pdf->Ln();
}

// Add last year total
if ($current_sy != '') {
    $pdf->Ln(2);
    $pdf->Cell(190, 6, 'SY ' . $current_sy . ' Total Units: ' . $sy_total, 0, 1, 'C');
}

$pdf->Ln(10);

// Legend
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'Legend', 0, 1);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(60, 6, 'Passed: Grade >= 75', 0, 0);
$pdf->Cell(60, 6, 'Failed: Grade < 75', 0, 0);
$pdf->Cell(60, 6, 'In Progress: Not yet graded', 0, 1);
$pdf->Ln(10);

// Signatures
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'Certification', 0, 1);
$pdf->SetFont('Arial', '', 10);

$pdf->Cell(60, 6, 'Certified by:', 0, 0);
$pdf->Cell(60, 6, 'Verified by:', 0, 0);
$pdf->Cell(60, 6, 'Approved by:', 0, 1);
$pdf->Ln(2);

$pdf->Cell(60, 6, '_________________________', 0, 0);
$pdf->Cell(60, 6, '_________________________', 0, 0);
$pdf->Cell(60, 6, '_________________________', 0, 1);
$pdf->Ln(2);

$pdf->Cell(60, 6, 'Registrar', 0, 0);
$pdf->Cell(60, 6, 'Department Head', 0, 0);
$pdf->Cell(60, 6, 'Dean', 0, 1);

// Output PDF
$pdf->Output('TOR_' . $student['student_id'] . '.pdf', 'I');
?>