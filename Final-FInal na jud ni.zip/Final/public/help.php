<?php
require_once __DIR__ . '/../includes/header.php';
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-question-circle"></i> Help & Support
            </h1>
        </div>
    </div>

    <!-- Getting Started -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-rocket"></i> Getting Started
            </h2>
        </div>
        <div class="card-body">
            <p class="mb-4">Welcome to the University Management System. This guide will help you navigate the system based on your role.</p>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="info-card info-card-primary">
                    <h4 class="font-semibold mb-2"><i class="fas fa-user-graduate"></i> Students</h4>
                    <ul class="text-sm space-y-1">
                        <li>• View your enrolled subjects</li>
                        <li>• Check your grades</li>
                        <li>• Generate exam permits</li>
                        <li>• View billing information</li>
                    </ul>
                </div>
                <div class="info-card info-card-success">
                    <h4 class="font-semibold mb-2"><i class="fas fa-chalkboard-teacher"></i> Teachers</h4>
                    <ul class="text-sm space-y-1">
                        <li>• View your class lists</li>
                        <li>• Encode student grades</li>
                        <li>• Print grade reports</li>
                        <li>• Manage class schedules</li>
                    </ul>
                </div>
                <div class="info-card info-card-info">
                    <h4 class="font-semibold mb-2"><i class="fas fa-user-tie"></i> Dean</h4>
                    <ul class="text-sm space-y-1">
                        <li>• Manage students and courses</li>
                        <li>• Oversee enrollment</li>
                        <li>• Assign teachers to subjects</li>
                        <li>• View academic reports</li>
                    </ul>
                </div>
                <div class="info-card info-card-warning">
                    <h4 class="font-semibold mb-2"><i class="fas fa-coins"></i> Finance & Cashier</h4>
                    <ul class="text-sm space-y-1">
                        <li>• Process student payments</li>
                        <li>• View collection reports</li>
                        <li>• Manage student billing</li>
                        <li>• Generate financial analytics</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Login Help -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-sign-in-alt"></i> Login Instructions
            </h2>
        </div>
        <div class="card-body">
            <div class="space-y-4">
                <div class="info-card">
                    <h4 class="font-semibold mb-2">How to Login</h4>
                    <ol class="text-sm space-y-2 ml-4">
                        <li>1. Click the <strong>Login</strong> button on the welcome page</li>
                        <li>2. Enter your username and password</li>
                        <li>3. Select your role from the dropdown</li>
                        <li>4. Click <strong>Sign In</strong> to access your dashboard</li>
                    </ol>
                </div>
                <div class="alert alert-warning">
                    <strong>Note:</strong> If you forgot your password, please contact the system administrator or your department office.
                </div>
            </div>
        </div>
    </div>

    <!-- Contact Support -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-headset"></i> Contact Support
            </h2>
        </div>
        <div class="card-body">
            <p class="mb-4">Need additional help? Contact our support team:</p>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="info-card info-card-primary">
                    <h4 class="font-semibold"><i class="fas fa-envelope"></i> Email</h4>
                    <p class="text-sm">support@university.edu</p>
                </div>
                <div class="info-card info-card-success">
                    <h4 class="font-semibold"><i class="fas fa-phone"></i> Phone</h4>
                    <p class="text-sm">+63 905-220-8739</p>
                </div>
                <div class="info-card info-card-info">
                    <h4 class="font-semibold"><i class="fas fa-building"></i> Office</h4>
                    <p class="text-sm">Admin Building, Room 101</p>
                </div>
            </div>
            <div class="mt-6 text-center">
                <a href="welcome.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Back to Welcome Page
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
