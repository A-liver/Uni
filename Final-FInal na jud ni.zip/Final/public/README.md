# University Management System - Public Portal

## Overview
This is the main entry point for the University Management System. When users access the `/final` directory, they are automatically redirected to this public folder.

## Structure
- **index.php** - Main entry point that redirects users based on their authentication status
- **welcome.php** - Public welcome page for non-authenticated users
- **README.md** - This documentation file

## How It Works

### For Non-Authenticated Users
1. Users visiting `/final` are redirected to `/final/public/`
2. If not logged in, they see the welcome page (`welcome.php`)
3. From the welcome page, users can:
   - Login to their account
   - Sign up for a new account
   - Access enrollment forms
   - Get help information

### For Authenticated Users
1. Users are automatically redirected to their role-specific dashboard:
   - **Admin** → `/final/admin/admin.php`
   - **Student** → `/final/student/student_dashboard.php`
   - **Teacher** → `/final/teacher/teacher_dashboard.php`
   - **Cashier** → `/final/cashier/cashier_dashboard.php`
   - **Finance** → `/final/finance/finance_dashboard.php`
   - **Dean** → `/final/dean/dean_dashboard.php`
   - **Records** → `/final/records/records_dashboard.php`

## URL Structure
```
/final/                    → Redirects to /final/public/
/final/public/              → Main portal entry point
/final/public/index.php     → Role-based redirect
/final/public/welcome.php   → Public welcome page
/final/auth/login.php       → Login page
/final/auth/signup.php      → Registration page
/final/form/eform.php       → Enrollment form
```

## Security Features
- Session-based authentication
- Role-based access control
- Automatic redirects based on user status
- Secure logout functionality

## Technical Implementation
- Uses `.htaccess` for URL rewriting
- PHP session management
- MySQL database integration
- Modern responsive design with CSS framework

## Access Requirements
- Web server with PHP support
- MySQL database
- Proper file permissions
- Apache with mod_rewrite enabled (for .htaccess)

## Support
For technical support or questions about the system, please contact the IT Support Team through the university's help desk system.
