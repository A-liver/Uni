-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2026 at 11:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `app_id` int(11) NOT NULL,
  `sy` varchar(20) DEFAULT NULL,
  `sem` varchar(5) DEFAULT NULL,
  `course` varchar(50) DEFAULT NULL,
  `major` varchar(50) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `bdate` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `ethnicity` varchar(50) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `region` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `barangay` varchar(50) DEFAULT NULL,
  `guardian_name` varchar(100) DEFAULT NULL,
  `guardian_contact` varchar(20) DEFAULT NULL,
  `guardian_address` varchar(150) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`app_id`, `sy`, `sem`, `course`, `major`, `fname`, `mname`, `lname`, `bdate`, `age`, `gender`, `religion`, `ethnicity`, `phone`, `email`, `country`, `region`, `city`, `barangay`, `guardian_name`, `guardian_contact`, `guardian_address`, `image_path`, `status`, `created_at`) VALUES
(3, '2025-2026', '3', 'AB', 'Economics', 'Darcy', 'Lich', 'Graves', '2003-10-31', 22, 'female', 'Assembly of God', '    Zamboangueño', '09052206769', 'LichGraves0@gmail.com', 'Philippines', 'REGIONXII', 'Alabel', 'Alegria', 'William L. Graves', '09773110999', 'Nowhere', 'uploads/1776917956_190px-Graves_card.png', 'approved', '2026-04-23 04:19:16'),
(4, '2025-2026', '3', 'BSIT', '', 'Apollo', 'Savant', 'Ixianus', '2004-10-18', 21, 'male', 'Protestants', '    Ati', '09052208739', 'Ixian1@gmail.com', 'Philippines', 'REGIONXII', 'Glan', 'Batulaki', 'Maximus S. Ixianus', '09773110666', 'North Ixia', 'uploads/1776920161_190px-Apollo_card.png', 'approved', '2026-04-23 04:56:01'),
(7, '2024-2025', '1', 'AB', 'Filipino', 'John', 'Ohne', 'Frankenstein', '2026-04-28', 0, 'male', 'Iglesia Ni Cristo', '    Bicolano', '09052208714', 'vikky@email.com', 'Philippines', 'REGIONXII', 'Kiamba', 'Badtasan', 'VIctor Frank', '09052212582', 'Munich, Germany', 'uploads/1777987296_Victor_card.png', 'approved', '2026-05-05 13:21:36'),
(8, '2025-2026', '1', 'AB', 'Economics', 'Rem', 'Remmington', 'Remy', '2026-05-01', 0, 'other', 'Evangelical Christian Outreach Foundation', '    Batak', '0905050578', 'remmy@email.com', 'Philippines', 'REGIONXII', 'Alabel', 'Pag-asa', 'Haze Remmington', '00000000011', 'OSIC', 'uploads/1777989301_images.jpg', 'approved', '2026-05-05 13:55:01'),
(9, '2025-2026', '2', 'BSIT', '', 'Fern', 'Nus', 'Flame', '2026-04-30', 0, 'male', 'Four Square Church', '    Binukid', '06090805214', 'flame@email.com', 'Philippines', 'REGIONXII', 'Kiamba', 'Badtasan', 'Saddy Fernus', '00000000012', 'New York, USA', 'uploads/1777990942_download.jpg', 'approved', '2026-05-05 14:22:22'),
(10, '2025-2026', '1', 'BSCS', '', 'Rem', 'Nus', 'Remy', '2026-05-03', 0, 'female', 'IGLESIA FILIPINIANA INDEPENDENCIA', '    Binukid', '09052208714', 'remmy1@email.com', 'Philippines', 'REGIONXII', 'Kiamba', 'Kayupo', 'Haze Remmington', '00000000011', 'Munich, Germany', 'uploads/1777993612_images.jpg', 'approved', '2026-05-05 15:06:52'),
(11, '2025-2026', '3', 'BSSW', '', 'saidal', 'Ohne', 'jikiri', '2023-05-15', 2, 'male', 'Iglesia Ni Cristo', '    Agta', '0905050578', 'saidaljikiri@gmail.com', 'Philippines', 'REGIONXII', 'Kiamba', 'Katubao', 'saidal jikiri', '09052212582', 'PUROK.PULOT', 'uploads/1777994366_download.jpg', 'approved', '2026-05-05 15:19:26');

-- --------------------------------------------------------

--
-- Table structure for table `billing_details`
--

CREATE TABLE `billing_details` (
  `billing_detail_id` int(11) NOT NULL,
  `billing_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `cn` varchar(50) DEFAULT NULL,
  `subject_code` varchar(20) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `units` int(11) NOT NULL,
  `rate_per_unit` decimal(10,2) DEFAULT 0.00,
  `amount` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billing_details`
--

INSERT INTO `billing_details` (`billing_detail_id`, `billing_id`, `student_id`, `cn`, `subject_code`, `description`, `units`, `rate_per_unit`, `amount`, `created_at`) VALUES
(1, 4, 0, NULL, NULL, 'Tuition', 0, 0.00, 0.00, '2026-05-05 15:19:36'),
(2, 4, 0, NULL, NULL, 'Miscellaneous Fee', 0, 0.00, 1200.00, '2026-05-05 15:19:36'),
(3, 4, 0, NULL, NULL, 'Laboratory Fee', 0, 0.00, 800.00, '2026-05-05 15:19:36'),
(4, 4, 0, NULL, NULL, 'Registration Fee', 0, 0.00, 500.00, '2026-05-05 15:19:36'),
(5, 4, 0, NULL, NULL, 'Library Fee', 0, 0.00, 300.00, '2026-05-05 15:19:36'),
(6, 4, 0, NULL, NULL, 'School ID Fee', 0, 0.00, 150.00, '2026-05-05 15:19:36'),
(7, 4, 0, NULL, NULL, 'Technology Fee', 0, 0.00, 600.00, '2026-05-05 15:19:36');

-- --------------------------------------------------------

--
-- Table structure for table `billing_master`
--

CREATE TABLE `billing_master` (
  `billing_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `sy` varchar(20) NOT NULL,
  `sem` varchar(10) NOT NULL,
  `total_units` int(11) DEFAULT 0,
  `total_amount` decimal(10,2) DEFAULT 0.00,
  `status` enum('unpaid','partial','paid') DEFAULT 'unpaid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billing_master`
--

INSERT INTO `billing_master` (`billing_id`, `student_id`, `sy`, `sem`, `total_units`, `total_amount`, `status`, `created_at`) VALUES
(1, 8, '2025-2026', '2', 0, 0.00, 'unpaid', '2026-05-05 14:22:36'),
(2, 9, '2025-2026', '1', 3, 300.00, 'unpaid', '2026-05-05 15:07:18'),
(4, 11, '2025-2026', '3', 3, 3850.00, 'partial', '2026-05-05 15:19:36');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `COURSE` varchar(50) NOT NULL,
  `DESC` varchar(255) NOT NULL,
  `MAJOR` varchar(100) DEFAULT '',
  `SY` varchar(20) DEFAULT '',
  `SEM` varchar(10) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `COURSE`, `DESC`, `MAJOR`, `SY`, `SEM`) VALUES
(1, 'COURSE', 'DESC', 'MAJOR', 'SY', 'SEM'),
(2, 'BSCE', 'Bachelor of Science in Civil Engineering', '', '', ''),
(3, 'BSCS', 'Bachelor of Science in Computer Science', '', '', ''),
(4, 'BSCA', 'Bachelor of Science in Customs Administration', '', '', ''),
(5, 'BSSW', 'Bachelor of Science in Social Work', '', '', ''),
(6, 'AB', 'Bachelor of Arts', 'Social Science', '', ''),
(7, 'AB', 'Bachelor of Arts', 'Filipino', '', ''),
(8, 'AB', 'Bachelor of Arts', 'Economics', '', ''),
(9, 'AB', 'Bachelor of Arts', 'English', '', ''),
(10, 'AB', 'Bachelor of Arts', 'Mass Communication', '', ''),
(11, 'BSOA', 'Bachelor of Science in Office Administration', 'Office Management', '', ''),
(12, 'BSOA', 'Bachelor of Science in Office Administration', 'Computer Education', '', ''),
(13, 'AOA', 'Associate in Office Administration', '', '', ''),
(14, 'BSCR', 'Bachelor of Science in Criminology', '', '', ''),
(15, 'BSA', 'Bachelor of Science in Accountancy', '', '', ''),
(16, 'BEED', 'Bachelor of Elementary Education', 'Filipino', '', ''),
(17, 'BSED', 'Bachelor of Secondary Education', 'Math', '', ''),
(18, 'BSED', 'Bachelor of Secondary Education', 'Science', '', ''),
(19, 'BSED', 'Bachelor of Secondary Education', 'Filipino', '', ''),
(20, 'BSED', 'Bachelor of Secondary Education', 'English', '', ''),
(21, 'MA', 'Master of Arts', 'English', '', ''),
(22, 'MA', 'Master of Arts', 'Guidance and Counseling', '', ''),
(23, 'MA', 'Master of Arts', 'Educational Management', '', ''),
(24, 'BEED', 'Bachelor of Elementary Education', 'Math', '', ''),
(25, 'BEED', 'Bachelor of Elementary Education', 'English', '', ''),
(26, 'BEED', 'Bachelor of Elementary Education', 'General Science', '', ''),
(27, 'AB', 'Bachelor or Arts', 'Psychology', '', ''),
(28, 'BSIT', 'Bachelor of Science in Information Technology', '', '', ''),
(29, 'BSBA', 'Bachelor of Science in Business Administration', 'Management Accounting', '', ''),
(30, 'BSIM', 'Bachelor of Science in Information Management', '', '', ''),
(31, 'ACT', 'Associates in Computer Technology', '', '', ''),
(32, 'CT', 'Computer System and Network Specialist', '', '', ''),
(33, 'MT', 'Medical Transcriptionist', '', '', ''),
(34, 'CC', 'Contact Center', '', '', ''),
(35, 'BEED', 'Bachelor of Elementary Education', 'Generalist', '', ''),
(36, 'CHS', 'COMPUTER HARDWARE SERVICING NCII', '', '', ''),
(37, 'BSBA', 'Bachelor of Science in Business Administration', 'Financial Management', '', ''),
(38, 'BSBA', 'Bachelor of Science in Business Administration', 'Marketing Management', '', ''),
(39, 'AB', 'Bachelor or Arts', 'Legal Studies', '', ''),
(40, 'ETEEAP', 'BSCR-ETEEAP', '', '', ''),
(41, 'BSEN', 'Bachelor of Science in Entrepreneurship', '', '', ''),
(42, 'BSGE', 'Bachelor of Science in Geodetic Engineering', '', '', ''),
(43, 'BSBA', 'Bachelor of Science in Business Administration', 'Business Management', '', ''),
(44, 'BSES', 'Bachelor of Science in Environmental Science', '', '', ''),
(45, 'BSMATH', 'Bachelor of Science in Mathematics', '', '', ''),
(46, 'BSED', 'Bachelor of Secondary Education', 'Mapeh', '', ''),
(47, 'BSED', 'Bachelor of Secondary Education', 'Physical Science', '', ''),
(48, 'BSBA', 'Bachelor of Science in Business Administration', 'Operation Management', '', ''),
(49, 'BPE', 'Bachelor of Physical Education', 'School Physical Education', '', ''),
(50, 'WINSW', 'Bachelor of Science in Social Work', '', '', ''),
(51, 'BTLED', 'Bachelor of Technology and Livelihood Education', 'Home Economics', '', ''),
(52, 'BSC', 'Bachelor of Science in Commerce', 'Business Management', '', ''),
(53, 'BSC', 'Bachelor of Science in Commerce', 'Management', '', ''),
(54, 'BSC', 'Bachelor of Science in Commerce', 'Marketing', '', ''),
(55, 'ACS', 'Associate in Computer Science', '', '', ''),
(56, 'PSP', 'POST SECONDARY PROGRAM', 'CHS NC2 & PROGRAMMING NC4', '', ''),
(57, 'JSC', 'Junior Secretarial Course', '', '', ''),
(58, 'CSC', 'Computer Secretarial Course', '', '', ''),
(59, 'BEED', 'Bachelor of Elementary Education', 'Pre-School Education', '', ''),
(60, 'BSAT', 'Bachelor of Science in Accounting Technology', '', '', ''),
(61, 'PSP', 'POST SECONDARY PROGRAM', 'BOOKKEEPING NC3', '', ''),
(62, 'BSBA', 'Bachelor of Science in Business Administration', 'Business Management', '', ''),
(63, 'BSBA', 'Bachelor of Science in Business Administration', 'Financial Management', '', ''),
(64, 'BSBA', 'Bachelor of Science in Business Administration', 'Marketing Management', '', ''),
(65, 'BSBA', 'Bachelor of Science in Business Administration', 'Operation Management', '', ''),
(66, 'SHS', 'Senior High School', 'ABM', '', ''),
(67, 'SHS', 'Senior High School', 'HUMSS', '', ''),
(68, 'SHS', 'Senior High School', 'STEM', '', ''),
(69, 'SHS', 'Senior High School', 'GAS', '', ''),
(70, 'BPED', 'Bachelor of Physical Education', '', '', ''),
(71, 'BLIS', 'Bachelor of Library and Information Science', '', '', ''),
(72, 'BSOA', 'Bachelor of Science in Office Administration', '', '', ''),
(73, 'BSMA', 'Bachelor of Science in Management Accounting', '', '', ''),
(74, 'BECED', 'Bachelor of Early Childhood Education', '', '', ''),
(75, 'BSIA', 'Bachelor of Science in Internal Auditing', '', '', ''),
(76, 'BSAIS', 'Bachelor of Science in Accounting Information System', '', '', ''),
(77, 'BEED', 'Bachelor of Elementary Education', 'Early Childhood Education', '', ''),
(78, 'BSC', 'Bachelor of Science in Commerce', 'Banking and Finance', '', ''),
(79, 'BEED', 'Bachelor of Elementary Education', '', '', ''),
(80, 'GRADER', 'BASIC EDUCATION', 'GRADE1', '', ''),
(81, 'GRADER', 'BASIC EDUCATION', 'GRADE2', '', ''),
(82, 'GRADER', 'BASIC EDUCATION', 'GRADE3', '', ''),
(83, 'GRADER', 'BASIC EDUCATION', 'GRADE4', '', ''),
(84, 'GRADER', 'BASIC EDUCATION', 'GRADE5', '', ''),
(85, 'GRADER', 'BASIC EDUCATION', 'GRADE6', '', ''),
(86, 'JHIGH', 'JUNIOR HIGH', 'GRADE7', '', ''),
(87, 'JHIGH', 'JUNIOR HIGH', 'GRADE8', '', ''),
(88, 'JHIGH', 'JUNIOR HIGH', 'GRADE9', '', ''),
(89, 'JHIGH', 'JUNIOR HIGH', 'GRADE10', '', ''),
(90, 'PREP', 'PREPARATORY', 'K1', '', ''),
(91, 'PREP', 'PREPARATORY', 'K2', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `fee_schedules`
--

CREATE TABLE `fee_schedules` (
  `fee_id` int(11) NOT NULL,
  `fee_name` varchar(100) DEFAULT NULL,
  `category` enum('Tuition','Misc','Lab','Other') NOT NULL,
  `amount` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_schedules`
--

INSERT INTO `fee_schedules` (`fee_id`, `fee_name`, `category`, `amount`) VALUES
(1, 'Miscellaneous Fee', 'Misc', 1200.00),
(2, 'Laboratory Fee', 'Lab', 800.00),
(3, 'Registration Fee', 'Other', 500.00),
(4, 'Library Fee', 'Other', 300.00),
(5, 'School ID Fee', 'Other', 150.00),
(6, 'Technology Fee', 'Misc', 600.00);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `billing_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `method` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `billing_id`, `student_id`, `amount_paid`, `payment_date`, `method`) VALUES
(2, 4, 11, 1550.00, '2026-05-06 08:03:14', NULL),
(3, 4, 11, 1550.00, '2026-05-06 08:03:30', NULL),
(4, 4, 11, 11.00, '2026-05-07 08:19:07', NULL),
(5, 4, 11, 11.00, '2026-05-07 08:19:57', NULL),
(6, 4, 11, 11.00, '2026-05-07 08:20:44', NULL),
(7, 4, 11, 11.00, '2026-05-07 08:21:57', NULL),
(8, 4, 11, 11.00, '2026-05-07 08:22:13', NULL),
(9, 4, 11, 150.00, '2026-05-07 09:21:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `subject_code` varchar(50) DEFAULT NULL,
  `instructor` varchar(100) DEFAULT NULL,
  `room` varchar(50) DEFAULT NULL,
  `day` varchar(20) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `sy` varchar(20) DEFAULT NULL,
  `sem` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `app_id` int(11) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `sy` varchar(20) DEFAULT NULL,
  `sem` varchar(5) DEFAULT NULL,
  `course` varchar(50) DEFAULT NULL,
  `major` varchar(50) DEFAULT NULL,
  `bdate` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `region` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `barangay` varchar(50) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `app_id`, `fname`, `mname`, `lname`, `sy`, `sem`, `course`, `major`, `bdate`, `gender`, `phone`, `email`, `region`, `city`, `barangay`, `image_path`, `created_at`) VALUES
(6, 7, 'John', 'Ohne', 'Frankenstein', '2025-2026', '1', 'AB', 'Filipino', '2026-04-28', 'male', '09052208714', 'vikky@email.com', 'REGIONXII', 'Kiamba', 'Badtasan', 'uploads/1777987296_Victor_card.png', '2026-05-05 13:28:47'),
(7, 8, 'Rem', 'Remmington', 'Remy', '2025-2026', '1', 'AB', 'Economics', '2026-05-01', 'other', '0905050578', 'remmy@email.com', 'REGIONXII', 'Alabel', 'Pag-asa', 'uploads/1777989301_images.jpg', '2026-05-05 13:59:53'),
(8, 9, 'Fern', 'Nus', 'Flame', '2025-2026', '2', 'BSIT', '', '2026-04-30', 'male', '06090805214', 'flame@email.com', 'REGIONXII', 'Kiamba', 'Badtasan', 'uploads/1777990942_download.jpg', '2026-05-05 14:22:36'),
(9, 10, 'Rem', 'Nus', 'Remy', '2025-2026', '1', 'BSCS', '', '2026-05-03', 'female', '09052208714', 'remmy1@email.com', 'REGIONXII', 'Kiamba', 'Kayupo', 'uploads/1777993612_images.jpg', '2026-05-05 15:07:18'),
(11, 11, 'saidal', 'Ohne', 'jikiri', '2025-2026', '3', 'BSSW', '', '2023-05-15', 'male', '0905050578', 'saidaljikiri@gmail.com', 'REGIONXII', 'Kiamba', 'Katubao', '1778079798_download.jpg', '2026-05-05 15:19:36');

-- --------------------------------------------------------

--
-- Table structure for table `student_subjects`
--

CREATE TABLE `student_subjects` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `cn` varchar(50) DEFAULT NULL,
  `course` varchar(100) DEFAULT NULL,
  `subject_code` varchar(20) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `units` int(11) DEFAULT NULL,
  `room` varchar(50) DEFAULT NULL,
  `instructor` varchar(100) DEFAULT NULL,
  `term` varchar(20) DEFAULT NULL,
  `sem` varchar(20) DEFAULT NULL,
  `sy` varchar(20) DEFAULT NULL,
  `g1` decimal(5,2) DEFAULT 0.00,
  `g2` decimal(5,2) DEFAULT 0.00,
  `g3` decimal(5,2) DEFAULT 0.00,
  `final` decimal(5,2) DEFAULT 0.00,
  `remarks` varchar(100) DEFAULT 'No Remarks'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_subjects`
--

INSERT INTO `student_subjects` (`id`, `student_id`, `cn`, `course`, `subject_code`, `description`, `units`, `room`, `instructor`, `term`, `sem`, `sy`, `g1`, `g2`, `g3`, `final`, `remarks`) VALUES
(8, 8, '7064', 'BSIT', 'GE203', 'The Contemporary World', 3, 'FG606', 'teacher01', '1', '2', '2025-2026', 0.00, 0.00, 0.00, 0.00, 'No Remarks'),
(9, 8, '5050', 'BSIT', 'DEVRDG413', 'Developmental Reading 2', 3, 'FG409', 'teacher01', '2', '2', '2025-2026', 99.00, 95.00, 75.00, 89.67, 'PASSED'),
(12, 6, '7064', 'AB', 'GE203', 'The Contemporary World', 3, 'FG606', 'teacher01', '1', '1', '2024-', 0.00, 0.00, 0.00, 0.00, 'No Remarks'),
(13, 6, '0038', 'AB', 'ENGL24', 'European Literature', 3, 'AG212', 'teacher01', '1', '1', '2024-', 0.00, 0.00, 0.00, 0.00, 'No Remarks'),
(14, 8, '5601', 'BSIT', 'GE301', 'Art Appreciation', 3, 'FG410', 'teacher01', '1', '2', '2025-2026', 0.00, 0.00, 0.00, 0.00, 'No Remarks'),
(17, 9, '5601', 'BSCS', 'GE301', 'Art Appreciation', 3, 'FG410', 'teacher01', '1', '1', '2025-2026', 0.00, 0.00, 0.00, 0.00, 'No Remarks'),
(18, 11, '5601', 'BSSW', 'GE301', 'Art Appreciation', 3, 'FG410', 'teacher01', '1', '3', '2025-2026', 90.00, 95.00, 99.00, 94.67, 'PASSED');

-- --------------------------------------------------------

--
-- Table structure for table `subjectssem120182019`
--

CREATE TABLE `subjectssem120182019` (
  `OPEN` tinyint(1) DEFAULT NULL,
  `BLOCK` int(11) DEFAULT NULL,
  `DISSOLVED` varchar(10) DEFAULT NULL,
  `TERM` varchar(5) DEFAULT NULL,
  `CN` varchar(20) DEFAULT NULL,
  `SEM` varchar(5) DEFAULT NULL,
  `SY` varchar(20) DEFAULT NULL,
  `COURSE` varchar(20) DEFAULT NULL,
  `SUBJECT` varchar(20) DEFAULT NULL,
  `DESC` varchar(100) DEFAULT NULL,
  `UNIT` int(11) DEFAULT NULL,
  `CREDIT` varchar(10) DEFAULT NULL,
  `TSTART` time DEFAULT NULL,
  `TEND` time DEFAULT NULL,
  `ROOM` varchar(20) DEFAULT NULL,
  `SK` varchar(5) DEFAULT NULL,
  `LIMIT` int(11) DEFAULT NULL,
  `ENROLLED` int(11) DEFAULT NULL,
  `CLOSED` tinyint(1) DEFAULT NULL,
  `CDATE` date DEFAULT NULL,
  `CTIME` time DEFAULT NULL,
  `LAB` tinyint(1) DEFAULT NULL,
  `AIR` tinyint(1) DEFAULT NULL,
  `MOD` tinyint(1) DEFAULT NULL,
  `C1` varchar(20) DEFAULT NULL,
  `C2` varchar(20) DEFAULT NULL,
  `C3` varchar(20) DEFAULT NULL,
  `C4` varchar(20) DEFAULT NULL,
  `PRN` varchar(20) DEFAULT NULL,
  `AFLAG` varchar(10) DEFAULT NULL,
  `DEPT` varchar(50) DEFAULT NULL,
  `DEPARTMENT` varchar(50) DEFAULT NULL,
  `PROGRAM` varchar(50) DEFAULT NULL,
  `MAJOR` varchar(50) DEFAULT NULL,
  `EMP_DP` varchar(10) DEFAULT NULL,
  `EMP_NO` varchar(20) DEFAULT NULL,
  `INSTRUCTOR` varchar(100) DEFAULT NULL,
  `SSERVICE` varchar(10) DEFAULT NULL,
  `SFCODE` varchar(20) DEFAULT NULL,
  `STYPE` varchar(10) DEFAULT NULL,
  `STP` varchar(10) DEFAULT NULL,
  `NRLD` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjectssem120182019`
--

INSERT INTO `subjectssem120182019` (`OPEN`, `BLOCK`, `DISSOLVED`, `TERM`, `CN`, `SEM`, `SY`, `COURSE`, `SUBJECT`, `DESC`, `UNIT`, `CREDIT`, `TSTART`, `TEND`, `ROOM`, `SK`, `LIMIT`, `ENROLLED`, `CLOSED`, `CDATE`, `CTIME`, `LAB`, `AIR`, `MOD`, `C1`, `C2`, `C3`, `C4`, `PRN`, `AFLAG`, `DEPT`, `DEPARTMENT`, `PROGRAM`, `MAJOR`, `EMP_DP`, `EMP_NO`, `INSTRUCTOR`, `SSERVICE`, `SFCODE`, `STYPE`, `STP`, `NRLD`) VALUES
(1, 0, NULL, '1', '6501', '1', '2018-2019', 'BSM', 'GE301', 'Art Appreciation', 3, '', '10:00:00', '11:00:00', 'AG208', 'D', 30, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6502', '1', '2018-2019', 'BSM', 'GE204', 'Ethics', 3, '', '12:00:00', '13:00:00', 'AG208', 'D', 30, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6503', '1', '2018-2019', 'BSM', 'MATH111', 'Precalculus', 5, '', '13:00:00', '14:00:00', 'AG208', 'D', 30, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6504', '1', '2018-2019', 'BSM', 'GE101', 'Purposive Communication', 3, '', '09:00:00', '10:00:00', 'AG208', 'D', 30, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6505', '1', '2018-2019', 'BSM', 'GE502', 'Enviromental Science', 3, '', '10:00:00', '11:00:00', 'AG208', 'D', 30, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6506', '1', '2018-2019', 'BSM', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6507', '1', '2018-2019', 'BSM', 'CWTS1', 'National Service Training Program 1', 3, '', '08:00:00', '10:00:00', 'AG208', 'S', 30, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1000', '1', '2018-2019', 'ITE', 'GE101', 'Purposive Communication', 3, '', '08:00:00', '09:00:00', 'EM202', 'D', 45, 45, 1, '0000-00-00', '10:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1001', '1', '2018-2019', 'ITE', 'GE302', 'Indigenous Creative Crafs', 3, '', '08:00:00', '09:00:00', 'EM202', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1002', '1', '2018-2019', 'ITE', 'GE204', 'Ethics', 3, '', '09:00:00', '10:00:00', 'EM202', 'D', 45, 45, 1, '0000-00-00', '10:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1003', '1', '2018-2019', 'ITE', 'GE502', 'Enviromental Science', 3, '', '09:00:00', '10:00:00', 'EM202', 'D', 45, 45, 1, '0000-00-00', '10:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1004', '1', '2018-2019', 'ITE', 'CC101', 'Introduction to Computing', 3, '', '10:00:00', '13:00:00', 'COMA', 'T', 40, 42, 1, '0000-00-00', '02:17:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1005', '1', '2018-2019', 'ITE', 'CC102', 'Computer Programming 1', 3, '', '10:00:00', '13:00:00', 'COMA', 'H', 40, 42, 1, '0000-00-00', '02:17:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1007', '1', '2018-2019', 'ITE', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 50, 1, '0000-00-00', '10:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1008', '1', '2018-2019', 'ITE', 'CWTS1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG405', 'S', 45, 45, 1, '0000-00-00', '10:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '2000', '1', '2018-2019', 'BSSW', 'GE201', 'Understanding the Self', 3, '', '08:00:00', '09:00:00', 'AG202', 'D', 45, 45, 1, '0000-00-00', '14:57:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '2001', '1', '2018-2019', 'BSSW', 'GE202', 'Reading in Philippine History', 3, '', '09:00:00', '10:00:00', 'AG202', 'D', 45, 45, 1, '0000-00-00', '14:57:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2002', '1', '2018-2019', 'BSSW', 'GE401', 'Mathematics in the Modern World', 3, '', '12:00:00', '13:00:00', 'AG202', 'D', 45, 45, 1, '0000-00-00', '14:57:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2003', '1', '2018-2019', 'BSSW', 'SWP1', 'Knowledge & Philosophical Foundation of the Social Work Profession', 3, '', '11:00:00', '12:00:00', 'AG202', 'D', 45, 45, 1, '0000-00-00', '14:57:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '2004', '1', '2018-2019', 'BSSW', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '2005', '1', '2018-2019', 'BSSW', 'NSTP1', 'National Service Training Program', 3, '', '13:00:00', '16:00:00', 'FG406', 'S', 45, 46, 1, '0000-00-00', '15:31:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2006', '1', '2018-2019', 'BSSW', 'ORIENT1', 'Orientation', 0, '', '09:00:00', '10:00:00', 'AG202', 'D', 45, 31, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '2007', '1', '2018-2019', 'BSSW', 'GE203', 'The Contemporary World', 3, '', '11:00:00', '12:00:00', 'AG202', 'D', 45, 45, 1, '0000-00-00', '14:58:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '2008', '1', '2018-2019', 'BSSW', 'GE201', 'Understanding the Self', 3, '', '14:00:00', '15:00:00', 'AG202', 'D', 45, 21, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '2009', '1', '2018-2019', 'BSSW', 'GE202', 'Reading in Philippine History', 3, '', '15:00:00', '16:00:00', 'AG202', 'D', 45, 21, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2010', '1', '2018-2019', 'BSSW', 'GE401', 'Mathematics in the Modern World', 3, '', '14:00:00', '15:00:00', 'AG202', 'D', 45, 21, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2011', '1', '2018-2019', 'BSSW', 'SWP1', 'Knowledge & Philosophical Foundation of the Social Work Profession', 3, '', '15:00:00', '16:00:00', 'AG202', 'D', 45, 19, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '2012', '1', '2018-2019', 'BSSW', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 21, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '2013', '1', '2018-2019', 'BSSW', 'NSTP1', 'National Service Training Program', 3, '', '08:00:00', '11:00:00', 'FG409', 'S', 45, 20, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2014', '1', '2018-2019', 'BSSW', 'ORIENT1', 'Orientation', 0, '', '16:00:00', '17:00:00', 'AG202', 'D', 45, 11, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '2015', '1', '2018-2019', 'BSSW', 'GE203', 'The Contemporary World', 3, '', '17:00:00', '18:00:00', 'AG202', 'D', 45, 22, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(0, 1, NULL, '1', '0001', '1', '2018-2019', 'CLA', 'ORIENT1', 'Orientation', 0, '', '15:00:00', '16:00:00', 'AG212', 'M', 37, 4, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0002', '1', '2018-2019', 'CLA', 'GE101', 'Purposive Communication', 3, '', '08:00:00', '09:00:00', 'AG212', 'D', 37, 39, 1, '0000-00-00', '09:22:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0003', '1', '2018-2019', 'CLA', 'GE301', 'Arts Appreciation', 3, '', '09:00:00', '10:00:00', 'FG512', 'D', 45, 39, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0004', '1', '2018-2019', 'CLA', 'GE501', 'Science, Technology and Society', 3, '', '11:00:00', '12:00:00', 'FG512', 'D', 45, 46, 1, '0000-00-00', '11:23:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0005', '1', '2018-2019', 'CLA', 'GE205', 'Life and Works of Rizal', 3, '', '12:00:00', '13:00:00', 'FG512', 'D', 45, 36, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0006', '1', '2018-2019', 'CLA', 'GE302', 'Indigenous Creative Crafts', 3, '', '08:00:00', '09:00:00', 'AG212', 'D', 37, 38, 1, '0000-00-00', '11:23:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0007', '1', '2018-2019', 'CLA', 'ESL1', 'Introduction to the English Language System', 3, '', '09:00:00', '10:00:00', 'AG212', 'D', 45, 40, 0, '0000-00-00', '10:57:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '0009', '1', '2018-2019', 'CLA', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '0010', '1', '2018-2019', 'CLA', 'NSTP1', 'National Service Training Program', 3, '', '08:00:00', '11:00:00', 'FG410', 'S', 45, 35, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '2016', '1', '2018-2019', 'BSSW', 'GE201', 'Undestanding the Self', 3, '', '17:00:00', '18:00:00', 'FG302', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '2017', '1', '2018-2019', 'BSSW', 'GE202', 'Reading in Philippine History', 3, '', '18:00:00', '19:00:00', 'FG302', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2018', '1', '2018-2019', 'BSSW', 'GE401', 'Mathematics in the Modern World', 3, '', '17:00:00', '18:00:00', 'AG202', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2019', '1', '2018-2019', 'BSSW', 'SWP1', 'Knowledge & Philosophical Foundation of the Social Work Profession', 3, '', '18:00:00', '19:00:00', 'AG202', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '2020', '1', '2018-2019', 'BSSW', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '2021', '1', '2018-2019', 'BSSW', 'NSTP1', 'National Service Training Program', 3, '', '08:00:00', '11:00:00', 'AG202', 'S', 45, 2, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2022', '1', '2018-2019', 'BSSW', 'ORIENT1', 'Orientation', 0, '', '19:00:00', '20:00:00', 'AG202', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '2023', '1', '2018-2019', 'BSSW', 'GE203', 'The Contemporary World', 3, '', '19:00:00', '20:00:00', 'FG302', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(0, 1, NULL, '1', '0011', '1', '2018-2019', 'CLA', 'ORIENT1', 'Orientation', 0, '', '15:00:00', '16:00:00', 'AG212', 'T', 37, 7, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0012', '1', '2018-2019', 'CLA', 'GE101', 'Purposive Communication', 3, '', '08:00:00', '09:00:00', 'AG207', 'D', 37, 37, 0, '0000-00-00', '14:54:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0013', '1', '2018-2019', 'CLA', 'GE301', 'Arts Appreciation', 3, '', '09:00:00', '10:00:00', 'AG207', 'D', 37, 37, 1, '0000-00-00', '14:54:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0014', '1', '2018-2019', 'CLA', 'GE501', 'Science, Technology and Society', 3, '', '11:00:00', '12:00:00', 'AG214', 'D', 37, 37, 1, '0000-00-00', '14:54:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0015', '1', '2018-2019', 'CLA', 'GE302', 'Indigenous Creative Crafts', 3, '', '08:00:00', '09:00:00', 'AG207', 'D', 37, 37, 1, '0000-00-00', '14:54:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0016', '1', '2018-2019', 'CLA', 'PSY101', 'Introduction to Psychology', 3, '', '11:00:00', '12:00:00', 'AG207', 'D', 37, 37, 1, '0000-00-00', '14:54:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '0018', '1', '2018-2019', 'CLA', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 38, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '0019', '1', '2018-2019', 'CLA', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG512', 'S', 45, 40, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(0, 1, NULL, '1', '0020', '1', '2018-2019', 'CLA', 'ORIENT1', 'Orientation', 0, '', '15:00:00', '16:00:00', 'AG212', 'W', 0, 10, 1, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0021', '1', '2018-2019', 'CLA', 'GE101', 'Purposive Communication', 3, '', '09:00:00', '10:00:00', 'FG405', 'D', 50, 46, 0, '0000-00-00', '16:34:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0022', '1', '2018-2019', 'CLA', 'GE301', 'Arts Appreciation', 3, '', '10:00:00', '11:00:00', 'FG512', 'D', 50, 46, 0, '0000-00-00', '16:34:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0023', '1', '2018-2019', 'CLA', 'GE501', 'Science, Technology and Society', 3, '', '12:00:00', '13:00:00', 'AG214', 'D', 40, 39, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0024', '1', '2018-2019', 'CLA', 'GE302', 'Indigenous Creative Crafts', 3, '', '09:00:00', '10:00:00', 'AG214', 'D', 40, 41, 1, '0000-00-00', '14:14:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0025', '1', '2018-2019', 'CLA', 'COM1', 'Communication Media', 3, '', '11:00:00', '12:00:00', 'AG214', 'D', 40, 34, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0026', '1', '2018-2019', 'CLA', 'COM2', 'Journalism Principles and Practice', 3, '', '12:00:00', '13:00:00', 'AG214', 'D', 40, 35, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '0027', '1', '2018-2019', 'CLA', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 50, 1, '0000-00-00', '08:16:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '0028', '1', '2018-2019', 'CLA', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG513', 'S', 45, 45, 1, '0000-00-00', '10:17:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5000', '1', '2018-2019', 'BEED', 'GE101', 'Purposive Communication', 3, '', '07:00:00', '08:00:00', 'FG402', 'D', 45, 45, 1, '0000-00-00', '14:05:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5001', '1', '2018-2019', 'BEED', 'GE301', 'Arts Appreciation', 3, '', '08:00:00', '09:00:00', 'FG402', 'D', 45, 45, 1, '0000-00-00', '14:05:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5002', '1', '2018-2019', 'BEED', 'GE501', 'Science, Technology and Society', 3, '', '10:00:00', '11:00:00', 'FG402', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5003', '1', '2018-2019', 'BEED', 'GE204', 'Ethics', 3, '', '11:00:00', '12:00:00', 'FG402', 'D', 45, 45, 1, '0000-00-00', '14:05:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5004', '1', '2018-2019', 'BEED', 'GE206', 'Gender and Society', 3, '', '07:00:00', '08:00:00', 'FG402', 'D', 45, 45, 1, '0000-00-00', '14:05:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5005', '1', '2018-2019', 'BEED', 'GE503', 'Living in the IT Era', 3, '', '11:00:00', '12:00:00', 'COMC', 'D', 45, 45, 1, '0000-00-00', '14:05:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5006', '1', '2018-2019', 'BEED', 'PCFG1/PCFC1', 'The Child and Adolescent Learning Principles', 3, '', '08:00:00', '09:00:00', 'FG402', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5007', '1', '2018-2019', 'BEED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5008', '1', '2018-2019', 'BEED', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG402', 'S', 45, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5010', '1', '2018-2019', 'BEED', 'PRSG1', 'Principles of Teaching', 3, '', '10:00:00', '11:00:00', 'FG402', 'D', 45, 45, 1, '0000-00-00', '10:30:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5011', '1', '2018-2019', 'BEED', 'GE101', 'Purposive Communication', 3, '', '12:00:00', '14:30:00', 'FG403', 'S', 45, 30, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5012', '1', '2018-2019', 'BEED', 'GE301', 'Arts Appreciation', 3, '', '14:30:00', '17:00:00', 'FG403', 'S', 45, 30, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5013', '1', '2018-2019', 'BEED', 'GE501', 'Science, Technology and Society', 3, '', '17:00:00', '19:30:00', 'FG403', 'S', 45, 30, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5014', '1', '2018-2019', 'BEED', 'GE204', 'Ethics', 3, '', '07:00:00', '09:30:00', 'FG403', 'U', 45, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5015', '1', '2018-2019', 'BEED', 'GE206', 'Gender and Society', 3, '', '09:30:00', '12:00:00', 'FG403', 'U', 45, 30, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5016', '1', '2018-2019', 'BEED', 'GE503', 'Living in the IT Era', 3, '', '12:30:00', '15:00:00', 'COMB', 'U', 45, 30, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5017', '1', '2018-2019', 'BEED', 'PCFG1/PCFC1', 'The Child and Adolescent Learning Principles', 3, '', '15:00:00', '17:30:00', 'FG403', 'U', 45, 29, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5018', '1', '2018-2019', 'BEED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5019', '1', '2018-2019', 'BEED', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '10:30:00', 'FG602', 'S', 45, 32, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5021', '1', '2018-2019', 'BEED', 'PRSG1', 'Principles of Teaching', 3, '', '17:30:00', '20:00:00', 'FG403', 'U', 45, 30, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5022', '1', '2018-2019', 'BEED', 'GE101', 'Purposive Communication', 3, '', '13:00:00', '14:00:00', 'FG402', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5023', '1', '2018-2019', 'BEED', 'GE301', 'Arts Appreciation', 3, '', '14:00:00', '15:00:00', 'FG402', 'D', 45, 41, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5024', '1', '2018-2019', 'BEED', 'GE501', 'Science, Technology and Society', 3, '', '16:00:00', '17:00:00', 'FG402', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5025', '1', '2018-2019', 'BEED', 'GE204', 'Ethics', 3, '', '17:00:00', '18:00:00', 'FG402', 'D', 45, 41, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5026', '1', '2018-2019', 'BEED', 'GE206', 'Gender and Society', 3, '', '13:00:00', '14:00:00', 'FG402', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5027', '1', '2018-2019', 'BEED', 'GE503', 'Living in the IT Era', 3, '', '14:00:00', '15:00:00', 'COMB', 'D', 45, 41, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5028', '1', '2018-2019', 'BEED', 'PCFG1/PCFC1', 'The Child and Adolescent Learning Principles', 3, '', '17:00:00', '18:00:00', 'FG402', 'D', 45, 41, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5029', '1', '2018-2019', 'BEED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5030', '1', '2018-2019', 'BEED', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG403', 'S', 45, 41, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5032', '1', '2018-2019', 'BEED', 'PRSG1', 'Principles of Teaching', 3, '', '16:00:00', '17:00:00', 'FG402', 'D', 45, 38, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5033', '1', '2018-2019', 'BEED', 'GE101', 'Purposive Communication', 3, '', '17:00:00', '18:00:00', 'FG403', 'D', 45, 29, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5034', '1', '2018-2019', 'BEED', 'GE301', 'Arts Appreciation', 3, '', '18:00:00', '19:00:00', 'FG403', 'D', 45, 28, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5035', '1', '2018-2019', 'BEED', 'GE501', 'Science, Technology and Society', 3, '', '19:00:00', '20:00:00', 'FG403', 'D', 45, 27, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5036', '1', '2018-2019', 'BEED', 'GE204', 'Ethics', 3, '', '20:00:00', '21:00:00', 'FG403', 'D', 45, 27, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5037', '1', '2018-2019', 'BEED', 'GE206', 'Gender and Society', 3, '', '17:00:00', '18:00:00', 'FG403', 'D', 45, 27, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5038', '1', '2018-2019', 'BEEU', 'GE503', 'Living in the IT Era', 3, '', '18:00:00', '19:00:00', 'COMB', 'D', 45, 27, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5039', '1', '2018-2019', 'BEED', 'PCFG1/PCFC1', 'The Child and Adolescent Learning Principles', 3, '', '19:00:00', '20:00:00', 'FG403', 'D', 45, 27, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5040', '1', '2018-2019', 'BEED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 35, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5041', '1', '2018-2019', 'BEED', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG206', 'S', 45, 35, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5043', '1', '2018-2019', 'BEED', 'PRSG1', 'Principles of Teaching', 3, '', '20:00:00', '21:00:00', 'FG403', 'D', 45, 27, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5400', '1', '2018-2019', 'BSED', 'M100', 'History of Mathematics', 3, '', '07:00:00', '08:00:00', 'FG403', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5401', '1', '2018-2019', 'BSED', 'M101', 'College and Advance A;gebra', 3, '', '08:00:00', '09:00:00', 'FG403', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5402', '1', '2018-2019', 'BSED', 'M105', 'Elementary Statistics and Probability', 3, '', '08:00:00', '09:00:00', 'FG403', 'D', 45, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5403', '1', '2018-2019', 'BSED', 'GE101', 'Purposive Communication', 3, '', '09:00:00', '10:00:00', 'FG403', 'D', 45, 45, 1, '0000-00-00', '10:58:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5404', '1', '2018-2019', 'BSED', 'GE301', 'Arts Appreciation', 3, '', '11:00:00', '12:00:00', 'FG403', 'D', 45, 45, 1, '0000-00-00', '10:59:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5405', '1', '2018-2019', 'BSED', 'GE501', 'Science, Technology and Society', 3, '', '07:00:00', '08:00:00', 'FG403', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5406', '1', '2018-2019', 'BSED', 'GE204', 'Ethics', 3, '', '09:00:00', '10:00:00', 'FG403', 'D', 45, 45, 1, '0000-00-00', '10:59:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5407', '1', '2018-2019', 'BSED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 51, 1, '0000-00-00', '16:54:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5408', '1', '2018-2019', 'BSED', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '10:30:00', 'FG603', 'S', 45, 46, 1, '0000-00-00', '16:54:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5410', '1', '2018-2019', 'BSED', 'CHEM1.0', 'Inorganic Chemistry Lecture', 3, '', '07:00:00', '08:00:00', 'FG409', 'D', 45, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5411', '1', '2018-2019', 'BSED', 'CHEM1.1', 'Inorganic Chemistry Lab', 2, '', '08:00:00', '09:00:00', 'FG409', 'D', 45, 39, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5412', '1', '2018-2019', 'BSED', 'SCI1', 'Earth Sciences', 3, '', '08:00:00', '09:00:00', 'FG409', 'D', 45, 38, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5413', '1', '2018-2019', 'BSED', 'PRSS9', 'Mechanics', 3, '', '09:00:00', '10:00:00', 'FG409', 'D', 45, 39, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5414', '1', '2018-2019', 'BSED', 'PCFS1', 'The Child and Adolescent Learning Principles', 3, '', '12:00:00', '13:00:00', 'FG403', 'D', 45, 29, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5415', '1', '2018-2019', 'BSED', 'GE101', 'Purposive Communication', 3, '', '09:00:00', '10:00:00', 'FG409', 'D', 45, 45, 1, '0000-00-00', '09:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5416', '1', '2018-2019', 'BSED', 'GE301', 'Arts Appreciation', 3, '', '10:00:00', '11:00:00', 'FG409', 'D', 45, 45, 1, '0000-00-00', '09:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5417', '1', '2018-2019', 'BSED', 'GE501', 'Science, Technology and Society', 3, '', '12:00:00', '13:00:00', 'FG409', 'D', 45, 45, 1, '0000-00-00', '11:40:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5418', '1', '2018-2019', 'BSED', 'GE204', 'Ethics', 3, '', '13:00:00', '14:00:00', 'FG409', 'D', 45, 45, 1, '0000-00-00', '09:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5419', '1', '2018-2019', 'BSED', 'GE206', 'Gender and Society', 3, '', '09:00:00', '10:00:00', 'FG402', 'D', 45, 45, 1, '0000-00-00', '09:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5420', '1', '2018-2019', 'BSED', 'GE503', 'Living in the IT Era', 3, '', '10:00:00', '11:00:00', 'COMC', 'D', 45, 45, 1, '0000-00-00', '09:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5421', '1', '2018-2019', 'BSED', 'PCFF1', 'The Child and Adolescent Learning Principles', 3, '', '13:00:00', '14:00:00', 'FG403', 'D', 45, 45, 1, '0000-00-00', '09:37:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5422', '1', '2018-2019', 'BSED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'F', 50, 47, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5423', '1', '2018-2019', 'BSED', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG405', 'S', 45, 45, 1, '0000-00-00', '13:36:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5425', '1', '2018-2019', 'BSED', 'EL100', 'Introduction to Linnguistics', 3, '', '10:00:00', '11:00:00', 'FG410', 'D', 45, 46, 1, '0000-00-00', '21:42:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5426', '1', '2018-2019', 'BSED', 'EL101', 'Language, Culture and Society', 3, '', '10:00:00', '11:00:00', 'FG409', 'D', 45, 46, 1, '0000-00-00', '21:42:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(0, 0, NULL, '2', '5427', '1', '2018-2019', 'BSED', 'EL102', 'Structure of English', 3, '', '13:00:00', '14:00:00', 'FG409', 'D', 45, 45, 1, '0000-00-00', '14:53:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5428', '1', '2018-2019', 'BSED', 'GE101', 'Purposive Communication', 3, '', '12:00:00', '13:00:00', 'FG410', 'D', 45, 46, 1, '0000-00-00', '21:41:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5429', '1', '2018-2019', 'BSED', 'GE301', 'Art Appreciation', 3, '', '09:00:00', '10:00:00', 'FG410', 'D', 45, 47, 1, '0000-00-00', '14:06:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5430', '1', '2018-2019', 'BSED', 'GE501', 'Science, Technology and Society', 3, '', '09:00:00', '10:00:00', 'FG303', 'D', 45, 46, 1, '0000-00-00', '21:41:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5431', '1', '2018-2019', 'BSED', 'GE204', 'Ethics', 3, '', '12:00:00', '13:00:00', 'FG402', 'D', 45, 45, 1, '0000-00-00', '09:46:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5432', '1', '2018-2019', 'BSED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'F', 50, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5433', '1', '2018-2019', 'BSED', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG409', 'S', 45, 46, 1, '0000-00-00', '21:41:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5435', '1', '2018-2019', 'BSED', 'PRSE7', 'Technical Correspondence', 3, '', '13:00:00', '14:00:00', 'FG410', 'D', 45, 46, 1, '0000-00-00', '21:42:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5436', '1', '2018-2019', 'BSED', 'EL100', 'Introduction to Linnguistics', 3, '', '09:00:00', '10:00:00', 'FG302', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5437', '1', '2018-2019', 'BSED', 'EL101', 'Language, Culture and Society', 3, '', '09:00:00', '10:00:00', 'FG410', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5438', '1', '2018-2019', 'BSED', 'EL102', 'Structure of English', 3, '', '12:00:00', '13:00:00', 'FG410', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5439', '1', '2018-2019', 'BSED', 'GE101', 'Purposive Communication', 3, '', '10:00:00', '11:00:00', 'FG302', 'D', 45, 45, 1, '0000-00-00', '14:03:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5440', '1', '2018-2019', 'BSED', 'GE301', 'Art Appreciation', 3, '', '13:00:00', '14:00:00', 'FG302', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5441', '1', '2018-2019', 'BSED', 'GE501', 'Science, Technology and Society', 3, '', '10:00:00', '11:00:00', 'FG410', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5442', '1', '2018-2019', 'BSED', 'GE204', 'Ethics', 3, '', '13:00:00', '14:00:00', 'FG410', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5443', '1', '2018-2019', 'BSED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'F', 50, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5444', '1', '2018-2019', 'BSED', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG410', 'S', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5446', '1', '2018-2019', 'BSED', 'PRSE7', 'Technical Correspondence', 3, '', '12:00:00', '13:00:00', 'FG302', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5700', '1', '2018-2019', 'BPE', 'GE101', 'Purposive Communication', 3, '', '11:00:00', '12:00:00', 'FG303', 'D', 45, 45, 1, '0000-00-00', '10:57:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5701', '1', '2018-2019', 'BPE', 'GE301', 'Art Appreciation', 3, '', '10:00:00', '11:00:00', 'FG303', 'D', 45, 45, 1, '0000-00-00', '10:57:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5702', '1', '2018-2019', 'BPE', 'GE501', 'Science, Technology and Society', 3, '', '09:00:00', '10:00:00', 'FG303', 'D', 45, 45, 1, '0000-00-00', '10:57:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5703', '1', '2018-2019', 'BPE', 'SCF1', 'Philosopical and Socioanthropological Foundation of Physical Education and Sports', 3, '', '10:00:00', '11:00:00', 'FG302', 'D', 45, 45, 1, '0000-00-00', '10:58:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5704', '1', '2018-2019', 'BPE', 'SCF2', 'Anatomy and Physiology of Human Movement', 3, '', '09:00:00', '10:00:00', 'FG302', 'D', 45, 45, 1, '0000-00-00', '10:58:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5705', '1', '2018-2019', 'BPE', 'PCFB1', 'The Child and Adolescent Learners and Learning Principles', 3, '', '11:00:00', '12:00:00', 'FG302', 'D', 45, 45, 1, '0000-00-00', '10:58:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5706', '1', '2018-2019', 'BPE', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'F', 50, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5707', '1', '2018-2019', 'BPE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG512', 'S', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5709', '1', '2018-2019', 'BPE', 'GE101', 'Purposive Communication', 3, '', '11:00:00', '12:00:00', 'FG303', 'D', 45, 45, 1, '0000-00-00', '16:11:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5710', '1', '2018-2019', 'BPE', 'GE301', 'Art Appreciation', 3, '', '10:00:00', '11:00:00', 'FG303', 'D', 45, 45, 1, '0000-00-00', '16:11:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5711', '1', '2018-2019', 'BPE', 'GE501', 'Science, Technology and Society', 3, '', '09:00:00', '10:00:00', 'FG405', 'D', 45, 45, 1, '0000-00-00', '16:11:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5712', '1', '2018-2019', 'BPE', 'SCF1', 'Philosopical and Socioanthropological Foundation of Physical Education and Sports', 3, '', '10:00:00', '11:00:00', 'FG406', 'D', 45, 45, 1, '0000-00-00', '16:11:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5713', '1', '2018-2019', 'BPE', 'SCF2', 'Anatomy and Physiology of Human Movement', 3, '', '09:00:00', '10:00:00', 'FG406', 'D', 45, 45, 1, '0000-00-00', '16:11:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5714', '1', '2018-2019', 'BPE', 'PCFB1', 'The Child and Adolescent Learners and Learning Principles', 3, '', '11:00:00', '12:00:00', 'FG406', 'D', 45, 45, 1, '0000-00-00', '16:11:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5715', '1', '2018-2019', 'BPE', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'F', 50, 45, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5716', '1', '2018-2019', 'BPE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG513', 'S', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3000', '1', '2018-2019', 'BSA', 'GE101', 'Purposive Communication', 3, '', '08:00:00', '09:00:00', 'FG206', 'D', 40, 26, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3001', '1', '2018-2019', 'BSA', 'GE201', 'Undestanding the Self', 3, '', '08:00:00', '09:00:00', 'FG206', 'D', 40, 27, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3002', '1', '2018-2019', 'BSA', 'GE202', 'Reading in Philippine History', 3, '', '09:00:00', '10:00:00', 'FG206', 'D', 40, 26, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3003', '1', '2018-2019', 'BSA', 'FIN11', 'Financial Markets', 3, '', '14:00:00', '15:00:00', 'FG206', 'MWF', 40, 25, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3004', '1', '2018-2019', 'BSA', 'ACCTG11', 'Financial Accounting and Reporting', 3, '', '12:00:00', '13:00:00', 'FG206', 'MWF', 40, 26, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3005', '1', '2018-2019', 'BSA', 'ADVMATH', 'Mathematics of Investment', 3, '', '09:00:00', '10:00:00', 'FG206', 'D', 40, 26, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3006', '1', '2018-2019', 'BSA', 'GE301', 'Art Appreciation', 3, '', '10:00:00', '11:00:00', 'FG206', 'D', 40, 27, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3007', '1', '2018-2019', 'BSA', 'ACCTG12', 'Conceptual Framework and Accounting Standards', 3, '', '13:00:00', '14:00:00', 'FG206', 'MWF', 40, 26, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3009', '1', '2018-2019', 'BSA', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 40, 25, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3010', '1', '2018-2019', 'BSA', 'CWTS1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG406', 'S', 40, 26, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3011', '1', '2018-2019', 'BSA', 'GE201', 'Undestanding the Self', 3, '', '13:00:00', '14:00:00', 'FG210', 'D', 40, 40, 1, '0000-00-00', '15:23:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3012', '1', '2018-2019', 'BSA', 'GE202', 'Reading in Philippine History', 3, '', '13:00:00', '14:00:00', 'FG210', 'D', 40, 40, 1, '0000-00-00', '15:23:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3013', '1', '2018-2019', 'BSA', 'GE101', 'Purposive Communication', 3, '', '14:00:00', '15:00:00', 'FG210', 'D', 40, 40, 1, '0000-00-00', '15:23:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3014', '1', '2018-2019', 'BSA', 'ADVMATH', 'Mathematics of Investment', 3, '', '14:00:00', '15:00:00', 'FG210', 'D', 40, 40, 1, '0000-00-00', '15:23:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL);
INSERT INTO `subjectssem120182019` (`OPEN`, `BLOCK`, `DISSOLVED`, `TERM`, `CN`, `SEM`, `SY`, `COURSE`, `SUBJECT`, `DESC`, `UNIT`, `CREDIT`, `TSTART`, `TEND`, `ROOM`, `SK`, `LIMIT`, `ENROLLED`, `CLOSED`, `CDATE`, `CTIME`, `LAB`, `AIR`, `MOD`, `C1`, `C2`, `C3`, `C4`, `PRN`, `AFLAG`, `DEPT`, `DEPARTMENT`, `PROGRAM`, `MAJOR`, `EMP_DP`, `EMP_NO`, `INSTRUCTOR`, `SSERVICE`, `SFCODE`, `STYPE`, `STP`, `NRLD`) VALUES
(1, 0, NULL, '3', '3015', '1', '2018-2019', 'BSA', 'ACCTG11', 'Financial Accounting and Reporting', 6, '', '12:00:00', '13:00:00', 'FG210', 'D', 40, 40, 1, '0000-00-00', '15:23:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3016', '1', '2018-2019', 'BSA', 'FIN11', 'Financial Markets', 3, '', '15:00:00', '16:00:00', 'FG210', 'MWF', 40, 40, 1, '0000-00-00', '15:23:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3017', '1', '2018-2019', 'BSA', 'ACCTG12', 'Conceptual Framework and Accounting Standards', 3, '', '16:00:00', '17:00:00', 'FG210', 'MWF', 40, 40, 1, '0000-00-00', '15:23:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3019', '1', '2018-2019', 'BSA', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 40, 39, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3020', '1', '2018-2019', 'BSA', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG605', 'S', 40, 39, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3021', '1', '2018-2019', 'BSA', 'GE101', 'Purposive Communication', 3, '', '10:00:00', '11:00:00', 'FG210', 'D', 40, 13, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3022', '1', '2018-2019', 'BSA', 'GE201', 'Undestanding the Self', 3, '', '09:00:00', '10:00:00', 'FG210', 'D', 40, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3023', '1', '2018-2019', 'BSA', 'GE202', 'Reading in Philippine History', 3, '', '09:00:00', '10:00:00', 'FG210', 'D', 40, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3024', '1', '2018-2019', 'BSA', 'FIN11', 'Financial Markets', 3, '', '13:00:00', '14:00:00', 'FG211', 'MWF', 40, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3025', '1', '2018-2019', 'BSA', 'ADVMATH', 'Mathematics of Investment', 3, '', '10:00:00', '11:00:00', 'FG210', 'D', 40, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3026', '1', '2018-2019', 'BSA', 'ACCTG12', 'Conceptual Framework and Accounting Standards', 3, '', '11:00:00', '12:00:00', 'FG210', 'MWF', 40, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3028', '1', '2018-2019', 'BSA', 'ACCTG11', 'Financial Accounting and Reporting', 6, '', '08:00:00', '09:00:00', 'FG210', 'D', 40, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3029', '1', '2018-2019', 'BSA', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 40, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3030', '1', '2018-2019', 'BSA', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG606', 'S', 40, 12, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3031', '1', '2018-2019', 'BSA', 'ADVMATH', 'Mathematics of Investment', 3, '', '12:00:00', '13:00:00', 'FG211', 'D', 40, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3032', '2', '2018-2019', 'BSA', 'GE201', 'Undestanding the Self', 3, '', '12:00:00', '13:00:00', 'FG211', 'D', 40, 5, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3033', '1', '2018-2019', 'BSA', 'GE202', 'Reading in Philippine History', 3, '', '13:00:00', '14:00:00', 'FG303', 'D', 40, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3034', '1', '2018-2019', 'BSA', 'FIN11', 'Financial Markets', 3, '', '14:00:00', '15:00:00', 'FG211', 'MWF', 40, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3035', '2', '2018-2019', 'BSA', 'GE101', 'Purposive Communication', 3, '', '13:00:00', '14:00:00', 'FG211', 'D', 40, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3036', '1', '2018-2019', 'BSA', 'ACCTG12', 'Conceptual Framework and Accounting Standards', 3, '', '15:00:00', '16:00:00', 'FG211', 'MWF', 40, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3038', '1', '2018-2019', 'BSA', 'ACCTG11', 'Financial Accounting and Reporting', 6, '', '16:00:00', '17:00:00', 'FG211', 'D', 40, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3039', '1', '2018-2019', 'BSA', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 40, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3040', '1', '2018-2019', 'BSA', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG607', 'S', 40, 4, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8000', '1', '2018-2019', 'CBE', 'GE202', 'Reading in Philippine History', 3, '', '08:00:00', '09:00:00', 'FG306', 'D', 45, 8, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8001', '1', '2018-2019', 'CBE', 'GE203', 'The Contemporary World', 3, '', '09:00:00', '10:00:00', 'FG306', 'D', 45, 8, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8002', '1', '2018-2019', 'CBE', 'ECON101', 'Basic Microeconomics', 3, '', '10:00:00', '11:00:00', 'FG306', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8003', '1', '2018-2019', 'CBE', 'GE201', 'Undestanding the Self', 3, '', '12:00:00', '13:00:00', 'FG306', 'D', 45, 8, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8004', '1', '2018-2019', 'CBE', 'GE205', 'Life and Works of Rizal', 3, '', '09:00:00', '10:00:00', 'FG306', 'D', 45, 7, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8005', '1', '2018-2019', 'CBE', 'MKTG1', 'Principles of Marketing', 3, '', '10:00:00', '11:00:00', 'FG306', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8006', '1', '2018-2019', 'CBE', 'MGT1', 'Principles of Management', 3, '', '13:00:00', '14:00:00', 'FG306', 'D', 45, 8, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8008', '1', '2018-2019', 'CBE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG602', 'S', 45, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8009', '1', '2018-2019', 'CBE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8010', '1', '2018-2019', 'CBE', 'GE203', 'The Contemporary World', 3, '', '09:00:00', '10:00:00', 'FG307', 'D', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8011', '1', '2018-2019', 'CBE', 'MKTG1', 'Principles of Marketing', 3, '', '10:00:00', '11:00:00', 'FG307', 'D', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8012', '1', '2018-2019', 'CBE', 'MGT1', 'Principles of Management', 3, '', '11:00:00', '12:00:00', 'FG307', 'D', 45, 38, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8013', '1', '2018-2019', 'CBE', 'GE201', 'Undestanding the Self', 3, '', '13:00:00', '14:00:00', 'FG307', 'D', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8014', '1', '2018-2019', 'CBE', 'GE202', 'Reading in Philippine History', 3, '', '08:00:00', '09:00:00', 'FG307', 'D', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8015', '1', '2018-2019', 'CBE', 'GE205', 'Life and Works of Rizal', 3, '', '09:00:00', '10:00:00', 'FG307', 'D', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8016', '1', '2018-2019', 'CBE', 'ECON101', 'Basic Microeconomics', 3, '', '10:00:00', '11:00:00', 'FG307', 'D', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8018', '1', '2018-2019', 'CBE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG603', 'S', 45, 37, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8019', '1', '2018-2019', 'CBE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8021', '1', '2018-2019', 'CBE', 'GE202', 'Reading in Philippine History', 3, '', '13:00:00', '14:00:00', 'FG306', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8022', '1', '2018-2019', 'CBE', 'GE205', 'Life and Works of Rizal', 3, '', '14:00:00', '15:00:00', 'FG307', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8023', '1', '2018-2019', 'CBE', 'ECON101', 'Basic Microeconomics', 3, '', '16:00:00', '17:00:00', 'FG306', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8024', '1', '2018-2019', 'CBE', 'GE203', 'The Contemporary World', 3, '', '13:00:00', '14:00:00', 'FG308', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8025', '1', '2018-2019', 'CBE', 'MKTG1', 'Principles of Marketing', 3, '', '14:00:00', '15:00:00', 'FG308', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8026', '1', '2018-2019', 'CBE', 'MGT1', 'Principles of Management', 3, '', '16:00:00', '17:00:00', 'FG308', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8028', '1', '2018-2019', 'CBE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG605', 'S', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8029', '1', '2018-2019', 'CBE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8030', '1', '2018-2019', 'CBE', 'GE201', 'Undestanding the Self', 3, '', '13:00:00', '14:00:00', 'FG308', 'D', 45, 11, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8031', '1', '2018-2019', 'CBE', 'MGT1', 'Principles of Management', 3, '', '14:00:00', '15:00:00', 'FG308', 'D', 45, 11, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8032', '1', '2018-2019', 'CBE', 'FIN101', 'Business Finance', 3, '', '16:00:00', '17:00:00', 'FG307', 'D', 45, 10, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8033', '1', '2018-2019', 'CBE', 'ECON101', 'Basic Microeconomics', 3, '', '17:00:00', '18:00:00', 'FG306', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8035', '1', '2018-2019', 'CBE', 'GE202', 'Reading in Philippine History', 3, '', '14:00:00', '15:00:00', 'FG307', 'D', 45, 11, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8036', '1', '2018-2019', 'CBE', 'GE203', 'The Contemporary World', 3, '', '16:00:00', '17:00:00', 'FG306', 'D', 45, 12, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8038', '1', '2018-2019', 'CBE', 'GE205', 'Life and Works of Rizal', 3, '', '17:00:00', '18:00:00', 'FG306', 'D', 45, 12, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8039', '1', '2018-2019', 'CBE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG606', 'S', 45, 10, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8040', '1', '2018-2019', 'CBE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, 10, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8041', '1', '2018-2019', 'CBE', 'GE203', 'The Contemporary World', 3, '', '08:00:00', '09:00:00', 'FG307', 'D', 45, 19, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8042', '1', '2018-2019', 'CBE', 'GE202', 'Reading in Philippine History', 3, '', '10:00:00', '11:00:00', 'FG308', 'D', 45, 20, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8043', '1', '2018-2019', 'CBE', 'ECON101', 'Basic Microeconomics', 3, '', '11:00:00', '12:00:00', 'FG308', 'D', 45, 21, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8044', '1', '2018-2019', 'CBE', 'FIN101', 'Business Finance', 3, '', '17:00:00', '18:00:00', 'FG307', 'D', 45, 20, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8045', '1', '2018-2019', 'CBE', 'GE205', 'Life and Works of Rizal', 3, '', '15:00:00', '16:00:00', 'FG311', 'D', 45, 21, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8046', '1', '2018-2019', 'CBE', 'GE201', 'Undestanding the Self', 3, '', '14:00:00', '15:00:00', 'FG311', 'D', 45, 19, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8047', '1', '2018-2019', 'CBE', 'MGT1', 'Principles of Management', 3, '', '18:00:00', '19:00:00', 'FG307', 'D', 45, 21, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8049', '1', '2018-2019', 'CBE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG607', 'S', 45, 21, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8050', '1', '2018-2019', 'CBE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, 20, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8051', '1', '2018-2019', 'CBE', 'MKTG1', 'Principles of Marketing', 3, '', '13:00:00', '14:00:00', 'FG311', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8052', '1', '2018-2019', 'CBE', 'GE201', 'Undestanding the Self', 3, '', '15:00:00', '16:00:00', 'FG308', 'D', 45, 12, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8053', '1', '2018-2019', 'CBE', 'GE202', 'Reading in Philippine History', 3, '', '16:00:00', '17:00:00', 'FG308', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8054', '1', '2018-2019', 'CBE', 'MGT1', 'Principles of Management', 3, '', '18:00:00', '19:00:00', 'FG311', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8056', '1', '2018-2019', 'CBE', 'GE203', 'The Contemporary World', 3, '', '09:00:00', '10:00:00', 'FG308', 'D', 45, 10, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8057', '1', '2018-2019', 'CBE', 'GE205', 'Life and Works of Rizal', 3, '', '10:00:00', '11:00:00', 'FG308', 'D', 45, 10, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8058', '1', '2018-2019', 'CBE', 'ECON101', 'Basic Microeconomics', 3, '', '11:00:00', '12:00:00', 'FG308', 'D', 45, 10, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8059', '1', '2018-2019', 'CBE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG610', 'S', 45, 13, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8060', '1', '2018-2019', 'CBE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, 10, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8062', '1', '2018-2019', 'CBE', 'GE201', 'Undestanding the Self', 3, '', '11:00:00', '12:00:00', 'FG311', 'D', 45, 22, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8063', '1', '2018-2019', 'CBE', 'GE203', 'The Contemporary World', 3, '', '13:00:00', '14:00:00', 'FG312', 'D', 45, 22, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8064', '1', '2018-2019', 'CBE', 'GE202', 'Reading in Philippine History', 3, '', '14:00:00', '15:00:00', 'FG312', 'D', 45, 22, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8065', '1', '2018-2019', 'CBE', 'MGT1', 'Principle of Management', 3, '', '13:00:00', '14:00:00', 'FG311', 'D', 45, 21, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8066', '1', '2018-2019', 'CBE', 'OM101', 'Clerical and Office Procedures', 3, '', '15:00:00', '16:00:00', 'FG308', 'D', 45, 22, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8067', '1', '2018-2019', 'CBE', 'SH101', 'Foundation of Shorthand', 3, '', '16:00:00', '17:00:00', 'FG311', 'D', 45, 21, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '8069', '1', '2018-2019', 'CBE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, 20, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8070', '1', '2018-2019', 'CBE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG611', 'S', 45, 23, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8068', '1', '2018-2019', 'CBE', 'COMPTYPE1', 'Intro to Keyboarding', 3, '', '17:00:00', '18:00:00', 'COMB', 'D', 40, 22, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4000', '1', '2018-2019', 'BSCE', 'MATH100', 'Precalculus', 6, '', '08:00:00', '10:00:00', 'EM301', 'D', 50, 50, 1, '0000-00-00', '09:26:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '4001', '1', '2018-2019', 'BSCE', 'GE501', 'Science, Technology and Society', 3, '', '07:00:00', '08:00:00', 'EM303', 'D', 50, 50, 1, '0000-00-00', '09:26:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4002', '1', '2018-2019', 'BSCE', 'GE401', 'Mathematics in the Modern World', 3, '', '10:00:00', '11:00:00', 'EM303', 'D', 50, 50, 1, '0000-00-00', '09:26:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4003', '1', '2018-2019', 'BSCE', 'MATH114', 'Calculus 1', 4, '', '08:00:00', '10:00:00', 'EM301', 'M-H', 50, 50, 1, '0000-00-00', '09:26:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4004', '1', '2018-2019', 'BSCE', 'CHEM114', 'Chemistry For Engineers', 4, '', '10:00:00', '12:00:00', 'EM301', 'D', 50, 50, 1, '0000-00-00', '09:26:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '4005', '1', '2018-2019', 'BSCE', 'BES112', 'Civil Engineering Orientation', 2, '', '11:00:00', '12:00:00', 'EM301', 'M-H', 50, 49, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4006', '1', '2018-2019', 'BSCE', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 55, 55, 1, '0000-00-00', '13:51:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4007', '1', '2018-2019', 'BSCE', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG610', 'S', 52, 52, 1, '0000-00-00', '09:46:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4008', '1', '2018-2019', 'BSCE', 'MATH100', 'Precalculus', 6, '', '13:00:00', '15:00:00', 'EM301', 'D', 50, 50, 1, '0000-00-00', '14:35:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '4009', '1', '2018-2019', 'BSCE', 'GE501', 'Science, Technology and Society', 3, '', '12:00:00', '13:00:00', 'EM303', 'D', 50, 50, 1, '0000-00-00', '14:33:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4010', '1', '2018-2019', 'BSCE', 'GE401', 'Mathematics in the Modern World', 3, '', '15:00:00', '16:00:00', 'EM303', 'D', 50, 50, 1, '0000-00-00', '14:33:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4011', '1', '2018-2019', 'BSCE', 'MATH114', 'Calculus 1', 4, '', '12:00:00', '14:00:00', 'EM301', 'M-H', 50, 50, 1, '0000-00-00', '14:33:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4012', '1', '2018-2019', 'BSCE', 'CHEM114', 'Chemistry For Engineers', 4, '', '14:00:00', '16:00:00', 'EM301', 'D', 50, 50, 1, '0000-00-00', '14:33:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '4013', '1', '2018-2019', 'BSCE', 'BES112', 'Civil Engineering Orientation', 2, '', '16:00:00', '17:00:00', 'EM302', 'M-H', 50, 50, 1, '0000-00-00', '14:33:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3504', '1', '2018-2019', 'BSES', 'GE101', 'Purposive Communication', 3, '', '08:00:00', '09:00:00', 'AG208', 'D', 30, 5, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3505', '1', '2018-2019', 'BSES', 'GE501', 'Science, Technology and Society', 3, '', '09:00:00', '10:00:00', 'FG513', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3506', '1', '2018-2019', 'BSES', 'MATH400', 'Pre-Calculus', 5, '', '10:00:00', '11:00:00', 'FG513', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3507', '1', '2018-2019', 'BSES', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 6, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3508', '1', '2018-2019', 'BSES', 'CWTS1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG611', 'S', 45, 6, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3509', '1', '2018-2019', 'BSES', 'EARTHSC1', 'Earth and Environmental Science', 3, '', '09:00:00', '10:00:00', 'BLAB', 'D', 40, 5, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3510', '1', '2018-2019', 'BSES', 'GE205', 'Life and Works of Rizal', 3, '', '10:00:00', '11:00:00', 'BLAB', 'D', 40, 5, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3511', '1', '2018-2019', 'BSES', 'CHEM1', 'General Chemistry', 5, '', '07:00:00', '09:00:00', 'BLAB', 'D', 40, 5, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3500', '1', '2018-2019', 'BSES', 'EM4', 'Environmental Laws and Policy', 3, '', '17:00:00', '18:00:00', 'BLAB', 'D', 40, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '3501', '1', '2018-2019', 'BSES', 'EM5', 'Environmental Economic Valuation', 3, '', '18:00:00', '19:00:00', 'BLAB', 'D', 40, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3502', '1', '2018-2019', 'BSES', 'ES4', 'The Environmental Impact Assessment System', 5, '', '17:00:00', '19:00:00', 'BLAB', 'D', 40, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'NE', 'S', 'mj', NULL),
(1, 0, NULL, '1', '6000', '1', '2018-2019', 'BSCA', 'ACCTG101', 'Fundamentals of Accounting, Business and Management', 3, '', '13:00:00', '14:00:00', 'FG205', 'D', 45, 42, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6001', '1', '2018-2019', 'BSCA', 'GE201', 'Undestanding the Self', 3, '', '14:00:00', '15:00:00', 'FG205', 'D', 45, 47, 1, '0000-00-00', '15:57:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6002', '1', '2018-2019', 'BSCA', 'GE202', 'Reading in Philippine History', 3, '', '15:00:00', '16:00:00', 'FG205', 'D', 45, 47, 0, '0000-00-00', '15:57:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6003', '1', '2018-2019', 'BSCA', 'GE203', 'The Contemporary World', 3, '', '16:00:00', '17:00:00', 'FG205', 'D', 45, 48, 1, '0000-00-00', '15:57:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6004', '1', '2018-2019', 'BSCA', 'GE401', 'Mathematics in the Modern World', 3, '', '13:00:00', '14:00:00', 'FG205', 'D', 45, 47, 1, '0000-00-00', '15:58:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6005', '1', '2018-2019', 'BSCA', 'GE101', 'Purposive Communication', 3, '', '14:00:00', '15:00:00', 'FG205', 'D', 45, 47, 1, '0000-00-00', '15:58:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6006', '1', '2018-2019', 'BSCA', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, 47, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6007', '1', '2018-2019', 'BSCA', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG604', 'S', 30, 31, 1, '0000-00-00', '15:58:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1009', '1', '2018-2019', 'ITE', 'MATH1', 'College Algebra', 3, '', '07:00:00', '08:00:00', 'EM202', 'D', 45, 9, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8071', '1', '2018-2019', 'CBE', 'GE201', 'Undestanding the Self', 3, '', '08:00:00', '09:00:00', 'FG308', 'D', 45, 20, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8072', '1', '2018-2019', 'CBE', 'ECON101', 'Basic Microeconomics', 3, '', '09:00:00', '10:00:00', 'FG308', 'D', 45, 20, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8073', '1', '2018-2019', 'CBE', 'GE202', 'Reading in Philippine History', 3, '', '11:00:00', '12:00:00', 'FG312', 'D', 45, 20, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8074', '1', '2018-2019', 'CBE', 'GE203', 'The Contemporary World', 3, '', '12:00:00', '13:00:00', 'FG312', 'D', 45, 21, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8077', '1', '2018-2019', 'CBE', 'MKTG1', 'Principles of Marketing', 3, '', '09:00:00', '10:00:00', 'FG311', 'D', 45, 20, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8078', '1', '2018-2019', 'CBE', 'MGT1', 'Principles of Management', 3, '', '11:00:00', '12:00:00', 'FG311', 'D', 45, 20, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8075', '1', '2018-2019', 'CBE', 'GE205', 'Life and Works of Rizal', 3, '', '13:00:00', '14:00:00', 'FG303', 'D', 45, 20, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8079', '1', '2018-2019', 'CBE', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG205', 'S', 45, 19, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8076', '1', '2018-2019', 'CBE', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 23, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8080', '1', '2018-2019', 'CBE', 'MGT1', 'Principles of Management', 3, '', '11:00:00', '12:00:00', 'FG302', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8081', '1', '2018-2019', 'CBE', 'GE201', 'Undestanding the Self', 3, '', '13:00:00', '14:00:00', 'FG403', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8082', '1', '2018-2019', 'CBE', 'GE203', 'The Contemporary World', 3, '', '14:00:00', '15:00:00', 'FG306', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8083', '1', '2018-2019', 'CBE', 'ECON101', 'Basic Microeconomics', 3, '', '17:00:00', '18:00:00', 'FG308', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8084', '1', '2018-2019', 'CBE', 'FIN101', 'Business Finance', 3, '', '14:00:00', '15:00:00', 'FG306', 'D', 45, 11, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8085', '1', '2018-2019', 'CBE', 'GE202', 'Reading in Philippine History', 3, '', '15:00:00', '16:00:00', 'FG306', 'D', 45, 11, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8086', '1', '2018-2019', 'CBE', 'GE205', 'Life and Works of Rizal', 3, '', '16:00:00', '17:00:00', 'FG307', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8087', '1', '2018-2019', 'CBE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG206', 'S', 45, 22, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8088', '1', '2018-2019', 'CBE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8089', '1', '2018-2019', 'CBE', 'SH101', 'Foundation of Shorthand', 3, '', '15:00:00', '16:00:00', 'FG306', 'D', 45, 1, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8090', '1', '2018-2019', 'CBE', 'GE201', 'Undestanding the Self', 3, '', '16:00:00', '17:00:00', 'FG311', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8093', '1', '2018-2019', 'CBE', 'GE202', 'Reading in Philippine History', 3, '', '10:00:00', '11:00:00', 'FG311', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8094', '1', '2018-2019', 'CBE', 'OM101', 'Clerical and Office Procedures', 3, '', '11:00:00', '12:00:00', 'FG306', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8095', '1', '2018-2019', 'CBE', 'MGT1', 'Principles of Management', 3, '', '14:00:00', '15:00:00', 'FG312', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8096', '1', '2018-2019', 'CBE', 'GE203', 'The Contemporary World', 3, '', '15:00:00', '16:00:00', 'FG312', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8097', '1', '2018-2019', 'CBE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'FG205', 'S', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8098', '1', '2018-2019', 'CBE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7000', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '08:00:00', '09:00:00', 'FG602', 'D', 50, 47, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7001', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '09:00:00', '10:00:00', 'FG602', 'D', 50, 47, 0, '0000-00-00', '09:42:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7002', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '10:00:00', '11:00:00', 'FG602', 'D', 50, 48, 0, '0000-00-00', '09:42:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7003', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '11:00:00', '12:00:00', 'FG602', 'D', 50, 48, 0, '0000-00-00', '15:48:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7004', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '08:00:00', '09:00:00', 'FG602', 'D', 50, 48, 0, '0000-00-00', '09:42:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7005', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '09:00:00', '10:00:00', 'FG602', 'D', 50, 47, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7006', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '10:00:00', '11:00:00', 'FG602', 'D', 50, 47, 0, '0000-00-00', '09:42:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7007', '1', '2018-2019', 'BSCR', 'DEFTAC1', 'Fundamentals of Martial Arts', 2, '', '13:00:00', '15:00:00', 'FL01', 'T', 100, 100, 1, '0000-00-00', '15:47:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'DE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7008', '1', '2018-2019', 'BSCR', 'ROTC1', 'Military Science 11 & 12', 3, '', '13:00:00', '17:00:00', 'FL01', 'S', 400, 385, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0017', '1', '2018-2019', 'CLA', 'ITC111', 'IT Fundamentals', 3, '', '09:00:00', '10:00:00', 'COMB', 'D', 40, 40, 1, '0000-00-00', '15:46:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7009', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '08:00:00', '09:00:00', 'FG603', 'D', 50, 45, 0, '0000-00-00', '16:41:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7010', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '09:00:00', '10:00:00', 'FG603', 'D', 50, 45, 0, '0000-00-00', '16:42:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7011', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '10:00:00', '11:00:00', 'FG603', 'D', 50, 45, 0, '0000-00-00', '16:42:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7012', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '11:00:00', '12:00:00', 'FG603', 'D', 50, 45, 0, '0000-00-00', '16:42:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7013', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '08:00:00', '09:00:00', 'FG603', 'D', 50, 45, 0, '0000-00-00', '16:42:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7014', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '09:00:00', '10:00:00', 'FG603', 'D', 50, 45, 0, '0000-00-00', '16:42:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7015', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '10:00:00', '11:00:00', 'FG603', 'D', 50, 45, 0, '0000-00-00', '16:42:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7016', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '07:00:00', '08:00:00', 'FG605', 'D', 50, 45, 0, '0000-00-00', '15:07:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7017', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '08:00:00', '09:00:00', 'FG605', 'D', 50, 45, 0, '0000-00-00', '15:07:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7018', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '09:00:00', '10:00:00', 'FG605', 'D', 50, 45, 0, '0000-00-00', '15:07:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7019', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '10:00:00', '11:00:00', 'FG605', 'D', 50, 45, 0, '0000-00-00', '15:07:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7020', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '07:00:00', '08:00:00', 'FG605', 'D', 50, 45, 0, '0000-00-00', '15:07:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7021', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '08:00:00', '09:00:00', 'FG605', 'D', 50, 45, 0, '0000-00-00', '15:08:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7022', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '09:00:00', '10:00:00', 'FG605', 'D', 50, 45, 0, '0000-00-00', '15:07:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7023', '1', '2018-2019', 'BSCR', 'DEFTAC1', 'Fundamentals of Martial Arts', 2, '', '13:00:00', '15:00:00', 'FL01', 'W', 100, 94, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'DE', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7024', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '07:00:00', '08:00:00', 'FG606', 'D', 50, 46, 0, '0000-00-00', '15:47:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7025', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '08:00:00', '09:00:00', 'FG606', 'D', 50, 46, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7026', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '09:00:00', '10:00:00', 'FG606', 'D', 50, 46, 0, '0000-00-00', '15:48:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7027', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '10:00:00', '11:00:00', 'FG606', 'D', 50, 46, 0, '0000-00-00', '15:48:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7028', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '07:00:00', '08:00:00', 'FG606', 'D', 50, 46, 0, '0000-00-00', '15:48:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7029', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '08:00:00', '09:00:00', 'FG606', 'D', 50, 46, 0, '0000-00-00', '11:02:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7030', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '09:00:00', '10:00:00', 'FG606', 'D', 50, 45, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7031', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '13:00:00', '14:00:00', 'FG605', 'D', 50, 49, 0, '0000-00-00', '02:50:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7032', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '14:00:00', '15:00:00', 'FG605', 'D', 50, 46, 0, '0000-00-00', '02:58:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL);
INSERT INTO `subjectssem120182019` (`OPEN`, `BLOCK`, `DISSOLVED`, `TERM`, `CN`, `SEM`, `SY`, `COURSE`, `SUBJECT`, `DESC`, `UNIT`, `CREDIT`, `TSTART`, `TEND`, `ROOM`, `SK`, `LIMIT`, `ENROLLED`, `CLOSED`, `CDATE`, `CTIME`, `LAB`, `AIR`, `MOD`, `C1`, `C2`, `C3`, `C4`, `PRN`, `AFLAG`, `DEPT`, `DEPARTMENT`, `PROGRAM`, `MAJOR`, `EMP_DP`, `EMP_NO`, `INSTRUCTOR`, `SSERVICE`, `SFCODE`, `STYPE`, `STP`, `NRLD`) VALUES
(1, 0, NULL, '1', '7033', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '15:00:00', '16:00:00', 'FG605', 'D', 50, 46, 0, '0000-00-00', '09:43:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7034', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '17:00:00', '18:00:00', 'FG605', 'D', 50, 46, 0, '0000-00-00', '18:35:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7035', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '13:00:00', '14:00:00', 'FG606', 'D', 50, 46, 0, '0000-00-00', '16:05:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7036', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '14:00:00', '15:00:00', 'FG606', 'D', 50, 46, 0, '0000-00-00', '02:58:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7037', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '15:00:00', '16:00:00', 'FG606', 'D', 50, 45, 0, '0000-00-00', '02:58:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7038', '1', '2018-2019', 'BSCR', 'DEFTAC1', 'Fundamentals of Martial Arts', 2, '', '06:00:00', '08:00:00', 'FL01', 'T', 100, 70, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'DE', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7039', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '13:00:00', '14:00:00', 'FG605', 'D', 50, 48, 0, '0000-00-00', '14:51:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7040', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '14:00:00', '15:00:00', 'FG605', 'D', 50, 50, 1, '0000-00-00', '09:13:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7041', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '15:00:00', '16:00:00', 'FG605', 'D', 50, 48, 0, '0000-00-00', '16:09:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7042', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '17:00:00', '18:00:00', 'FG605', 'D', 50, 48, 0, '0000-00-00', '11:01:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7043', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '13:00:00', '14:00:00', 'FG606', 'D', 50, 48, 0, '0000-00-00', '11:04:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7044', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '14:00:00', '15:00:00', 'FG606', 'D', 50, 48, 0, '0000-00-00', '13:25:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7045', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '15:00:00', '16:00:00', 'FG606', 'D', 50, 48, 0, '0000-00-00', '11:01:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7046', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '12:00:00', '13:00:00', 'FG607', 'D', 50, 44, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7047', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '13:00:00', '14:00:00', 'FG607', 'D', 50, 44, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7048', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '14:00:00', '15:00:00', 'FG607', 'D', 50, 44, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7049', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '15:00:00', '16:00:00', 'FG607', 'D', 50, 44, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7050', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '12:00:00', '13:00:00', 'FG602', 'D', 50, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7051', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '13:00:00', '14:00:00', 'FG602', 'D', 50, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7052', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '14:00:00', '15:00:00', 'FG602', 'D', 50, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7053', '1', '2018-2019', 'BSCR', 'DEFTAC1', 'Fundamentals of Martial Arts', 2, '', '08:00:00', '11:00:00', 'FL01', 'T', 100, 100, 1, '0000-00-00', '09:14:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'DE', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7054', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '12:00:00', '13:00:00', 'FG603', 'D', 50, 47, 0, '0000-00-00', '14:55:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7055', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '13:00:00', '14:00:00', 'FG603', 'D', 50, 47, 0, '0000-00-00', '14:56:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7056', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '14:00:00', '15:00:00', 'FG603', 'D', 50, 47, 0, '0000-00-00', '14:56:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7057', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '15:00:00', '16:00:00', 'FG603', 'D', 50, 47, 0, '0000-00-00', '14:56:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7058', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '12:00:00', '13:00:00', 'FG610', 'D', 50, 47, 0, '0000-00-00', '14:56:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7059', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '13:00:00', '14:00:00', 'FG610', 'D', 50, 47, 0, '0000-00-00', '14:56:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7060', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '14:00:00', '15:00:00', 'FG610', 'D', 50, 47, 0, '0000-00-00', '14:56:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7061', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '17:00:00', '18:00:00', 'FG606', 'D', 45, 44, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7062', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '18:00:00', '19:00:00', 'FG606', 'D', 45, 45, 1, '0000-00-00', '13:23:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7063', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '19:00:00', '20:00:00', 'FG606', 'D', 45, 45, 1, '0000-00-00', '13:23:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7064', '1', '2018-2019', ' BSC', 'GE203', 'The Contemporary World', 3, '', '20:00:00', '21:00:00', 'FG606', 'D', 45, 44, 1, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7065', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '17:00:00', '18:00:00', 'FG603', 'D', 45, 45, 1, '0000-00-00', '13:23:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7066', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '18:00:00', '19:00:00', 'FG603', 'D', 45, 45, 1, '0000-00-00', '13:13:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7067', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '19:00:00', '20:00:00', 'FG603', 'D', 45, 45, 1, '0000-00-00', '13:32:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7069', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '17:00:00', '18:00:00', 'FG606', 'D', 45, 46, 1, '0000-00-00', '15:55:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7070', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '18:00:00', '19:00:00', 'FG606', 'D', 45, 45, 1, '0000-00-00', '15:55:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7071', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '19:00:00', '20:00:00', 'FG606', 'D', 45, 46, 1, '0000-00-00', '15:55:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7072', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '20:00:00', '21:00:00', 'FG606', 'D', 45, 44, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7073', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '17:00:00', '18:00:00', 'FG602', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7074', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '18:00:00', '19:00:00', 'FG602', 'D', 45, 45, 1, '0000-00-00', '15:55:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7075', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '19:00:00', '20:00:00', 'FG602', 'D', 45, 46, 1, '0000-00-00', '15:55:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '2025', '1', '2018-2019', 'BSSW', 'FIELD1SW', 'Field Instruction 1', 6, '', '08:00:00', '09:00:00', 'AG210', 'D', 37, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2026', '1', '2018-2019', 'BSSW', 'SPPS9', 'Seminar in Current Trend in Social Work Practice', 3, '', '18:00:00', '19:00:00', 'AG210', 'D', 37, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '2027', '1', '2018-2019', 'BSSW', 'FIELD1SW', 'Field Instruction 1', 6, '', '09:00:00', '10:00:00', 'AG210', 'D', 37, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '2028', '1', '2018-2019', 'BSSW', 'SPPS9', 'Seminar in Current Trend in Social Work Practice', 3, '', '19:00:00', '20:00:00', 'AG210', 'D', 37, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6508', '1', '2018-2019', 'BSSW', 'MATH21', 'Complex Analysis', 3, '', '13:00:00', '14:00:00', 'FG604', 'D', 30, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6509', '1', '2018-2019', 'BSSW', 'MATH22', 'Graph Theory and its application', 3, '', '12:00:00', '13:00:00', 'AG208', 'D', 30, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6510', '1', '2018-2019', 'BSSW', 'MATH23', 'Actuarial Mathematics 1', 3, '', '14:00:00', '15:00:00', 'AG208', 'D', 30, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5044', '1', '2018-2019', 'BEED', 'FS411', 'Learning Assessment Strategies', 1, '', '07:00:00', '08:00:00', 'EM306', 'W', 45, 5, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5045', '1', '2018-2019', 'BEED', 'FS431', 'On becoming a Teacher', 1, '', '08:00:00', '09:00:00', 'EM306', 'W', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5046', '1', '2018-2019', 'BEED', 'PSE8', 'Prep. and Eval. of Insr. Mateials', 3, '', '17:00:00', '18:00:00', 'FG409', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5047', '1', '2018-2019', 'BEED', 'PSE18', 'Directed Study in ECE', 3, '', '18:00:00', '19:00:00', 'FG409', 'D', 45, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5048', '1', '2018-2019', 'BEED', 'HE1', 'Home Economics and Livelihood Educ', 3, '', '19:00:00', '20:00:00', 'FG409', 'D', 45, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5049', '1', '2018-2019', 'BEED', 'PSE10', 'Observational Child Study', 3, '', '16:00:00', '17:00:00', 'FG302', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5050', '1', '2018-2019', 'BEED', 'DEVRDG413', 'Developmental Reading 2', 3, '', '17:00:00', '18:00:00', 'FG409', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5051', '1', '2018-2019', 'BEED', 'PSE17', 'Trends and Issues in PSE', 3, '', '18:00:00', '19:00:00', 'FG409', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5052', '1', '2018-2019', 'BEED', 'ST400', 'Seminar on Special Topics', 3, '', '07:00:00', '09:30:00', 'EM306', 'S', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5053', '1', '2018-2019', 'BEED', 'FS311', 'Technology in the Learning Envi.', 1, '', '07:00:00', '08:00:00', 'EM306', 'M', 45, 2, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5054', '1', '2018-2019', 'BEED', 'MATH202', 'Plane Geometry', 3, '', '15:00:00', '16:00:00', 'FG409', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5055', '1', '2018-2019', 'BEED', 'PSE7', 'Science, Health and Nature Study', 3, '', '12:00:00', '13:00:00', 'FG604', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5056', '1', '2018-2019', 'BEED', 'PS305', 'Astronomy', 3, '', '17:00:00', '18:00:00', 'FG410', 'D', 45, 1, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5058', '1', '2018-2019', 'BEED', 'PSE12', 'Classroom Management', 3, '', '12:00:00', '13:00:00', 'FG205', 'D', 45, 0, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5059', '1', '2018-2019', 'BEED', 'PSE13', 'Guidance and Counseling in PSE', 3, '', '17:00:00', '18:00:00', 'FG410', 'D', 45, 0, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5060', '1', '2018-2019', 'BEED', 'EDUC302', 'Curriculum Development', 3, '', '15:00:00', '16:00:00', 'FG410', 'D', 45, 1, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5062', '1', '2018-2019', 'BEED', 'TSPSE', 'Teaching Strategies in ECE (ALL SUBJECT)', 3, '', '14:00:00', '15:00:00', 'FG409', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5063', '1', '2018-2019', 'BEED', 'FS411', 'Learning Assessment Strategies', 1, '', '07:00:00', '08:00:00', 'EM306', 'M', 45, 36, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5064', '1', '2018-2019', 'BEEU', 'FS431', 'On becoming a Teacher', 1, '', '07:00:00', '08:00:00', 'EM306', 'M', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5065', '1', '2018-2019', 'BEED', 'DEVRDG413', 'Developmental Reading 2', 3, '', '13:00:00', '14:00:00', 'FG512', 'D', 45, 33, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5066', '1', '2018-2019', 'BEED', 'NATSC313', 'Ecology', 3, '', '15:00:00', '16:00:00', 'FG512', 'D', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5067', '1', '2018-2019', 'BEED', 'MATH308', 'Problem Solving in Math', 3, '', '14:00:00', '15:00:00', 'FG512', 'D', 45, 38, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5068', '1', '2018-2019', 'BEED', 'ST400', 'Seminar on Special Topics', 3, '', '12:00:00', '13:00:00', 'EM306', 'D', 45, 34, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5069', '1', '2018-2019', 'BEED', 'HE413', 'Home Economics & Livelihood Ed.', 3, '', '13:00:00', '14:00:00', 'FG302', 'D', 45, 38, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5070', '1', '2018-2019', 'BEED', 'GE413', 'Prep & Eval of Instruc Materials', 3, '', '14:00:00', '15:00:00', 'FG302', 'D', 45, 39, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5071', '1', '2018-2019', 'BEED', 'ENGL433', 'Masterpiece of the world', 3, '', '15:00:00', '16:00:00', 'FG302', 'D', 45, 38, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5072', '1', '2018-2019', 'BEED', 'TSG3', 'Teching Strategies (Mapeh/HE)', 3, '', '17:00:00', '18:00:00', 'FG302', 'D', 45, 34, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5073', '1', '2018-2019', 'BEED', 'FS411', 'Learning Assessment Strategies', 1, '', '07:00:00', '08:00:00', 'EM306', 'T', 45, 7, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5074', '1', '2018-2019', 'BEED', 'FS431', 'On becoming a Teacher', 1, '', '07:00:00', '08:00:00', 'EM306', 'T', 45, 7, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5075', '1', '2018-2019', 'BEED', 'DEVRDG413', 'Developmental Reading 2', 3, '', '13:00:00', '14:00:00', 'FG512', 'D', 45, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5076', '1', '2018-2019', 'BEED', 'NATSC313', 'Ecology', 3, '', '15:00:00', '16:00:00', 'FG402', 'D', 45, 15, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5077', '1', '2018-2019', 'BEED', 'MATH308', 'Problem Solving in Math', 3, '', '17:00:00', '18:00:00', 'FG512', 'D', 45, 7, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5078', '1', '2018-2019', 'BEED', 'ST400', 'Seminar on Special Topics', 3, '', '19:00:00', '20:00:00', 'EM306', 'D', 45, 9, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5079', '1', '2018-2019', 'BEED', 'HE413', 'Home Economics & Livelihood Ed.', 3, '', '15:00:00', '16:00:00', 'FG403', 'D', 45, 16, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5080', '1', '2018-2019', 'BEED', 'GE413', 'Prep & Eval of Instruc Materials', 3, '', '18:00:00', '19:00:00', 'FG512', 'D', 45, 15, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5081', '1', '2018-2019', 'BEED', 'ENGL433', 'Masterpiece of the world', 3, '', '16:00:00', '17:00:00', 'FG403', 'D', 45, 9, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5082', '1', '2018-2019', 'BEED', 'TSG3', 'Teching Strategies (Mapeh/HE)', 3, '', '17:00:00', '18:00:00', 'FG512', 'D', 45, 15, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5083', '1', '2018-2019', 'BEED', 'FS411', 'Learning Assessment Strategies', 1, '', '08:00:00', '09:00:00', 'EM306', 'M', 45, 5, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5084', '1', '2018-2019', 'BEED', 'FS431', 'On becoming a Teacher', 1, '', '08:00:00', '09:00:00', 'EM306', 'M', 45, 5, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5085', '1', '2018-2019', 'BEED', 'MATH308', 'Problem Solving in Math', 3, '', '16:00:00', '17:00:00', 'FG303', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5086', '1', '2018-2019', 'BEED', 'DEVRDG413', 'Developmental Reading 2', 3, '', '17:00:00', '18:00:00', 'FG303', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5087', '1', '2018-2019', 'BEED', 'NATSC313', 'Ecology', 3, '', '18:00:00', '19:00:00', 'FG303', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5088', '1', '2018-2019', 'BEED', 'ST400', 'Seminar on Special Topics', 3, '', '19:00:00', '20:00:00', 'EM306', 'D', 45, 7, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5089', '1', '2018-2019', 'BEED', 'GE413', 'Prep & Eval of Instruc Materials', 3, '', '18:00:00', '19:00:00', 'FG303', 'D', 45, 6, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5090', '1', '2018-2019', 'BEED', 'ENGL433', 'Masterpiece of the world', 3, '', '17:00:00', '18:00:00', 'FG303', 'D', 45, 14, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5091', '1', '2018-2019', 'BEED', 'HE413', 'Home Economics & Livelihood Ed.', 3, '', '16:00:00', '17:00:00', 'FG303', 'D', 45, 7, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5092', '1', '2018-2019', 'BEED', 'TSG3', 'Teching Strategies (Mapeh/HE)', 3, '', '20:00:00', '21:00:00', 'FG303', 'D', 45, 5, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4070', '1', '2018-2019', 'BSCE', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4071', '1', '2018-2019', 'BSCE', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG604', 'S', 50, 41, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5775', '1', '2018-2019', 'BPE', 'GE101', 'Purposive Communication', 3, '', '13:00:00', '14:00:00', 'FG513', 'D', 45, 45, 1, '0000-00-00', '11:33:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5776', '1', '2018-2019', 'BPE', 'GE301', 'Art Appreciation', 3, '', '14:00:00', '15:00:00', 'FG513', 'D', 45, 45, 1, '0000-00-00', '11:33:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5777', '1', '2018-2019', 'BPE', 'GE501', 'Science, Technology and Society', 3, '', '15:00:00', '16:00:00', 'FG513', 'D', 45, 45, 1, '0000-00-00', '11:33:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5778', '1', '2018-2019', 'BPE', 'SCF1', 'Philosopical and Socioanthropological Foundation of Physical Education and Sports', 3, '', '11:00:00', '12:00:00', 'FG512', 'D', 45, 45, 1, '0000-00-00', '13:35:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5779', '1', '2018-2019', 'BPE', 'SCF2', 'Anatomy and Physiology of Human Movement', 3, '', '10:00:00', '11:00:00', 'FG512', 'D', 45, 45, 1, '0000-00-00', '13:35:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5780', '1', '2018-2019', 'BPE', 'PCFB1', 'The Child and Adolescent Learners and Learning Principles', 3, '', '09:00:00', '10:00:00', 'FG512', 'D', 45, 45, 1, '0000-00-00', '13:35:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5781', '1', '2018-2019', 'BPE', 'PE1', 'Movement Enhancement', 2, '', '08:00:00', '10:00:00', 'PC', 'S', 50, 47, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5782', '1', '2018-2019', 'BPE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'AG202', 'S', 45, 45, 1, '0000-00-00', '11:36:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5783', '1', '2018-2019', 'BPE', 'GE101', 'Purposive Communication', 3, '', '13:00:00', '14:00:00', 'FG513', 'D', 45, 45, 1, '0000-00-00', '14:40:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5784', '1', '2018-2019', 'BPE', 'GE301', 'Art Appreciation', 3, '', '14:00:00', '15:00:00', 'FG513', 'D', 45, 45, 1, '0000-00-00', '14:40:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5785', '1', '2018-2019', 'BPE', 'GE501', 'Science, Technology and Society', 3, '', '15:00:00', '16:00:00', 'FG513', 'D', 45, 45, 1, '0000-00-00', '14:40:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5786', '1', '2018-2019', 'BPE', 'SCF1', 'Philosopical and Socioanthropological Foundation of Physical Education and Sports', 3, '', '10:00:00', '11:00:00', 'FG403', 'D', 45, 45, 1, '0000-00-00', '14:40:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5787', '1', '2018-2019', 'BPE', 'SCF2', 'Anatomy and Physiology of Human Movement', 3, '', '09:00:00', '10:00:00', 'FG402', 'D', 45, 45, 1, '0000-00-00', '14:40:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5788', '1', '2018-2019', 'BPE', 'PCFB1', 'The Child and Adolescent Learners and Learning Principles', 3, '', '11:00:00', '12:00:00', 'FG409', 'D', 45, 45, 1, '0000-00-00', '14:40:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5789', '1', '2018-2019', 'BPE', 'PE1', 'Movement Enhancement', 2, '', '08:00:00', '10:00:00', 'PC', 'S', 50, 45, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5790', '1', '2018-2019', 'BPE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'AG205', 'S', 45, 45, 1, '0000-00-00', '14:40:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5791', '1', '2018-2019', 'BPE', 'GE101', 'Purposive Communication', 3, '', '09:00:00', '10:00:00', 'FG604', 'D', 30, 30, 1, '0000-00-00', '14:10:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5792', '1', '2018-2019', 'BPE', 'GE301', 'Art Appreciation', 3, '', '11:00:00', '12:00:00', 'FG410', 'D', 45, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5793', '1', '2018-2019', 'BPE', 'GE501', 'Science, Technology and Society', 3, '', '07:00:00', '08:00:00', 'FG405', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5093', '1', '2018-2019', 'BEED', 'GE101', 'Purposive Communication', 3, '', '07:00:00', '08:00:00', 'FG410', 'D', 45, 42, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5094', '1', '2018-2019', 'BEED', 'GE301', 'Art Appreciation', 3, '', '08:00:00', '09:00:00', 'FG410', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5095', '1', '2018-2019', 'BEED', 'GE501', 'Science, Technology and Society', 3, '', '10:00:00', '11:00:00', 'FG403', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5096', '1', '2018-2019', 'BEED', 'GE204', 'Ethics', 3, '', '11:00:00', '12:00:00', 'FG403', 'D', 45, 42, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5097', '1', '2018-2019', 'BEED', 'GE206', 'Gender and Society', 3, '', '07:00:00', '08:00:00', 'FG303', 'D', 45, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5098', '1', '2018-2019', 'BEED', 'GE503', 'Living in the IT Era', 3, '', '11:00:00', '12:00:00', 'COMC', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5099', '1', '2018-2019', 'BEED', 'PCFG1/PCFC1', 'The Child and Adolescent Learning Principles', 3, '', '08:00:00', '09:00:00', 'FG303', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5100', '1', '2018-2019', 'BEED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 42, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5101', '1', '2018-2019', 'BEED', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '10:30:00', 'RA118', 'S', 50, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5102', '1', '2018-2019', 'BEED', 'PRSG1', 'Principles of Teaching', 3, '', '10:00:00', '11:00:00', 'FG405', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5447', '1', '2018-2019', 'BEED', 'EL100', 'Introduction to Linnguistics', 3, '', '10:00:00', '11:00:00', 'FG205', 'D', 45, 45, 1, '0000-00-00', '13:40:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5448', '1', '2018-2019', 'BEED', 'EL101', 'Language, Culture and Society', 3, '', '10:00:00', '11:00:00', 'FG513', 'D', 45, 45, 1, '0000-00-00', '13:36:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5449', '1', '2018-2019', 'BEED', 'EL102', 'Structure of English', 3, '', '13:00:00', '14:00:00', 'FG405', 'D', 45, 45, 1, '0000-00-00', '13:36:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5450', '1', '2018-2019', 'BEED', 'GE101', 'Purposive Communication', 3, '', '09:00:00', '10:00:00', 'FG205', 'D', 45, 45, 1, '0000-00-00', '13:36:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5451', '1', '2018-2019', 'BEED', 'GE301', 'Art Appreciation', 3, '', '13:00:00', '14:00:00', 'FG405', 'D', 45, 45, 1, '0000-00-00', '13:36:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5452', '1', '2018-2019', 'BEED', 'GE501', 'Science, Technology and Society', 3, '', '09:00:00', '10:00:00', 'FG513', 'D', 45, 45, 1, '0000-00-00', '13:36:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5453', '1', '2018-2019', 'BEED', 'GE204', 'Ethics', 3, '', '12:00:00', '13:00:00', 'FG403', 'D', 45, 45, 1, '0000-00-00', '13:36:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5454', '1', '2018-2019', 'BEED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'F', 50, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5455', '1', '2018-2019', 'BEED', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'RA118', 'S', 50, 42, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5456', '1', '2018-2019', 'BEED', 'PRSE7', 'Technical Correspondence', 3, '', '11:00:00', '12:00:00', 'FG205', 'D', 45, 44, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5459', '1', '2018-2019', 'BEED', 'GE501', 'Science, Technology and Society', 3, '', '12:00:00', '13:00:00', 'FG406', 'D', 45, 39, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5460', '1', '2018-2019', 'BEED', 'GE204', 'Ethics', 3, '', '13:00:00', '14:00:00', 'FG406', 'D', 45, 38, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5461', '1', '2018-2019', 'BEED', 'GE206', 'Gender and Society', 3, '', '09:00:00', '10:00:00', 'FG406', 'D', 45, 38, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5462', '1', '2018-2019', 'BEED', 'GE503', 'Living in the IT Era', 3, '', '10:00:00', '11:00:00', 'COMB', 'D', 45, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5463', '1', '2018-2019', 'BEED', 'PCFF1', 'The Child and Adolescent Learning Principles', 3, '', '13:00:00', '14:00:00', 'FG406', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5464', '1', '2018-2019', 'BEED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'F', 50, 38, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5465', '1', '2018-2019', 'BEED', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'RA119', 'S', 50, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5467', '1', '2018-2019', 'BSED', 'M100', 'History of Mathematics', 3, '', '07:00:00', '08:00:00', 'FG405', 'D', 45, 25, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5468', '1', '2018-2019', 'BSED', 'M101', 'College and Advance A;gebra', 3, '', '08:00:00', '09:00:00', 'FG405', 'D', 45, 23, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5469', '1', '2018-2019', 'BSED', 'M105', 'Elementary Statistics and Probability', 3, '', '08:00:00', '09:00:00', 'FG405', 'D', 45, 23, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5470', '1', '2018-2019', 'BSED', 'GE204', 'Ethics', 3, '', '10:00:00', '11:00:00', 'FG405', 'D', 45, 23, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5471', '1', '2018-2019', 'BSED', 'GE101', 'Purposive Communication', 3, '', '11:00:00', '12:00:00', 'FG513', 'D', 45, 34, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5474', '1', '2018-2019', 'BSED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 49, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5475', '1', '2018-2019', 'BSED', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'RA119', 'S', 50, 46, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5476', '1', '2018-2019', 'BSED', 'CHEM1.0', 'Inorganic Chemistry Lecture', 3, '', '10:00:00', '11:00:00', 'CLAB', 'D', 45, 8, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5477', '1', '2018-2019', 'BSED', 'CHEM1.1', 'Inorganic Chemistry Lab', 2, '', '11:00:00', '12:00:00', 'CLAB', 'D', 45, 9, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5478', '1', '2018-2019', 'BSED', 'SCI1', 'Earth Sciences', 3, '', '08:00:00', '09:00:00', 'FG406', 'D', 45, 8, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5479', '1', '2018-2019', 'BSED', 'PRSS9', 'Mechanics', 3, '', '08:00:00', '09:00:00', 'FG410', 'D', 45, 8, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5104', '1', '2018-2019', 'BSED', 'GE301', 'Art Appreciation', 3, '', '14:00:00', '15:00:00', 'FG403', 'D', 45, 1, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5105', '1', '2018-2019', 'BSED', 'GE501', 'Science, Technology and Society', 3, '', '16:00:00', '17:00:00', 'FG405', 'D', 45, 1, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5106', '1', '2018-2019', 'BSED', 'GE204', 'Ethics', 3, '', '17:00:00', '18:00:00', 'FG405', 'D', 45, 0, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5107', '1', '2018-2019', 'BSED', 'GE206', 'Gender and Society', 3, '', '14:00:00', '15:00:00', 'FG405', 'D', 45, 0, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5108', '1', '2018-2019', 'BSED', 'GE503', 'Living in the IT Era', 3, '', '15:00:00', '16:00:00', 'COMC', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5109', '1', '2018-2019', 'BSED', 'PCFG1/PCFC1', 'The Child and Adolescent Learning Principles', 3, '', '12:00:00', '13:00:00', 'FG402', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5110', '1', '2018-2019', 'BEED', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5111', '1', '2018-2019', 'BEDU', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'RA120', 'S', 50, 0, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8099', '1', '2018-2019', 'GEN', 'GE201', 'Undestanding the Self', 3, '', '07:00:00', '09:30:00', 'RA121', 'S', 50, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8100', '1', '2018-2019', 'GEN', 'GE205', 'Life and Works of Rizal', 3, '', '09:30:00', '12:00:00', 'RA121', 'S', 50, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8101', '1', '2018-2019', 'GEN', 'ECON101', 'Basic Microeconomics', 3, '', '12:30:00', '15:00:00', 'RA121', 'S', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8102', '1', '2018-2019', 'GEN', 'MKTG1', 'Principles of Marketing', 3, '', '15:00:00', '17:30:00', 'RA121', 'S', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '8103', '1', '2018-2019', 'GEN', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'U', 50, 18, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8104', '1', '2018-2019', 'GEN', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'FG405', 'U', 45, 17, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8105', '1', '2018-2019', 'GEN', 'GE202', 'Reading in Philippine History', 3, '', '12:00:00', '14:30:00', 'FG405', 'U', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8106', '1', '2018-2019', 'GEN', 'MGT1', 'Principles of Management', 3, '', '14:30:00', '17:00:00', 'FG405', 'U', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '8107', '1', '2018-2019', 'GEN', 'GE203', 'The Contemporary World', 3, '', '17:00:00', '19:30:00', 'FG405', 'U', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '2030', '1', '2018-2019', 'GEN', 'SWP1', 'Knowledge & Philosophical Foundation of the Social Work Profession', 3, '', '12:30:00', '15:00:00', 'AG210', 'S', 37, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '2031', '1', '2018-2019', 'GEN', 'GE401', 'Mathematics in the Modern World', 3, '', '15:00:00', '17:30:00', 'AG210', 'S', 37, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7078', '1', '2018-2019', 'GEN', 'ROTC1', 'Military Science 11 & 12', 3, '', '13:00:00', '17:00:00', 'FL03', 'S', 150, 150, 1, '0000-00-00', '14:36:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7079', '1', '2018-2019', 'GEN', 'GE401', 'Mathematics in the Modern World', 3, '', '17:00:00', '19:30:00', 'FG312', 'S', 45, 3, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7080', '1', '2018-2019', 'GEN', 'DEFTAC1', 'Fundamentals of Martial Arts', 2, '', '06:00:00', '08:00:00', 'FL01', 'U', 120, 120, 1, '0000-00-00', '16:09:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'DE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7081', '1', '2018-2019', 'GEN', 'CRIM1', 'Introduction to Criminology', 3, '', '08:00:00', '10:30:00', 'FG406', 'U', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL);
INSERT INTO `subjectssem120182019` (`OPEN`, `BLOCK`, `DISSOLVED`, `TERM`, `CN`, `SEM`, `SY`, `COURSE`, `SUBJECT`, `DESC`, `UNIT`, `CREDIT`, `TSTART`, `TEND`, `ROOM`, `SK`, `LIMIT`, `ENROLLED`, `CLOSED`, `CDATE`, `CTIME`, `LAB`, `AIR`, `MOD`, `C1`, `C2`, `C3`, `C4`, `PRN`, `AFLAG`, `DEPT`, `DEPARTMENT`, `PROGRAM`, `MAJOR`, `EMP_DP`, `EMP_NO`, `INSTRUCTOR`, `SSERVICE`, `SFCODE`, `STYPE`, `STP`, `NRLD`) VALUES
(1, 0, NULL, '3', '7084', '1', '2018-2019', 'GEN', 'CHEM1', 'General Chemistry', 3, '', '14:30:00', '17:00:00', 'FG406', 'U', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5457', '1', '2018-2019', 'BSED', 'GE101', 'Purposive Communication', 3, '', '15:00:00', '16:00:00', 'FG406', 'D', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5458', '1', '2018-2019', 'BSED', 'GE301', 'Art Appreciation', 3, '', '14:00:00', '15:00:00', 'FG406', 'D', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5472', '1', '2018-2019', 'BSED', 'GE301', 'Art Appreciation', 3, '', '12:00:00', '13:00:00', 'FG405', 'D', 45, 32, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5473', '1', '2018-2019', 'BSED', 'GE501', 'Science, Technology and Society', 3, '', '12:00:00', '13:00:00', 'FG405', 'D', 45, 33, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5480', '1', '2018-2019', 'BSED', 'PCFS1', 'The Child and Adolescent Learning Principles', 3, '', '07:00:00', '08:00:00', 'FG406', 'D', 45, 8, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5103', '1', '2018-2019', 'BEED', 'GE101', 'Purposive Communication', 3, '', '12:00:00', '13:00:00', 'FG406', 'D', 45, 9, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5112', '1', '2018-2019', 'BEED', 'PRSG1', 'Principles of Teaching', 3, '', '16:00:00', '17:00:00', 'FG403', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0029', '1', '2018-2019', 'CLA', 'LIT1', 'Literature of the Philippines', 3, '', '08:00:00', '09:00:00', 'AG214', 'D', 37, 30, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0030', '1', '2018-2019', 'CLA', 'LIT1', 'Literature of the Philippines', 3, '', '13:00:00', '14:00:00', 'AG214', 'D', 37, 3, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0031', '1', '2018-2019', 'CLA', 'LIT1', 'Literature of the Philippines', 3, '', '10:00:00', '11:00:00', 'AG214', 'D', 37, 25, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1040', '1', '2018-2019', 'ITE', 'GE101', 'Purposive Communication', 3, '', '14:00:00', '15:00:00', 'EM202', 'D', 45, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1041', '1', '2018-2019', 'ITE', 'GE302', 'Indigenous Creative Crafts', 3, '', '14:00:00', '15:00:00', 'EM202', 'D', 45, 8, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1042', '1', '2018-2019', 'ITE', 'GE204', 'Ethics', 3, '', '15:00:00', '16:00:00', 'EM202', 'D', 45, 8, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1043', '1', '2018-2019', 'ITE', 'GE502', 'Enviromental Science', 3, '', '15:00:00', '16:00:00', 'EM202', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1044', '1', '2018-2019', 'ITE', 'LIT1', 'Literature of the Philippines', 3, '', '16:00:00', '17:00:00', 'FG409', 'D', 45, 2, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1045', '1', '2018-2019', 'ITE', 'LIS101', 'Introduction to Library and Information Science', 3, '', '17:00:00', '18:00:00', 'RA123', 'D', 45, 2, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1046', '1', '2018-2019', 'ITE', 'SPT101', 'School/Academic Librianship', 3, '', '17:00:00', '18:00:00', 'RA123', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1047', '1', '2018-2019', 'ITE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1048', '1', '2018-2019', 'ITE', 'CWTS1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'RA120', 'S', 50, 6, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1104', '1', '2018-2019', 'ITE', 'CC101', 'Introduction to Computing', 3, '', '10:00:00', '12:00:00', 'EM201', 'M', 40, 40, 1, '0000-00-00', '15:47:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1105', '1', '2018-2019', 'ITE', 'CC102', 'Computer Programming 1', 3, '', '10:00:00', '12:00:00', 'EM201', 'W', 40, 40, 1, '0000-00-00', '15:47:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4073', '1', '2018-2019', 'BSCE', 'GE501', 'Science, Technology and Society', 3, '', '20:00:00', '21:00:00', 'EM301', 'D', 50, 41, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4072', '1', '2018-2019', 'BSCE', 'MATH100', 'Precalculus', 6, '', '18:00:00', '20:00:00', 'EM301', 'D', 50, 41, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '4074', '1', '2018-2019', 'BSCE', 'GE401', 'Mathematics in the Modern World', 3, '', '16:00:00', '17:00:00', 'EM301', 'D', 50, 40, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4077', '1', '2018-2019', 'BSCE', 'BES112', 'Civil Engineering Orientation', 2, '', '17:00:00', '18:00:00', 'EM301', 'M-H', 50, 42, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4075', '1', '2018-2019', 'BSCE', 'MATH114', 'Calculus 1', 4, '', '17:00:00', '19:00:00', 'EM301', 'M-H', 50, 41, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4076', '1', '2018-2019', 'BSCE', 'CHEM114', 'Chemistry For Engineers', 4, '', '19:00:00', '21:00:00', 'EM301', 'D', 50, 41, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '4078', '1', '2018-2019', 'BSCE', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4079', '1', '2018-2019', 'BSCE', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'RA127', 'S', 50, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5794', '1', '2018-2019', 'BPE', 'GE101', 'Purposive Communication', 3, '', '12:00:00', '13:00:00', 'FG513', 'D', 45, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5795', '1', '2018-2019', 'BPE', 'GE301', 'Art Appreciation', 3, '', '07:00:00', '08:00:00', 'FG410', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5796', '1', '2018-2019', 'BPE', 'GE501', 'Science, Technology and Society', 3, '', '08:00:00', '09:00:00', 'FG406', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5797', '1', '2018-2019', 'BPE', 'SCF1', 'Philosopical and Socioanthropological Foundation of Physical Education and Sports', 3, '', '10:00:00', '11:00:00', 'FG406', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5798', '1', '2018-2019', 'BPE', 'SCF2', 'Anatomy and Physiology of Human Movement', 3, '', '11:00:00', '12:00:00', 'FG405', 'D', 45, 45, 1, '0000-00-00', '11:38:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5799', '1', '2018-2019', 'BPE', 'PCFB1', 'The Child and Adolescent Learners and Learning Principles', 3, '', '12:00:00', '13:00:00', 'FG409', 'D', 45, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5800', '1', '2018-2019', 'BPE', 'PE1', 'Movement Enhancement', 2, '', '08:00:00', '10:00:00', 'PC', 'S', 50, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5801', '1', '2018-2019', 'BPE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'RA127', 'S', 50, 45, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5802', '1', '2018-2019', 'BPE', 'GE101', 'Purposive Communication', 3, '', '12:00:00', '13:00:00', 'FG512', 'D', 45, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5803', '1', '2018-2019', 'BPE', 'GE301', 'Art Appreciation', 3, '', '07:00:00', '08:00:00', 'FG406', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5804', '1', '2018-2019', 'BPE', 'GE501', 'Science, Technology and Society', 3, '', '08:00:00', '09:00:00', 'FG512', 'D', 45, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5805', '1', '2018-2019', 'BPE', 'SCF1', 'Philosopical and Socioanthropological Foundation of Physical Education and Sports', 3, '', '11:00:00', '12:00:00', 'FG405', 'D', 45, 42, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5806', '1', '2018-2019', 'BPE', 'SCF2', 'Anatomy and Physiology of Human Movement', 3, '', '08:00:00', '09:00:00', 'FG512', 'D', 45, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5807', '1', '2018-2019', 'BPE', 'PCFB1', 'The Child and Adolescent Learners and Learning Principles', 3, '', '12:00:00', '13:00:00', 'FG205', 'D', 45, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5808', '1', '2018-2019', 'BPE', 'PE1', 'Movement Enhancement', 2, '', '08:00:00', '10:00:00', 'PC', 'S', 50, 42, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5809', '1', '2018-2019', 'BPE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'RA128', 'S', 50, 39, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5600', '1', '2018-2019', 'BPE', 'GE101', 'Purposive Communication', 3, '', '15:00:00', '16:00:00', 'FG410', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5601', '1', '2018-2019', ' BTL', 'GE301', 'Art Appreciation', 3, '', '14:00:00', '15:00:00', 'FG410', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5602', '1', '2018-2019', 'BTLE', 'GE501', 'Science, Technology and Society', 3, '', '16:00:00', '17:00:00', 'FG512', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5603', '1', '2018-2019', 'BTLE', 'GE204', 'Ethics', 3, '', '07:00:00', '08:00:00', 'FG512', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5604', '1', '2018-2019', 'BTLE', 'GE206', 'Gender and Society', 3, '', '11:00:00', '12:00:00', 'FG402', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5605', '1', '2018-2019', 'BTLE', 'GE503', 'Living in the IT Era', 3, '', '08:00:00', '09:00:00', 'FG513', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5606', '1', '2018-2019', 'BTLE', 'PCFH1', 'The Child and Adolescent Learning Principles', 3, '', '12:00:00', '13:00:00', 'FG513', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5607', '1', '2018-2019', 'BTLE', 'PE1', 'Movement Enhancement', 2, '', '08:00:00', '10:00:00', 'PC', 'S', 50, 9, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5608', '1', '2018-2019', 'BTLE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'RA129', 'S', 37, 8, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0032', '1', '2018-2019', 'CLA', 'ITC111', 'IT Fundamentals', 3, '', '08:00:00', '09:00:00', 'COMB', 'D', 40, 40, 1, '0000-00-00', '15:16:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0033', '1', '2018-2019', 'CLA', 'PSY101', 'Introduction to Psychology', 3, '', '10:00:00', '11:00:00', 'AG207', 'D', 45, 38, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '1049', '1', '2018-2019', 'ITE', 'GE101', 'Purposive Communication', 3, '', '13:00:00', '14:00:00', 'EM202', 'D', 45, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1050', '1', '2018-2019', 'ITE', 'GE302', 'Indigenous Creative Crafts', 3, '', '13:00:00', '14:00:00', 'EM202', 'D', 45, 45, 1, '0000-00-00', '11:41:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1051', '1', '2018-2019', 'ITE', 'GE204', 'Ethics', 3, '', '14:00:00', '15:00:00', 'FG302', 'D', 45, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1052', '1', '2018-2019', 'ITE', 'GE502', 'Enviromental Science', 3, '', '14:00:00', '15:00:00', 'FG406', 'D', 45, 43, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1053', '1', '2018-2019', 'ITE', 'CC101', 'Introduction to Computing', 3, '', '16:00:00', '19:00:00', 'COMA', 'T', 40, 41, 1, '0000-00-00', '11:42:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1054', '1', '2018-2019', 'ITE', 'CC102', 'Computer Programming 1', 3, '', '16:00:00', '19:00:00', 'COMA', 'H', 40, 41, 1, '0000-00-00', '11:42:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1055', '1', '2018-2019', 'ITE', 'PE1', 'Movement Enhancement', 2, '', '08:00:00', '10:00:00', 'PC', 'S', 50, 42, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1056', '1', '2018-2019', 'ITE', 'CWTS1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'RA215', 'S', 50, 42, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5115', '1', '2018-2019', 'BEED', 'FS411', 'Learning Assessment Strategies', 1, '', '08:00:00', '09:00:00', 'EM306', 'T', 45, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5116', '1', '2018-2019', 'BEED', 'FS431', 'On becoming a Teacher', 1, '', '08:00:00', '09:00:00', 'EM306', 'T', 45, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5117', '1', '2018-2019', 'BEED', 'GE413', 'Prep & Eval of Instruc Materials', 3, '', '17:00:00', '18:00:00', 'FG405', 'D', 45, 7, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5118', '1', '2018-2019', 'BEED', 'ENGL433', 'Masterpiece of the world', 3, '', '16:00:00', '17:00:00', 'FG405', 'D', 45, 11, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5119', '1', '2018-2019', 'BEED', 'HE413', 'Home Economics & Livelihood Ed.', 3, '', '20:00:00', '21:00:00', 'FG405', 'D', 45, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5120', '1', '2018-2019', 'BEED', 'MATH308', 'Problem Solving in Math', 3, '', '16:00:00', '17:00:00', 'FG512', 'D', 45, 5, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5121', '1', '2018-2019', 'BEED', 'DEVRDG413', 'Developmental Reading 2', 3, '', '18:00:00', '19:00:00', 'FG405', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5122', '1', '2018-2019', 'BEED', 'NATSC313', 'Ecology', 3, '', '19:00:00', '20:00:00', 'FG405', 'D', 45, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5123', '1', '2018-2019', 'BEED', 'ST400', 'Seminar on Special Topics', 3, '', '18:00:00', '19:00:00', 'EM306', 'D', 45, 5, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5124', '1', '2018-2019', 'BEED', 'TSG3', 'Teching Strategies (Mapeh/HE)', 3, '', '20:00:00', '21:00:00', 'FG405', 'D', 45, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5125', '1', '2018-2019', 'BEED', 'FS411', 'Learning Assessment Strategies', 1, '', '08:00:00', '09:00:00', 'EM306', 'W', 45, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5126', '1', '2018-2019', 'BEED', 'FS431', 'On becoming a Teacher', 1, '', '08:00:00', '09:00:00', 'EM306', 'W', 45, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5127', '1', '2018-2019', 'BEED', 'HE413', 'Home Economics & Livelihood Ed.', 3, '', '17:00:00', '18:00:00', 'FG406', 'D', 45, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5128', '1', '2018-2019', 'BEED', 'GE413', 'Prep & Eval of Instruc Materials', 3, '', '16:00:00', '17:00:00', 'FG406', 'D', 45, 10, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5129', '1', '2018-2019', 'BEED', 'ENGL433', 'Masterpiece of the world', 3, '', '15:00:00', '16:00:00', 'FG403', 'D', 45, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5130', '1', '2018-2019', 'BEED', 'NATSC313', 'Ecology', 3, '', '16:00:00', '17:00:00', 'FG406', 'D', 45, 16, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5131', '1', '2018-2019', 'BEED', 'ST400', 'Seminar on Special Topics', 3, '', '18:00:00', '19:00:00', 'EM306', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5132', '1', '2018-2019', 'BEED', 'MATH308', 'Problem Solving in Math', 3, '', '17:00:00', '18:00:00', 'FG406', 'D', 45, 12, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5133', '1', '2018-2019', 'BEED', 'DEVRDG413', 'Developmental Reading 2', 3, '', '19:00:00', '20:00:00', 'FG402', 'D', 45, 8, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5134', '1', '2018-2019', 'BEED', 'TSG3', 'Teching Strategies (Mapeh/HE)', 3, '', '19:00:00', '20:00:00', 'FG513', 'D', 45, 10, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5135', '1', '2018-2019', 'BEED', 'FS411', 'Learning Assessment Strategies', 1, '', '07:00:00', '08:00:00', 'EM306', 'W', 45, 25, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5136', '1', '2018-2019', 'BEED', 'FS431', 'On becoming a Teacher', 1, '', '07:00:00', '08:00:00', 'EM306', 'W', 45, 25, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5137', '1', '2018-2019', 'BEED', 'DEVRDG413', 'Developmental Reading 2', 3, '', '07:00:00', '09:30:00', 'RA129', 'S', 37, 22, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5138', '1', '2018-2019', 'BEED', 'NATSC313', 'Ecology', 3, '', '09:30:00', '12:00:00', 'FG409', 'U', 45, 29, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5139', '1', '2018-2019', 'BEED', 'MATH308', 'Problem Solving in Math', 3, '', '15:30:00', '18:00:00', 'RA214', 'S', 50, 30, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5140', '1', '2018-2019', 'BEED', 'ST400', 'Seminar on Special Topics', 3, '', '13:00:00', '15:30:00', 'EM306', 'S', 45, 26, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5141', '1', '2018-2019', 'BEED', 'HE413', 'Home Economics & Livelihood Ed.', 3, '', '07:00:00', '09:30:00', 'FG409', 'U', 45, 30, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5142', '1', '2018-2019', 'BEED', 'GE413', 'Prep & Eval of Instruc Materials', 3, '', '13:00:00', '15:30:00', 'FG409', 'U', 45, 28, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5143', '1', '2018-2019', 'BEED', 'ENGL433', 'Masterpiece of the world', 3, '', '15:30:00', '18:00:00', 'FG409', 'U', 45, 26, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5144', '1', '2018-2019', 'BEED', 'TSG3', 'Teching Strategies (Mapeh/HE)', 3, '', '09:30:00', '12:00:00', 'RA129', 'S', 37, 25, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5481', '1', '2018-2019', 'BEED', 'FS411', 'Learning Assessment Strategies', 1, '', '07:00:00', '08:00:00', 'EM306', 'M', 45, 13, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5482', '1', '2018-2019', 'BSED', 'FS431', 'On becoming a Teacher', 1, '', '07:00:00', '08:00:00', 'EM306', 'M', 45, 13, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5483', '1', '2018-2019', 'BSED', 'ST400', 'Seminar on Multicultural Teaching', 3, '', '20:00:00', '21:00:00', 'EM306', 'D', 45, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5484', '1', '2018-2019', 'BSED', 'ENGL413', 'Language curr. for sec.sch', 3, '', '16:00:00', '17:00:00', 'FG410', 'D', 45, 11, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5485', '1', '2018-2019', 'BSED', 'ENGL453', 'Intro to stylistics', 3, '', '17:00:00', '18:00:00', 'FG205', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5486', '1', '2018-2019', 'BSED', 'ENGL473', 'Translation and Editing of text', 3, '', '18:00:00', '19:00:00', 'FG205', 'D', 45, 11, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5487', '1', '2018-2019', 'BSED', 'ENGL493', 'Afro-Asian Literature', 3, '', '16:00:00', '17:00:00', 'FG513', 'D', 45, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5488', '1', '2018-2019', 'BSED', 'ENGL494', 'Teaching Literature', 3, '', '17:00:00', '18:00:00', 'FG513', 'D', 45, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5489', '1', '2018-2019', 'BSED', 'ENGL495', 'Preparation of instructional materials', 3, '', '18:00:00', '19:00:00', 'FG513', 'D', 45, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '5490', '1', '2018-2019', 'BSED', 'ENGL496', 'Campus Journalism', 3, '', '19:00:00', '20:00:00', 'FG513', 'D', 45, 9, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5491', '1', '2018-2019', 'BSED', 'FS411', 'Learning Assessment Strategies', 1, '', '08:00:00', '09:00:00', 'EM306', 'T', 45, 14, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5492', '1', '2018-2019', 'BSED', 'FS431', 'On becoming a Teacher', 1, '', '07:00:00', '08:00:00', 'EM306', 'T', 45, 14, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5493', '1', '2018-2019', 'BSED', 'ENGL453', 'Intro to stylistics', 3, '', '20:00:00', '21:00:00', 'FG402', 'D', 45, 17, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5494', '1', '2018-2019', 'BSED', 'ENGL473', 'Translation and Editing of text', 3, '', '17:00:00', '18:00:00', 'RA118', 'D', 50, 17, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5495', '1', '2018-2019', 'BSED', 'ENGL413', 'Language curr. for sec.sch', 3, '', '19:00:00', '20:00:00', 'FG402', 'D', 45, 19, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5496', '1', '2018-2019', 'BSED', 'ST400', 'Seminar on Special Topics', 3, '', '07:00:00', '08:00:00', 'EM306', 'D', 45, 16, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5497', '1', '2018-2019', 'BSED', 'ENGL495', 'Preparation of instructional materials', 3, '', '16:00:00', '17:00:00', 'FG205', 'D', 45, 25, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '5498', '1', '2018-2019', 'BSED', 'ENGL496', 'Campus Journalism', 3, '', '17:00:00', '18:00:00', 'FG205', 'D', 45, 15, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5499', '1', '2018-2019', 'BSED', 'ENGL493', 'Afro-Asian Literature', 3, '', '19:00:00', '20:00:00', 'FG205', 'D', 45, 16, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5500', '1', '2018-2019', 'BSED', 'ENGL494', 'Teaching Literature', 3, '', '20:00:00', '21:00:00', 'FG205', 'D', 45, 15, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5501', '1', '2018-2019', 'BSED', 'EDUC400', 'Practice Teaching', 6, '', '11:00:00', '12:00:00', 'EM306', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5502', '1', '2018-2019', 'BSED', 'FS411', 'Learning Assessment Strategies', 1, '', '07:00:00', '08:00:00', 'EM306', 'W', 45, 25, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5503', '1', '2018-2019', 'BSED', 'FS431', 'On becoming a Teacher', 1, '', '07:00:00', '08:00:00', 'EM306', 'W', 45, 25, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5504', '1', '2018-2019', 'BSED', 'ST400', 'Seminar on Special Topics', 3, '', '20:00:00', '21:00:00', 'EM306', 'D', 45, 20, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5505', '1', '2018-2019', 'BSED', 'ENGL413', 'Language curr. for sec.sch', 3, '', '18:00:00', '19:00:00', 'RA119', 'D', 50, 16, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5506', '1', '2018-2019', 'BSED', 'ENGL453', 'Intro to stylistics', 3, '', '17:00:00', '18:00:00', 'RA119', 'D', 50, 19, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5507', '1', '2018-2019', 'BSED', 'ENGL473', 'Translation and Editing of text', 3, '', '15:00:00', '16:00:00', 'FG405', 'D', 45, 22, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5508', '1', '2018-2019', 'BSED', 'ENGL493', 'Afro-Asian Literature', 3, '', '16:00:00', '17:00:00', 'FG513', 'D', 45, 26, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5509', '1', '2018-2019', 'BSED', 'ENGL494', 'Teaching Literature', 3, '', '17:00:00', '18:00:00', 'RA118', 'D', 50, 24, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5510', '1', '2018-2019', 'BSED', 'ENGL495', 'Preparation of instructional materials', 3, '', '18:00:00', '19:00:00', 'RA118', 'D', 50, 15, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '5511', '1', '2018-2019', 'BSED', 'ENGL496', 'Campus Journalism', 3, '', '14:00:00', '15:00:00', 'FG409', 'D', 45, 23, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5512', '1', '2018-2019', 'BSED', 'FS411', 'Learning Assessment Strategies', 1, '', '08:00:00', '09:00:00', 'EM306', 'M', 45, 24, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5513', '1', '2018-2019', 'BSED', 'FS431', 'On becoming a Teacher', 1, '', '08:00:00', '09:00:00', 'EM306', 'M', 45, 24, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5514', '1', '2018-2019', 'BSED', 'FIL413', 'Paghahanda at Ebalwasyon ng kagamitan', 3, '', '19:00:00', '20:00:00', 'FG406', 'D', 45, 26, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5515', '1', '2018-2019', 'BSED', 'FIL433', 'Ang Fil. Sa Kur. Ng Batayang Eduk', 3, '', '17:00:00', '18:00:00', 'RA120', 'D', 50, 25, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5516', '1', '2018-2019', 'BSED', 'FIL453', 'Pagbasa ng mga obra maestrang pilipino', 3, '', '20:00:00', '21:00:00', 'FG406', 'D', 45, 24, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5517', '1', '2018-2019', 'BSED', 'FIL473', 'Pagpapahalagang Pampanitikan', 3, '', '18:00:00', '19:00:00', 'FG406', 'D', 45, 28, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5518', '1', '2018-2019', 'BSED', 'FIL493', 'Maikling Kwentong Filipino', 3, '', '17:00:00', '18:00:00', 'RA119', 'D', 50, 32, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5519', '1', '2018-2019', 'BSED', 'PEACEED', 'Peace Education', 3, '', '19:00:00', '20:00:00', 'FG406', 'D', 45, 29, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5520', '1', '2018-2019', 'BSED', 'ST400', 'Seminar on Special Topics', 3, '', '07:00:00', '08:00:00', 'EM306', 'D', 45, 21, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5521', '1', '2018-2019', 'BSED', 'FS411', 'Learning Assessment Strategies', 1, '', '08:00:00', '09:00:00', 'EM306', 'T', 45, 17, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5522', '1', '2018-2019', 'BSED', 'FS431', 'On becoming a Teacher', 1, '', '08:00:00', '09:00:00', 'EM306', 'T', 45, 17, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5523', '1', '2018-2019', 'BSED', 'PS413', 'Basic Electronics', 4, '', '17:00:00', '18:00:00', 'RA121', 'D', 50, 8, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5524', '1', '2018-2019', 'BSED', 'PS493', 'BioChemistry', 5, '', '19:00:00', '20:00:00', 'FG410', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'NE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5525', '1', '2018-2019', 'BSED', 'PS495', 'Prep. & Val. Of Instructional Materials', 3, '', '20:00:00', '21:00:00', 'FG409', 'D', 45, 6, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5526', '1', '2018-2019', 'BSED', 'MATH305', 'Modern Geometry', 3, '', '19:00:00', '20:00:00', 'FG512', 'D', 45, 16, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5528', '1', '2018-2019', 'BSED', 'PS473', 'Science, Tech. & Society', 3, '', '18:00:00', '19:00:00', 'FG402', 'D', 45, 8, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5529', '1', '2018-2019', 'BSED', 'MATH402', 'Action in Research in Math Educ', 3, '', '18:00:00', '19:00:00', 'FG406', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5530', '1', '2018-2019', 'BSED', 'MATH403', 'Seminar on Technology in Math', 3, '', '17:00:00', '18:00:00', 'RA127', 'D', 50, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5531', '1', '2018-2019', 'BSED', 'PS453', 'History & Philo of Sc.', 3, '', '15:00:00', '16:00:00', 'FG409', 'D', 45, 7, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5532', '1', '2018-2019', 'BSED', 'MATH401', 'Seminar on Problem Solving in Math', 3, '', '19:00:00', '20:00:00', 'RA118', 'D', 50, 9, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5533', '1', '2018-2019', 'BSED', 'MATH304', 'Calculus 2', 3, '', '17:00:00', '18:00:00', 'RA129', 'D', 37, 12, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5534', '1', '2018-2019', 'BSED', 'PS433', 'Optics', 3, '', '18:00:00', '19:00:00', 'FG402', 'D', 45, 6, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5535', '1', '2018-2019', 'BSED', 'MATH307', 'Instrumentation in Math', 3, '', '18:00:00', '19:00:00', 'FG403', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5536', '1', '2018-2019', 'BSED', 'ST400', 'Seminar on Special Topics', 3, '', '12:00:00', '13:00:00', 'EM306', 'D', 45, 15, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5810', '1', '2018-2019', 'BSED', 'FS431', 'On becoming a Teacher', 1, '', '07:00:00', '08:00:00', 'EM306', 'M', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5812', '1', '2018-2019', 'BSED', 'ST400', 'Seminar on Special Topics', 3, '', '09:30:00', '12:30:00', 'EM306', 'S', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5813', '1', '2018-2019', 'BSED', 'SPE108', 'Organization and Management of PE, Sports and Wellness', 6, '', '19:00:00', '20:00:00', 'RA119', 'D', 50, 0, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5814', '1', '2018-2019', 'BSED', 'SPE116', 'Aquatics', 3, '', '18:00:00', '19:00:00', 'RA128', 'D', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5815', '1', '2018-2019', 'BSED', 'SPE119', 'Sports and Wellness Law', 3, '', '17:00:00', '18:00:00', 'RA128', 'D', 50, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5811', '1', '2018-2019', 'BSED', 'FS411', 'Learning Assessment Strategies', 1, '', '07:00:00', '08:00:00', 'EM306', 'M', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5816', '1', '2018-2019', 'BPE', 'SPE120', 'Applied Sports and Nutrition', 3, '', '20:00:00', '21:00:00', 'FG410', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5817', '1', '2018-2019', 'BPE', 'SPE118', 'Emergency Preparedness and Response Management', 3, '', '17:00:00', '18:00:00', 'RA120', 'D', 50, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5818', '1', '2018-2019', 'BPE', 'DEVRDG413', 'Developmental Reading 2', 3, '', '14:00:00', '15:00:00', 'FG405', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5819', '1', '2018-2019', 'BPE', 'SPE117', 'Special PE sports & wellness', 3, '', '15:00:00', '16:00:00', 'FG405', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5820', '1', '2018-2019', 'BPE', 'FS431', 'On becoming a Teacher', 1, '', '07:00:00', '08:00:00', 'EM306', 'T', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5821', '1', '2018-2019', 'BPE', 'FS411', 'Learning Assessment Strategies', 1, '', '07:00:00', '08:00:00', 'EM306', 'T', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5822', '1', '2018-2019', 'BPE', 'ST400', 'Seminar on Special Topics', 3, '', '15:30:00', '18:00:00', 'EM306', 'S', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5823', '1', '2018-2019', 'BPE', 'SPE108', 'Organization and Management of PE, Sports and Wellness', 6, '', '14:00:00', '16:00:00', 'FG512', 'D', 45, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5824', '1', '2018-2019', 'BPE', 'SPE116', 'Aquatics', 3, '', '18:00:00', '19:00:00', 'RA127', 'D', 50, 5, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5825', '1', '2018-2019', 'BSED', 'SPE119', 'Sports and Wellness Law', 3, '', '17:00:00', '18:00:00', 'RA127', 'D', 50, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5826', '1', '2018-2019', 'BSED', 'SPE120', 'Applied Sports and Nutrition', 3, '', '19:00:00', '20:00:00', 'RA120', 'D', 50, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5827', '1', '2018-2019', 'BSED', 'SPE118', 'Emergency Preparedness and Response Management', 3, '', '17:00:00', '18:00:00', 'RA129', 'D', 37, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5828', '1', '2018-2019', 'BSED', 'DEVRDG413', 'Developmental Reading 2', 3, '', '19:00:00', '20:00:00', 'RA129', 'D', 37, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5829', '1', '2018-2019', 'BSED', 'SPE117', 'Special PE sports & wellness', 3, '', '18:00:00', '19:00:00', 'RA129', 'D', 37, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5830', '1', '2018-2019', 'BPE', 'FS431', 'On becoming a Teacher', 1, '', '08:00:00', '09:00:00', 'EM306', 'M', 45, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5831', '1', '2018-2019', 'BPE', 'FS411', 'Learning Assessment Strategies', 1, '', '08:00:00', '09:00:00', 'EM306', 'M', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5832', '1', '2018-2019', 'BPE', 'ST400', 'Seminar on Special Topics', 3, '', '12:00:00', '15:30:00', 'EM306', 'U', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5833', '1', '2018-2019', 'BPE', 'SPE108', 'Organization and Management of PE, Sports and Wellness', 6, '', '19:00:00', '21:00:00', 'FG409', 'D', 45, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5834', '1', '2018-2019', 'BPE', 'SPE116', 'Aquatics', 3, '', '08:30:00', '11:00:00', 'RA212', 'S', 50, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5835', '1', '2018-2019', 'BPE', 'SPE119', 'Sports and Wellness Law', 3, '', '15:00:00', '16:00:00', 'FG402', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5836', '1', '2018-2019', 'BPE', 'SPE120', 'Applied Sports and Nutrition', 3, '', '17:00:00', '18:00:00', 'RA212', 'D', 50, 5, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5837', '1', '2018-2019', 'BPE', 'SPE118', 'Emergency Preparedness and Response Management', 3, '', '18:00:00', '19:00:00', 'RA212', 'D', 50, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5838', '1', '2018-2019', 'BPE', 'DEVRDG413', 'Developmental Reading 2', 3, '', '20:00:00', '21:00:00', 'RA212', 'D', 50, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL);
INSERT INTO `subjectssem120182019` (`OPEN`, `BLOCK`, `DISSOLVED`, `TERM`, `CN`, `SEM`, `SY`, `COURSE`, `SUBJECT`, `DESC`, `UNIT`, `CREDIT`, `TSTART`, `TEND`, `ROOM`, `SK`, `LIMIT`, `ENROLLED`, `CLOSED`, `CDATE`, `CTIME`, `LAB`, `AIR`, `MOD`, `C1`, `C2`, `C3`, `C4`, `PRN`, `AFLAG`, `DEPT`, `DEPARTMENT`, `PROGRAM`, `MAJOR`, `EMP_DP`, `EMP_NO`, `INSTRUCTOR`, `SSERVICE`, `SFCODE`, `STYPE`, `STP`, `NRLD`) VALUES
(1, 0, NULL, '1', '5839', '1', '2018-2019', 'BPE', 'SPE117', 'Special PE sports & wellness', 3, '', '19:00:00', '20:00:00', 'RA212', 'D', 50, 6, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5840', '1', '2018-2019', 'BPE', 'FS431', 'On becoming a Teacher', 1, '', '08:00:00', '09:00:00', 'EM306', 'T', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5841', '1', '2018-2019', 'BPE', 'FS411', 'Learning Assessment Strategies', 1, '', '08:00:00', '09:00:00', 'EM306', 'T', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5842', '1', '2018-2019', 'BPE', 'ST400', 'Seminar on Special Topics', 3, '', '09:30:00', '12:00:00', 'EM306', 'U', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5843', '1', '2018-2019', 'BPE', 'SPE108', 'Organization and Management of PE, Sports and Wellness', 6, '', '17:00:00', '19:00:00', 'RA128', 'D', 50, 2, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5844', '1', '2018-2019', 'BPE', 'SPE116', 'Aquatics', 3, '', '11:00:00', '14:30:00', 'RA214', 'S', 50, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5845', '1', '2018-2019', 'BPE', 'SPE119', 'Sports and Wellness Law', 3, '', '15:00:00', '16:00:00', 'FG406', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5846', '1', '2018-2019', 'BPE', 'SPE120', 'Applied Sports and Nutrition', 3, '', '16:00:00', '17:00:00', 'RA118', 'D', 50, 3, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5847', '1', '2018-2019', 'BPE', 'SPE118', 'Emergency Preparedness and Response Management', 3, '', '18:00:00', '19:00:00', 'RA214', 'D', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5848', '1', '2018-2019', 'BPE', 'DEVRDG413', 'Developmental Reading 2', 3, '', '17:00:00', '18:00:00', 'RA214', 'D', 50, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5849', '1', '2018-2019', 'BPE', 'SPE117', 'Special PE sports & wellness', 3, '', '19:00:00', '20:00:00', 'RA118', 'D', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8152', '1', '2018-2019', 'BSBA', 'ACCTG43', 'Management Accounting', 6, '', '12:00:00', '13:00:00', 'FG307', 'D', 45, 17, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8153', '1', '2018-2019', 'BSBA', 'MGT13', 'Social Responsibility & Good Governance', 3, '', '13:00:00', '14:00:00', 'AG202', 'D', 45, 16, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8154', '1', '2018-2019', 'BSBA', 'MKTG10', 'Entrepreneurial Management', 3, '', '16:00:00', '17:00:00', 'FG302', 'D', 45, 19, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8155', '1', '2018-2019', 'BSBA', 'FIN9', 'Strategic Financial Management', 3, '', '18:00:00', '19:00:00', 'FG312', 'D', 45, 18, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8157', '1', '2018-2019', 'BSBA', 'MKTG9', 'Franchising', 3, '', '15:00:00', '16:00:00', 'FG307', 'D', 45, 21, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8158', '1', '2018-2019', 'BSBA', 'FIN10', 'Financial Controllership', 3, '', '16:00:00', '17:00:00', 'FG312', 'D', 45, 16, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8121', '1', '2018-2019', 'BSBA', 'MKTG10', 'Entrepreneurial Management', 3, '', '15:00:00', '16:00:00', 'FG307', 'D', 40, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8122', '1', '2018-2019', 'BSBA', 'FIN10', 'Financial Controllership', 3, '', '17:00:00', '18:00:00', 'FG312', 'D', 40, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8123', '1', '2018-2019', 'BSBA', 'BUSMATH4', 'Quantitative techniques in Business', 3, '', '13:00:00', '14:00:00', 'FG312', 'D', 40, 15, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8124', '1', '2018-2019', 'BSBA', 'MGT13', 'Social Responsibility & Good Governance', 3, '', '14:00:00', '15:00:00', 'FG303', 'D', 40, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8125', '1', '2018-2019', 'BSBA', 'MKTG9', 'Franchising', 3, '', '16:00:00', '17:00:00', 'FG302', 'D', 40, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8126', '1', '2018-2019', 'BSBA', 'FIN9', 'Strategic Financial Management', 3, '', '17:00:00', '18:00:00', 'FG307', 'D', 40, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8127', '1', '2018-2019', 'BSBA', 'MKTG841', 'Sales Management', 3, '', '18:00:00', '19:00:00', 'FG306', 'D', 40, 30, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8128', '1', '2018-2019', 'BSBA', 'MKTG11', 'Strategic Marketing Management', 3, '', '16:00:00', '17:00:00', 'FG312', 'D', 40, 26, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8129', '1', '2018-2019', 'BSBA', 'MKTG10', 'Entrepreneurial Management', 3, '', '17:00:00', '18:00:00', 'FG211', 'D', 40, 23, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8131', '1', '2018-2019', 'BSBA', 'BUSMATH4', 'Quantitative techniques in Business', 3, '', '15:00:00', '16:00:00', 'FG303', 'D', 45, 15, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8132', '1', '2018-2019', 'BSBA', 'MKTG841', 'Sales Management', 3, '', '17:00:00', '18:00:00', 'FG210', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8133', '1', '2018-2019', 'BSBA', 'BUSMATH4', 'Quantitative techniques in Business', 3, '', '18:00:00', '19:00:00', 'FG307', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8134', '1', '2018-2019', 'BSBA', 'MKTG10', 'Entrepreneurial Management', 3, '', '19:00:00', '20:00:00', 'FG306', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8135', '1', '2018-2019', 'BSBA', 'MKTG11', 'Strategic Marketing Management', 3, '', '17:00:00', '18:00:00', 'FG308', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8136', '1', '2018-2019', 'BSBA', 'MKTG9', 'Franchising', 3, '', '18:00:00', '19:00:00', 'FG308', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8137', '1', '2018-2019', 'BSBA', 'BUSMATH4', 'Quantitative techniques in Business', 3, '', '16:00:00', '17:00:00', 'FG206', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8138', '1', '2018-2019', 'BSBA', 'MKTG10', 'Entrepreneurial Management', 3, '', '17:00:00', '18:00:00', 'FG206', 'D', 45, 8, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8139', '1', '2018-2019', 'BSBA', 'BM5', 'Business Ethics including Public Realations', 3, '', '17:00:00', '18:00:00', 'FG311', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8140', '1', '2018-2019', 'BSBA', 'BM7', 'Executive Leadership', 3, '', '18:00:00', '19:00:00', 'FG311', 'D', 45, 8, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8141', '1', '2018-2019', 'BSBA', 'BUSMATH4', 'Quantitative techniques in Business', 3, '', '09:00:00', '10:00:00', 'FG311', 'D', 45, 3, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8142', '1', '2018-2019', 'BSBA', 'OPTNMGT5', 'Productivity and Quality Tools', 3, '', '10:00:00', '11:00:00', 'FG311', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8143', '1', '2018-2019', 'BSBA', 'MKTG10', 'Entrepreneurial Management', 3, '', '10:00:00', '11:00:00', 'FG312', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8144', '1', '2018-2019', 'BSBA', 'OPTNMGT6', 'Facilities Management', 3, '', '12:00:00', '13:00:00', 'FG311', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '8146', '1', '2018-2019', 'BSBA', 'MGT13', 'Social Responsibility & Good Governance', 3, '', '17:00:00', '18:00:00', 'RA215', 'D', 45, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8147', '1', '2018-2019', 'BSBA', 'MGT11', 'Total Quality Management', 3, '', '18:00:00', '19:00:00', 'FG308', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8148', '1', '2018-2019', 'BSBA', 'OM7', 'Practicum 1 (General 200 hrs)', 3, '', '19:00:00', '20:00:00', 'BSBA', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8150', '1', '2018-2019', 'BSBA', 'HUM2', 'Philosophy of Man', 3, '', '11:00:00', '12:00:00', 'FG312', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7161', '1', '2018-2019', 'BSCR', 'CDI6', 'Fire Technology and Arson Investigation', 3, '', '14:00:00', '15:00:00', 'FG602', 'D', 45, 45, 1, '0000-00-00', '14:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7162', '1', '2018-2019', 'BSCR', 'CRIM5', 'Human Behavior & Cris Management', 3, '', '15:00:00', '16:00:00', 'FG602', 'D', 45, 45, 1, '0000-00-00', '14:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7163', '1', '2018-2019', 'BSCR', 'FORSCI6', 'Legal Medicine', 3, '', '17:00:00', '18:00:00', 'FG602', 'D', 45, 45, 1, '0000-00-00', '17:45:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7164', '1', '2018-2019', 'BSCR', 'CLJ5', 'Court Testimony', 3, '', '18:00:00', '19:00:00', 'FG602', 'D', 45, 45, 1, '0000-00-00', '09:10:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7165', '1', '2018-2019', 'BSCR', 'CDI6', 'Fire Technology and Arson Investigation', 3, '', '14:00:00', '15:00:00', 'FG607', 'D', 45, 45, 1, '0000-00-00', '12:13:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7166', '1', '2018-2019', 'BSCR', 'CRIM5', 'Human Behavior & Cris Management', 3, '', '15:00:00', '16:00:00', 'FG607', 'D', 45, 45, 1, '0000-00-00', '14:32:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7167', '1', '2018-2019', 'BSCR', 'FORSCI6', 'Legal Medicine', 3, '', '17:00:00', '18:00:00', 'FG603', 'D', 45, 45, 1, '0000-00-00', '17:50:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7168', '1', '2018-2019', 'BSCR', 'CLJ5', 'Court Testimony', 3, '', '18:00:00', '19:00:00', 'FG603', 'D', 45, 42, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7169', '1', '2018-2019', 'BSCR', 'CDI6', 'Fire Technology and Arson Investigation', 3, '', '15:00:00', '16:00:00', 'FG603', 'D', 45, 45, 1, '0000-00-00', '15:47:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7170', '1', '2018-2019', 'BSCR', 'CRIM5', 'Human Behavior & Cris Management', 3, '', '16:00:00', '17:00:00', 'FG603', 'D', 45, 45, 1, '0000-00-00', '09:31:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, '0', '2', '7171', '1', '2018-2019', 'BSCR', 'FORSCI6', 'Legal Medicine', 3, '', '18:00:00', '19:00:00', 'FG605', 'D', 45, 45, 1, '0000-00-00', '15:16:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7172', '1', '2018-2019', 'BSCR', 'CLJ5', 'Court Testimony', 3, '', '19:00:00', '20:00:00', 'FG605', 'D', 45, 45, 1, '0000-00-00', '16:29:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7173', '1', '2018-2019', 'BSCR', 'CDI6', 'Fire Technology and Arson Investigation', 3, '', '15:00:00', '16:00:00', 'FG602', 'D', 45, 19, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7174', '1', '2018-2019', 'BSCR', 'CRIM5', 'Human Behavior & Cris Management', 3, '', '16:00:00', '17:00:00', 'FG602', 'D', 45, 20, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7175', '1', '2018-2019', 'BSCR', 'FORSCI6', 'Legal Medicine', 3, '', '18:00:00', '19:00:00', 'FG605', 'D', 45, 18, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7176', '1', '2018-2019', 'BSCR', 'CLJ5', 'Court Testimony', 3, '', '19:00:00', '20:00:00', 'FG605', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7177', '1', '2018-2019', 'BSCR', 'FORSCI6', 'Legal Medicine', 3, '', '19:00:00', '20:00:00', 'FG607', 'D', 45, 45, 1, '0000-00-00', '16:14:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7178', '1', '2018-2019', 'BSCR', 'CLJ5', 'Court Testimony', 3, '', '07:00:00', '12:00:00', 'RA128', 'S', 50, 41, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7179', '1', '2018-2019', 'BSCR', 'CDI6', 'Fire Technology and Arson Investigation', 3, '', '17:00:00', '18:00:00', 'FG607', 'D', 45, 45, 1, '0000-00-00', '16:13:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7180', '1', '2018-2019', 'BSCR', 'CRIM5', 'Human Behavior & Cris Management', 3, '', '18:00:00', '19:00:00', 'FG607', 'D', 45, 45, 1, '0000-00-00', '16:13:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7181', '1', '2018-2019', 'BSCR', 'FORSCI6', 'Legal Medicine', 3, '', '19:00:00', '20:00:00', 'FG607', 'D', 45, 23, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7182', '1', '2018-2019', 'BSCR', 'CLJ5', 'Court Testimony', 3, '', '07:00:00', '12:00:00', 'RA128', 'S', 50, 10, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7183', '1', '2018-2019', 'BSCR', 'CDI6', 'Fire Technology and Arson Investigation', 3, '', '17:00:00', '18:00:00', 'FG607', 'D', 45, 28, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7184', '1', '2018-2019', 'BSCR', 'CRIM5', 'Human Behavior & Cris Management', 3, '', '18:00:00', '19:00:00', 'FG607', 'D', 45, 26, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7185', '1', '2018-2019', 'BSCR', 'FORSCI6', 'Legal Medicine', 3, '', '16:00:00', '17:00:00', 'FG603', 'D', 45, 7, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7186', '1', '2018-2019', 'BSCR', 'CLJ5', 'Court Testimony', 3, '', '13:00:00', '18:00:00', 'RA212', 'S', 50, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7187', '1', '2018-2019', 'BSCR', 'CDI6', 'Fire Technology and Arson Investigation', 3, '', '13:00:00', '14:00:00', 'FG607', 'D', 45, 8, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7188', '1', '2018-2019', 'BSCR', 'CRIM5', 'Human Behavior & Cris Management', 3, '', '14:00:00', '15:00:00', 'FG603', 'D', 45, 8, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(0, 1, NULL, '1', '7189', '1', '2018-2019', 'BSCR', 'FORSCI6', 'Legal Medicine', 3, '', '16:00:00', '17:00:00', 'FG602', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(0, 1, NULL, '2', '7190', '1', '2018-2019', 'BSCR', 'CLJ5', 'Court Testimony', 3, '', '13:00:00', '18:00:00', 'RA212', 'S', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(0, 1, NULL, '1', '7191', '1', '2018-2019', 'BSCR', 'CDI6', 'Fire Technology and Arson Investigation', 3, '', '13:00:00', '14:00:00', 'FG602', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(0, 1, NULL, '2', '7192', '1', '2018-2019', 'BSCR', 'CRIM5', 'Human Behavior & Cris Management', 3, '', '14:00:00', '15:00:00', 'FG610', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '1032', '1', '2018-2019', 'ITE', 'IT500', 'On the Job Training', 9, '', '07:00:00', '10:00:00', 'ITE', 'D', 37, 22, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1033', '1', '2018-2019', 'ITE', 'SPS411', 'Thesis I', 3, '', '13:00:00', '16:00:00', 'COMA', 'W', 40, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1034', '1', '2018-2019', 'ITE', 'IT225', 'Data Ccmmunication and Networking', 3, '', '17:00:00', '18:00:00', 'EM202', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1035', '1', '2018-2019', 'ITE', 'BCS416', 'Professional Ethics Values Education and Quality Processes', 3, '', '16:00:00', '17:00:00', 'EM202', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '1036', '1', '2018-2019', 'ITE', 'CSE412', 'CS Elective 3', 3, '', '16:00:00', '17:00:00', 'EM202', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6015', '1', '2018-2019', 'BSCA', 'SOCSC5', 'Life and Works of Rizal', 3, '', '08:00:00', '09:00:00', 'AG206', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6016', '1', '2018-2019', 'BSCA', 'CUST8', 'Customs Law Review', 5, '', '09:00:00', '10:00:00', 'AG206', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6017', '1', '2018-2019', 'BSCA', 'TARIFF7', 'Trade Remedies', 4, '', '10:00:00', '11:00:00', 'AG206', 'MTW', 45, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '6018', '1', '2018-2019', 'BSCA', 'TARIFF6', 'International Trade Org., Agreements and Rules of Origin', 5, '', '11:00:00', '12:00:00', 'AG206', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6019', '1', '2018-2019', 'BSCR', 'LAW1', 'Law on Obligation and Contracts', 3, '', '08:00:00', '09:00:00', 'AG206', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6020', '1', '2018-2019', 'BSCA', 'MGT2', 'Human Behavior in Organization', 3, '', '09:00:00', '10:00:00', 'AG206', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6021', '1', '2018-2019', 'BSCA', 'CUST8', 'Ethics and Customs Broker Profession', 3, '', '14:00:00', '15:00:00', 'AG206', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6022', '1', '2018-2019', 'BSCA', 'LAW1', 'Law on Obligation and Contracts', 3, '', '15:00:00', '16:00:00', 'AG206', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6023', '1', '2018-2019', 'BSCA', 'TARIFF7', 'Trade Remedies', 4, '', '16:00:00', '17:00:00', 'AG206', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '6024', '1', '2018-2019', 'BSCA', 'TARIFF6', 'International Trade Org., Agreements and Rules of Origin', 5, '', '18:00:00', '19:00:00', 'AG206', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6025', '1', '2018-2019', 'BSCR', 'SOCSC5', 'Life and Works of Rizal', 3, '', '15:00:00', '16:00:00', 'FG205', 'D', 45, 7, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6026', '1', '2018-2019', 'BSCA', 'MGT2', 'Human Behavior in Organization', 3, '', '14:00:00', '15:00:00', 'FG402', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3045', '1', '2018-2019', 'BSA', 'ACCTG43', 'Management Accounting', 6, '', '09:00:00', '11:00:00', 'FG211', 'A', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '3046', '1', '2018-2019', 'BSA', 'ACCTG41', 'Auditing Practice', 6, '', '09:00:00', '11:00:00', 'FG211', 'B', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '3047', '1', '2018-2019', 'BSA', 'ACCTG44', 'Accounting information system', 3, '', '11:00:00', '12:00:00', 'FG211', 'MWF', 45, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3048', '1', '2018-2019', 'BSA', 'ACCTG47', 'Accounting for Government, Not for Profit Organization', 3, '', '18:00:00', '19:00:00', 'FG206', 'MWF', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3050', '1', '2018-2019', 'BSA', 'REV1', 'Practical Accounting 1 & 2/ Theory of Accounts', 3, '', '15:00:00', '17:00:00', 'AG201', 'D', 30, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3054', '1', '2018-2019', 'BSA', 'ACCTG43', 'Management Accounting', 6, '', '09:00:00', '11:00:00', 'FG211', 'A', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '3055', '1', '2018-2019', 'BSA', 'ACCTG44', 'Accounting information system', 3, '', '07:00:00', '08:00:00', 'FG206', 'MWF', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '3056', '1', '2018-2019', 'BSA', 'LIT1', 'Literature of the Philippines', 3, '', '08:00:00', '09:00:00', 'FG211', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3057', '1', '2018-2019', 'BSA', 'BM4', 'Production and Operations Management', 3, '', '08:00:00', '09:00:00', 'FG211', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3058', '1', '2018-2019', 'BSA', 'TAX2', 'Business & Transfer Taxes', 3, '', '13:00:00', '14:00:00', 'AG201', 'D', 30, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3059', '1', '2018-2019', 'BSA', 'SOCSC4', 'Soc., Cult., Nat\'l Dev. w/ Fam Planning/Pop & Drug Educ/STD/Aids/HIV', 3, '', '14:00:00', '15:00:00', 'FG303', 'D', 45, 8, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0035', '1', '2018-2019', 'CLA', 'ENGL493', 'Afro-Asian Literature', 3, '', '10:00:00', '11:00:00', 'AG212', 'D', 37, 3, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0036', '1', '2018-2019', 'CLA', 'MATH2', 'Business Statistics', 3, '', '11:00:00', '12:00:00', 'AG212', 'D', 37, 10, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0037', '1', '2018-2019', 'CLA', 'ENGL393', 'English and American Literature', 3, '', '12:00:00', '13:00:00', 'AG212', 'D', 37, 4, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 1, NULL, '1', '0038', '1', '2018-2019', ' CLA', 'ENGL24', 'European Literature', 3, '', '09:00:00', '10:00:00', 'AG212', 'D', 37, 3, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0039', '1', '2018-2019', 'CLA', 'SOCSC5', 'Life and Works of Rizal', 3, '', '10:00:00', '11:00:00', 'AG202', 'D', 45, 27, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0040', '1', '2018-2019', 'CLA', 'EDUC13', 'Administration and Supervision', 3, '', '12:00:00', '13:00:00', 'AG212', 'D', 37, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0041', '1', '2018-2019', 'CLA', 'MR', 'Methods of Research', 3, '', '14:00:00', '15:00:00', 'AG212', 'D', 37, 3, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0042', '1', '2018-2019', 'CLA', 'PSY111', 'Practicum', 3, '', '11:00:00', '12:00:00', 'AG207', 'D', 37, 25, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '0043', '1', '2018-2019', 'CLA', 'PSY112', 'Research in Psychology I (Thesis 1)', 3, '', '12:00:00', '13:00:00', 'AG207', 'D', 37, 26, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '0045', '1', '2018-2019', 'CLA', 'PSY113', 'Seminar in Psychology IV (Group Dynamics)', 3, '', '12:00:00', '13:00:00', 'AG207', 'D', 37, 25, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '0046', '1', '2018-2019', 'CLA', 'MGT1', 'Principles of Management', 3, '', '15:00:00', '16:00:00', 'AG207', 'D', 37, 27, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '0047', '1', '2018-2019', 'CLA', 'BA9', 'Communcation Media Laws and Ethics', 3, '', '09:00:00', '10:00:00', 'AG214', 'D', 37, 7, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0048', '1', '2018-2019', 'CLA', 'BA11', 'Intro to Development Communication', 3, '', '10:00:00', '11:00:00', 'AG214', 'D', 37, 7, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0049', '1', '2018-2019', 'CLA', 'BA12', 'Thesis or Special Project', 3, '', '11:00:00', '12:00:00', 'AG211', 'D', 30, 6, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0050', '1', '2018-2019', 'CLA', 'BA-EL4', 'Communcation Related Elective (Organizational Communication)', 3, '', '11:00:00', '12:00:00', 'AG211', 'D', 30, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0051', '1', '2018-2019', 'CLA', 'SSHUM-EL4', 'Social Science/ Humanities Elective(Educational Broadcasting)', 3, '', '13:00:00', '14:00:00', 'AG211', 'D', 30, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4031', '1', '2018-2019', 'BSCE', 'CE414', 'Geo Tech Eng\'g 1 Lec', 4, '', '08:00:00', '09:00:00', 'EM303', 'D', 45, 14, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4032', '1', '2018-2019', 'BSCE', 'CE414L', 'Geo Tech Eng\'g 1 Lab', 0, '', '09:00:00', '12:00:00', 'MTRLB', 'MW', 30, 13, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'EN', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4033', '1', '2018-2019', 'BSCE', 'CE454', 'Structural Theory 1 Lec', 4, '', '17:00:00', '18:00:00', 'EM302', 'D', 45, 15, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4034', '1', '2018-2019', 'BSCE', 'CE454L', 'Structural Theory 1 Lab', 0, '', '18:00:00', '19:00:00', 'EM302', 'D', 45, 15, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CL', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4035', '1', '2018-2019', 'BSCE', 'MECH413', 'Mechanics of Fluid Lec', 3, '', '13:00:00', '14:00:00', 'EM303', 'M-H', 45, 14, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4036', '1', '2018-2019', 'BSCE', 'MECH413L', 'Mechanics of Fluids Lab', 0, '', '08:00:00', '11:00:00', 'FLAB', 'MW', 25, 14, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'EN', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4037', '1', '2018-2019', 'BSCE', 'CE473', 'Construction Materials and Testing Lec', 3, '', '18:00:00', '19:00:00', 'AG205', 'M-H', 45, 17, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4040', '1', '2018-2019', 'BSCE', 'CE323', 'Highway Engineering', 3, '', '16:00:00', '17:00:00', 'EM303', 'D', 45, 36, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4041', '1', '2018-2019', 'BSCE', 'CE473L', 'Construction Materials and Testing Lab', 0, '', '08:00:00', '11:00:00', 'MTRLB', 'U', 30, 14, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'EN', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4043', '1', '2018-2019', 'BSCE', 'CE414', 'Geo Tech Eng\'g 1 Lec', 4, '', '19:00:00', '20:00:00', 'EM303', 'D', 45, 18, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4044', '1', '2018-2019', 'BSCE', 'CE414L', 'Geo Tech Eng\'g 1 Lab', 0, '', '09:00:00', '12:00:00', 'MTRLB', 'TH', 30, 19, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'EN', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4045', '1', '2018-2019', 'BSCE', 'CE454', 'Structural Theory 1 Lec', 4, '', '15:00:00', '16:00:00', 'EM302', 'D', 45, 17, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4046', '1', '2018-2019', 'BSCE', 'CE454L', 'Structural Theory 1 Lab', 0, '', '16:00:00', '17:00:00', 'EM302', 'D', 45, 17, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CL', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4047', '1', '2018-2019', 'BSCE', 'MECH413', 'Mechanics of Fluid Lec', 3, '', '17:00:00', '18:00:00', 'EM303', 'M-H', 45, 15, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4048', '1', '2018-2019', 'BSCE', 'MECH413L', 'Mechanics of Fluids Lab', 0, '', '08:00:00', '11:00:00', 'FLAB', 'TH', 25, 15, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'EN', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4049', '1', '2018-2019', 'BSCE', 'CE473', 'Construction Materials and Testing Lec', 3, '', '19:00:00', '20:00:00', 'AG205', 'M-H', 45, 15, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4052', '1', '2018-2019', 'BSCE', 'CE323', 'Highway Engineering', 3, '', '20:00:00', '21:00:00', 'EM303', 'D', 45, 17, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4053', '1', '2018-2019', 'BSCE', 'CE473L', 'Construction Materials and Testing Lab', 0, '', '13:00:00', '16:00:00', 'MTRLB', 'U', 30, 17, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'EN', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4059', '1', '2018-2019', 'BSCE', 'CE552', 'Const Method & Project Mgt. Lec', 2, '', '08:00:00', '09:00:00', 'EM302', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4060', '1', '2018-2019', 'BSCE', 'CE551L', 'Const Method & Project Mgt. Lab', 1, '', '07:00:00', '08:00:00', 'EM302', 'M', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4061', '1', '2018-2019', 'BSCE', 'CE533', 'Foundation Lecture', 3, '', '08:00:00', '09:00:00', 'EM302', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4062', '1', '2018-2019', 'BSCE', 'CE531L', 'Foundation Lab', 1, '', '09:00:00', '12:00:00', 'MTRLB', 'MW', 30, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'EN', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4063', '1', '2018-2019', 'BSCE', 'CE572', 'RC2  Lec', 2, '', '14:00:00', '15:00:00', 'EM303', 'D', 45, 0, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4065', '1', '2018-2019', 'BSCE', 'CE592', 'Timber Design Lec', 2, '', '09:00:00', '10:00:00', 'EM302', 'M-H', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4066', '1', '2018-2019', 'BSCE', 'CE591L', 'Timber Design Lab', 1, '', '10:00:00', '11:00:00', 'EM302', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CL', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4067', '1', '2018-2019', 'BSCE', 'CE513', 'Water Resources Engineering', 3, '', '17:00:00', '18:00:00', 'AG205', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4068', '1', '2018-2019', 'BSCE', 'CE553', 'CE Laws, Contracts, Specs & Ethic', 3, '', '13:00:00', '14:00:00', 'EM302', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4069', '1', '2018-2019', 'BSCE', 'CE573', 'Hydrology', 3, '', '19:00:00', '20:00:00', 'EM303', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8130', '1', '2018-2019', 'BSCE', 'MKTG9', 'Franchising', 3, '', '14:00:00', '15:00:00', 'AG106', 'D', 40, 22, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '1011', '1', '2018-2019', 'ITE', 'ENGL2', 'Writing in the Disciplines', 3, '', '08:00:00', '09:00:00', 'EM201', 'D', 45, 11, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1012', '1', '2018-2019', 'ITE', 'SOCSC1', 'Philippine History & Government', 3, '', '08:00:00', '09:00:00', 'EM201', 'D', 45, 4, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1013', '1', '2018-2019', 'ITE', 'HUM2', 'Philosophy of Man', 3, '', '09:00:00', '10:00:00', 'EM201', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1014', '1', '2018-2019', 'ITE', 'SOCSC2', 'Basic Econ w/Tax. Land Ref. & Oth. Iss.', 3, '', '09:00:00', '10:00:00', 'EM201', 'D', 45, 7, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1015', '1', '2018-2019', 'ITE', 'PT101', 'Platform Technologies', 3, '', '10:00:00', '13:00:00', 'COMA', 'M', 40, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '3', '1017', '1', '2018-2019', 'ITE', 'PF101', 'Object Oriented Programming', 3, '', '10:00:00', '13:00:00', 'COMA', 'S', 40, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '2', '1018', '1', '2018-2019', 'ITE', 'DS102', 'Discrete Structures 2', 3, '', '07:00:00', '08:00:00', 'EM201', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1019', '1', '2018-2019', 'ITE', 'PE3', 'Fundl\'s of Games and Sports', 2, '', '08:00:00', '10:00:00', 'PC', 'S', 50, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1020', '1', '2018-2019', 'ITE', 'SIA101', 'Systems Integration and Architecture 1', 3, '', '13:00:00', '16:00:00', 'COMA', 'T', 40, 7, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '3', '1021', '1', '2018-2019', 'ITE', 'PFE101', 'Event Driven Programming', 3, '', '13:00:00', '16:00:00', 'COMA', 'H', 40, 7, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '3', '1022', '1', '2018-2019', 'ITE', 'IM101', 'Advanced Database Systems', 3, '', '13:00:00', '16:00:00', 'COMA', 'S', 30, 13, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '1023', '1', '2018-2019', 'ITE', 'HUM3', 'Literature of the World', 3, '', '16:00:00', '17:00:00', 'FG606', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1024', '1', '2018-2019', 'ITE', 'SOCSC5', 'Life and Works of Rizal', 3, '', '16:00:00', '17:00:00', 'FG410', 'D', 45, 5, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1031', '1', '2018-2019', 'ITE', 'NET102', 'Networking 2', 3, '', '17:00:00', '18:00:00', 'EM202', 'D', 45, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '5527', '1', '2018-2019', 'BSED', 'MATH400', 'Prep. & Eval of Instructional Mat', 3, '', '20:00:00', '21:00:00', 'FG512', 'D', 45, 7, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7209', '1', '2018-2019', 'BSCR', 'PRACT1&2', 'OJT and Community Immersion', 6, '', '06:00:00', '12:00:00', 'BSCR', 'D', 20, 8, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7210', '1', '2018-2019', 'BSCR', 'PR.101', 'Pre-Review', 6, '', '18:00:00', '20:00:00', 'BSCR', 'D', 20, 5, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1025', '1', '2018-2019', 'BSCR', 'CSE311', 'CS Elective 1', 3, '', '13:00:00', '16:00:00', 'COMA', 'S', 10, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '1026', '1', '2018-2019', 'ITE', 'AL102', 'Automata Theory and Formal Languages', 3, '', '12:00:00', '13:00:00', 'EM202', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1027', '1', '2018-2019', 'ITE', 'AR101', 'Computer Organization and Architecture', 3, '', '12:00:00', '13:00:00', 'EM202', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1028', '1', '2018-2019', 'ITE', 'SOCSC5', 'Life and Works of Rizal', 3, '', '11:00:00', '12:00:00', 'EM202', 'D', 45, 2, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1029', '1', '2018-2019', 'ITE', 'IAS101', 'Information Assurance and Security 1', 3, '', '11:00:00', '12:00:00', 'EM202', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '3', '1030', '1', '2018-2019', 'ITE', 'CC106', 'Application Development and Emerging Technologies', 3, '', '13:00:00', '16:00:00', 'COMA', 'M', 45, 1, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '6027', '1', '2018-2019', 'ITE', 'ACCTG101', 'Fundamentals of Accounting, Business and Management', 3, '', '08:00:00', '09:00:00', 'FG205', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6028', '1', '2018-2019', 'ITE', 'GE201', 'Undestanding the Self', 3, '', '07:00:00', '08:00:00', 'AG206', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6029', '1', '2018-2019', 'ITE', 'GE202', 'Reading in Philippine History', 3, '', '10:00:00', '11:00:00', 'AG202', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6030', '1', '2018-2019', 'ITE', 'GE203', 'The Contemporary World', 3, '', '11:00:00', '12:00:00', 'FG206', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6031', '1', '2018-2019', 'ITE', 'GE401', 'Mathematics in the Modern World', 3, '', '08:00:00', '09:00:00', 'FG205', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL);
INSERT INTO `subjectssem120182019` (`OPEN`, `BLOCK`, `DISSOLVED`, `TERM`, `CN`, `SEM`, `SY`, `COURSE`, `SUBJECT`, `DESC`, `UNIT`, `CREDIT`, `TSTART`, `TEND`, `ROOM`, `SK`, `LIMIT`, `ENROLLED`, `CLOSED`, `CDATE`, `CTIME`, `LAB`, `AIR`, `MOD`, `C1`, `C2`, `C3`, `C4`, `PRN`, `AFLAG`, `DEPT`, `DEPARTMENT`, `PROGRAM`, `MAJOR`, `EMP_DP`, `EMP_NO`, `INSTRUCTOR`, `SSERVICE`, `SFCODE`, `STYPE`, `STP`, `NRLD`) VALUES
(1, 0, NULL, '2', '6032', '1', '2018-2019', 'ITE', 'GE101', 'Purposive Communication', 3, '', '09:00:00', '10:00:00', 'FG205', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6033', '1', '2018-2019', 'ITE', 'PE1', 'Movement Enhancement', 2, '', '08:00:00', '10:00:00', 'PC', 'S', 50, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6034', '1', '2018-2019', 'ITE', 'NSTP1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'AG206', 'S', 45, 8, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6008', '1', '2018-2019', 'BSCA', 'CUST5', 'Customs Clearance and Procedures and Practices', 3, '', '13:00:00', '14:00:00', 'AG206', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6010', '1', '2018-2019', 'BSCA', 'FIN1', 'Basic Finance', 3, '', '15:00:00', '16:00:00', 'AG208', 'D', 30, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '6011', '1', '2018-2019', 'BSCA', 'HUM2', 'Philosophy of Man', 3, '', '16:00:00', '17:00:00', 'AG202', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '6012', '1', '2018-2019', 'BSCA', 'TARIFF4', 'Import Taxation 1', 3, '', '17:00:00', '18:00:00', 'AG206', 'D', 45, 4, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6013', '1', '2018-2019', 'BSCA', 'SCM2', 'Transportation and Purchasing Management', 3, '', '15:00:00', '16:00:00', 'AG208', 'D', 30, 4, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '6014', '1', '2018-2019', 'BSCA', 'LIT1', 'Literature of the Philippines', 3, '', '14:00:00', '15:00:00', 'AG208', 'D', 30, 3, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4022', '1', '2018-2019', 'BSCE', 'CE333', 'Static of Rigid Bodies', 3, '', '17:00:00', '18:00:00', 'EM302', 'D', 45, 34, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4023', '1', '2018-2019', 'BSCE', 'CE314', 'Surveying 1 Lec', 4, '', '18:00:00', '19:00:00', 'EM303', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4024', '1', '2018-2019', 'BSCE', 'MGT313', 'Engineering Management', 3, '', '19:00:00', '20:00:00', 'EM302', 'D', 45, 20, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4025', '1', '2018-2019', 'BSCE', 'ECON313', 'Engineering Economy', 3, '', '17:00:00', '18:00:00', 'EM303', 'D', 45, 22, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4026', '1', '2018-2019', 'BSCE', 'CE371', 'Safety Management', 1, '', '18:00:00', '19:00:00', 'EM303', 'D', 45, 23, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4027', '1', '2018-2019', 'BSCE', 'ME313', 'Basic Mechanical Engineering', 3, '', '19:00:00', '20:00:00', 'EM302', 'D', 45, 16, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4028', '1', '2018-2019', 'BSCE', 'MATH313', 'Differential Equations', 3, '', '20:00:00', '21:00:00', 'EM302', 'D', 45, 23, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4029', '1', '2018-2019', 'BSCE', 'CE314L', 'Surveying 1Lab', 0, '', '08:00:00', '11:00:00', 'EM303', 'U', 45, 12, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(0, 1, NULL, '1', '4015', '1', '2018-2019', 'BSCE', 'ENGL2', 'Writing in the Disciplines', 3, '', '18:00:00', '19:00:00', 'EM302', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(0, 1, NULL, '2', '4017', '1', '2018-2019', 'BSCE', 'SOCSC1', 'Philippine History & Government', 3, '', '15:00:00', '16:00:00', 'AG205', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(0, 1, NULL, '2', '4018', '1', '2018-2019', 'BSCE', 'PHYS214', 'College Physics 2', 4, '', '19:00:00', '21:00:00', 'AG205', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(0, 1, NULL, '3', '4020', '1', '2018-2019', 'BSCE', 'PE3', 'Fundl\'s of Games and Sports', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(0, 1, NULL, '3', '4021', '1', '2018-2019', 'BSCE', 'CWTS2', 'National Service Training Program 2', 3, '', '08:00:00', '11:00:00', 'EM303', 'S', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0052', '1', '2018-2019', 'CLA', 'GE301', 'Art Appreciation', 3, '', '13:00:00', '14:00:00', 'AG212', 'D', 37, 28, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0053', '1', '2018-2019', 'CLA', 'GE501', 'Science, Technology and Society', 3, '', '14:00:00', '15:00:00', 'AG212', 'D', 37, 31, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '0054', '1', '2018-2019', 'CLA', 'GE101', 'Purposive Communication', 3, '', '15:00:00', '16:00:00', 'AG214', 'D', 37, 28, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0055', '1', '2018-2019', 'CLA', 'GE205', 'Life and Works of Rizal', 3, '', '11:00:00', '12:00:00', 'AG212', 'D', 37, 9, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0056', '1', '2018-2019', 'CLA', 'LIT1', 'Literature of the Philippines', 3, '', '13:00:00', '14:00:00', 'AG212', 'D', 37, 23, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '0057', '1', '2018-2019', 'CLA', 'GE302', 'Indigenous Creative Crafts', 3, '', '15:00:00', '16:00:00', 'AG214', 'D', 37, 27, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '0058', '1', '2018-2019', 'CLA', 'PE1', 'Movement Enhancement', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 25, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '0059', '1', '2018-2019', 'CLA', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'AG212', 'S', 37, 24, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8160', '1', '2018-2019', 'BSBA', 'MKTG3', 'Marketing Research', 3, '', '10:00:00', '11:00:00', 'FG312', 'D', 40, 36, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8156', '1', '2018-2019', 'BSBA', 'BUSMATH4', 'Quantitative techniques in Business', 3, '', '12:00:00', '13:00:00', 'FG306', 'D', 45, 1, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8120', '1', '2018-2019', 'BSBA', 'ACCTG43', 'Management Advisory Services', 6, '', '11:00:00', '12:00:00', 'AG106', 'D', 40, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8145', '1', '2018-2019', 'BSBA', 'OPTNMGT7', 'Global International Trade', 3, '', '13:00:00', '14:00:00', 'SRBA', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7193', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '08:00:00', '09:00:00', 'FG604', 'D', 30, 30, 1, '0000-00-00', '13:59:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7194', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '09:00:00', '10:00:00', 'FG509', 'D', 30, 30, 1, '0000-00-00', '13:59:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7195', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '10:00:00', '11:00:00', 'FG604', 'D', 30, 30, 1, '0000-00-00', '13:59:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7196', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '11:00:00', '12:00:00', 'FG604', 'D', 30, 30, 1, '0000-00-00', '13:59:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7197', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '08:00:00', '09:00:00', 'FG604', 'D', 30, 30, 1, '0000-00-00', '13:59:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7198', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '09:00:00', '10:00:00', 'FG509', 'D', 30, 30, 1, '0000-00-00', '13:59:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7199', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '10:00:00', '11:00:00', 'FG605', 'D', 45, 33, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7200', '1', '2018-2019', 'BSCR', 'DEFTAC1', 'Fundamentals of Martial Arts', 2, '', '13:00:00', '15:00:00', 'FL04', 'F', 60, 6, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'DE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7201', '1', '2018-2019', 'BSCR', 'GE401', 'Mathematics in the Modern World', 3, '', '13:00:00', '14:00:00', 'FG603', 'D', 45, 45, 1, '0000-00-00', '14:37:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7202', '1', '2018-2019', 'BSCR', 'GE201', 'Undestanding the Self', 3, '', '14:00:00', '15:00:00', 'FG509', 'D', 45, 45, 1, '0000-00-00', '14:43:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7203', '1', '2018-2019', 'BSCR', 'GE202', 'Reading in Philippine History', 3, '', '15:00:00', '16:00:00', 'FG509', 'D', 45, 45, 1, '0000-00-00', '14:43:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7204', '1', '2018-2019', 'BSCR', 'GE203', 'The Contemporary World', 3, '', '17:00:00', '18:00:00', 'FG509', 'D', 45, 45, 1, '0000-00-00', '14:43:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7205', '1', '2018-2019', 'BSCR', 'GE205', 'Life and Works of Rizal', 3, '', '13:00:00', '14:00:00', 'FG509', 'D', 45, 45, 1, '0000-00-00', '14:43:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7206', '1', '2018-2019', 'BSCR', 'CRIM1', 'Introduction to Criminology', 3, '', '15:00:00', '16:00:00', 'FG509', 'D', 45, 45, 1, '0000-00-00', '14:43:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7207', '1', '2018-2019', 'BSCR', 'CHEM1', 'General Chemistry', 3, '', '14:00:00', '15:00:00', 'FG509', 'D', 45, 45, 1, '0000-00-00', '14:43:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7208', '1', '2018-2019', 'BSCR', 'DEFTAC1', 'Fundamentals of Martial Arts', 2, '', '08:00:00', '10:00:00', 'FL02', 'H', 60, 46, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'DE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8161', '1', '2018-2019', 'BSBA', 'MKTG5', 'Product Management', 3, '', '11:00:00', '12:00:00', 'SRBA', 'D', 40, 34, 0, '0000-00-00', '09:32:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8162', '1', '2018-2019', 'BSBA', 'MGT11', 'Total Quality Management', 3, '', '13:00:00', '14:00:00', 'AG106', 'D', 40, 35, 0, '0000-00-00', '09:30:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8163', '1', '2018-2019', 'BSBA', 'MKTG4', 'Distribution Management', 3, '', '14:00:00', '15:00:00', 'FG311', 'D', 40, 35, 0, '0000-00-00', '09:31:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8164', '1', '2018-2019', 'BSBA', 'MGT6', 'Human Behavior in Organization', 3, '', '15:00:00', '16:00:00', 'FG311', 'D', 40, 31, 0, '0000-00-00', '09:31:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8165', '1', '2018-2019', 'BSBA', 'MGT13', 'Social Responsibility & Good Governance', 3, '', '15:00:00', '16:00:00', 'AG106', 'D', 40, 31, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8167', '1', '2018-2019', 'BSBA', 'HUM3', 'Logic', 3, '', '16:00:00', '17:00:00', 'AG106', 'D', 40, 17, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8168', '1', '2018-2019', 'BSBA', 'LAW1', 'Law on Obligation and Contracts', 3, '', '18:00:00', '19:00:00', 'FG306', 'D', 40, 23, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '8170', '1', '2018-2019', 'BSBA', 'MKTG3', 'Marketing Research', 3, '', '09:00:00', '10:00:00', 'FG312', 'D', 40, 33, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '8172', '1', '2018-2019', 'BSBA', 'MKTG5', 'Product Management', 3, '', '12:00:00', '13:00:00', 'FG308', 'D', 40, 32, 0, '0000-00-00', '09:36:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8173', '1', '2018-2019', 'BSBA', 'MGT11', 'Total Quality Management', 3, '', '15:00:00', '16:00:00', 'AG106', 'D', 40, 18, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8174', '1', '2018-2019', 'BSBA', 'MGT6', 'Human Behavior in Organization', 3, '', '13:00:00', '14:00:00', 'AG202', 'D', 40, 22, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8176', '1', '2018-2019', 'BSBA', 'MGT12', 'Human Resource Management', 3, '', '17:00:00', '18:00:00', 'AG106', 'D', 40, 27, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8177', '1', '2018-2019', 'BSBA', 'LAW1', 'Law on Obligation and Contracts', 3, '', '19:00:00', '20:00:00', 'FG308', 'D', 40, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '3049', '1', '2018-2019', 'BSA', 'ELECTIVE4A', 'World Culture', 3, '', '19:00:00', '20:00:00', 'FG206', 'D', 45, 4, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4038', '1', '2018-2019', 'BSCE', 'CE412', 'Building Design 2 Lec', 2, '', '13:00:00', '14:00:00', 'COMC', 'W', 35, 14, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4042', '1', '2018-2019', 'MH', 'CE412L', 'Building Design 2 Lab', 0, '', '13:00:00', '15:00:00', 'COMC', 'MH', 35, 13, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4050', '1', '2018-2019', 'BSCE', 'CE412', 'Building Design 2 Lec', 2, '', '17:00:00', '18:00:00', 'COMC', 'W', 35, 18, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4054', '1', '2018-2019', 'BSCE', 'CE412L', 'Building Design 2 Lab', 0, '', '17:00:00', '19:00:00', 'COMC', 'MH', 35, 18, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4055', '1', '2018-2019', 'BSCE', 'CE412', 'Building Design 2 Lec', 2, '', '18:00:00', '19:00:00', 'COMC', 'W', 35, 0, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4056', '1', '2018-2019', 'BSCE', 'CE412L', 'Building Design 2 Lab', 0, '', '17:00:00', '19:00:00', 'COMC', 'TF', 35, 0, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4057', '1', '2018-2019', 'BSCE', 'CE412', 'Building Design 2 Lec', 2, '', '14:00:00', '15:00:00', 'COMC', 'W', 35, 9, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4058', '1', '2018-2019', 'BSCE', 'CE412L', 'Building Design 2 Lab', 0, '', '13:00:00', '15:00:00', 'COMC', 'TF', 35, 9, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4051', '1', '2018-2019', 'BSCE', 'PHILO2', 'Intro to Philosophy and Logic', 3, '', '20:00:00', '21:00:00', 'FG206', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4030', '1', '2018-2019', 'BSCE', 'ES321', 'Computer Aided Drafting', 1, '', '13:00:00', '16:00:00', 'COMC', 'U', 35, 28, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7121', '1', '2018-2019', 'BSCR', 'FORSCI3', 'Forensic Ballistics', 4, '', '07:00:00', '08:50:00', 'FG607', 'D', 45, 37, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CR', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7122', '1', '2018-2019', 'BSCR', 'ENGL34CR', 'Technical Report Writing 1', 3, '', '09:00:00', '10:00:00', 'FG607', 'D', 45, 36, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7123', '1', '2018-2019', 'BSCR', 'LEA4', 'Police Intelligence', 3, '', '10:00:00', '11:00:00', 'FG607', 'D', 45, 41, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7124', '1', '2018-2019', 'BSCR', 'LEA5', 'Police Personnel and Records Management', 3, '', '07:00:00', '08:00:00', 'FG603', 'D', 45, 40, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7125', '1', '2018-2019', 'BSCR', 'CA1', 'Institutional Corrections', 3, '', '09:00:00', '10:00:00', 'FG607', 'D', 45, 29, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7126', '1', '2018-2019', 'BSCR', 'CDI2', 'Traffic Management and Accident Investigation', 3, '', '10:00:00', '11:00:00', 'FG607', 'D', 45, 37, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7127', '1', '2018-2019', 'BSCR', 'FORSCI4', 'Questioned Documents Exam', 4, '', '11:00:00', '12:20:00', 'FG607', 'D', 45, 39, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CR', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7128', '1', '2018-2019', 'BSCR', 'CRIM6', 'Criminilogical Research & Statistics', 3, '', '12:00:00', '13:00:00', 'FG605', 'D', 45, 34, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '7129', '1', '2018-2019', 'BSCR', 'CRIM6', 'Criminilogical Research & Statistics', 3, '', '07:00:00', '08:00:00', 'FG602', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7130', '1', '2018-2019', 'BSCR', 'FORSCI3', 'Forensic Ballistics', 4, '', '10:00:00', '11:20:00', 'FG610', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CR', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7131', '1', '2018-2019', 'BSCR', 'ENGL34CR', 'Technical Report Writing 1', 3, '', '09:00:00', '10:00:00', 'FG610', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7132', '1', '2018-2019', 'BSCR', 'LEA4', 'Police Intelligence', 3, '', '08:00:00', '09:00:00', 'FG610', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7133', '1', '2018-2019', 'BSCR', 'LEA5', 'Police Personnel and Records Management', 3, '', '12:00:00', '13:00:00', 'FG611', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7134', '1', '2018-2019', 'BSCR', 'CA1', 'Institutional Corrections', 3, '', '09:00:00', '10:00:00', 'FG611', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7135', '1', '2018-2019', 'BSCR', 'CDI2', 'Traffic Management and Accident Investigation', 3, '', '08:00:00', '09:00:00', 'FG611', 'D', 45, 0, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7136', '1', '2018-2019', 'BSCR', 'FORSCI4', 'Questioned Documents Exam', 4, '', '10:00:00', '11:20:00', 'FG611', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CR', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7138', '1', '2018-2019', 'BSCU', 'LEA4', 'Police Intelligence', 3, '', '15:00:00', '16:00:00', 'FG611', 'D', 45, 34, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7139', '1', '2018-2019', 'BSCR', 'ENGL34CR', 'Technical Report Writing 1', 3, '', '14:00:00', '15:00:00', 'FG611', 'D', 45, 45, 1, '0000-00-00', '16:25:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7140', '1', '2018-2019', 'BSCR', 'FORSCI4', 'Questioned Documents Exam', 4, '', '11:40:00', '13:00:00', 'FG610', 'D', 45, 44, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CR', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7141', '1', '2018-2019', 'BSCR', 'LEA5', 'Police Personnel and Records Management', 3, '', '13:00:00', '14:00:00', 'FG611', 'D', 45, 42, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7142', '1', '2018-2019', 'BSCR', 'CA1', 'Institutional Corrections', 3, '', '14:00:00', '15:00:00', 'FG611', 'D', 45, 28, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7143', '1', '2018-2019', 'BSCR', 'CDI2', 'Traffic Management and Accident Investigation', 3, '', '15:00:00', '16:00:00', 'FG611', 'D', 45, 45, 1, '0000-00-00', '13:40:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '7144', '1', '2018-2019', 'BSCR', 'CRIM6', 'Criminilogical Research & Statistics', 3, '', '16:00:00', '17:00:00', 'FG605', 'D', 45, 45, 1, '0000-00-00', '09:48:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7145', '1', '2018-2019', 'BSCR', 'ENGL34CR', 'Technical Report Writing 1', 3, '', '13:00:00', '14:00:00', 'FG611', 'D', 45, 12, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7146', '1', '2018-2019', 'BSCR', 'FORSCI3', 'Forensic Ballistics', 4, '', '15:00:00', '16:20:00', 'FG604', 'D', 30, 12, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CR', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7147', '1', '2018-2019', 'BSCR', 'LEA4', 'Police Intelligence', 3, '', '14:00:00', '15:00:00', 'FG604', 'D', 30, 12, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7148', '1', '2018-2019', 'BSCR', 'LEA5', 'Police Personnel and Records Management', 3, '', '14:00:00', '15:00:00', 'FG604', 'D', 30, 12, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7149', '1', '2018-2019', 'BSCR', 'FORSCI4', 'Questioned Documents Exam', 4, '', '15:00:00', '16:20:00', 'FG604', 'D', 30, 12, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CR', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7150', '1', '2018-2019', 'BSCR', 'CDI2', 'Traffic Management and Accident Investigation', 3, '', '13:00:00', '14:00:00', 'FG610', 'D', 45, 12, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7151', '1', '2018-2019', 'BSCR', 'CA1', 'Institutional Corrections', 3, '', '12:00:00', '13:00:00', 'FG611', 'D', 45, 12, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '7152', '1', '2018-2019', 'BSCR', 'CRIM6', 'Criminilogical Research & Statistics', 3, '', '11:00:00', '12:00:00', 'FG605', 'D', 45, 11, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7153', '1', '2018-2019', 'BSCR', 'LEA4', 'Police Intelligence', 3, '', '17:00:00', '18:00:00', 'FG610', 'D', 45, 22, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '7154', '1', '2018-2019', 'BSCR', 'ENGL34CR', 'Technical Report Writing 1', 3, '', '18:00:00', '19:00:00', 'FG610', 'D', 45, 26, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7155', '1', '2018-2019', 'BSCR', 'FORSCI3', 'Forensic Ballistics', 4, '', '19:00:00', '20:20:00', 'FG610', 'D', 45, 39, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CR', 'S', 'mn', NULL),
(1, 0, NULL, '2', '7156', '1', '2018-2019', 'BSCR', 'LEA5', 'Police Personnel and Records Management', 3, '', '17:00:00', '18:00:00', 'FG610', 'D', 45, 21, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7157', '1', '2018-2019', 'BSCR', 'CA1', 'Institutional Corrections', 3, '', '18:00:00', '19:00:00', 'FG610', 'D', 45, 18, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7158', '1', '2018-2019', 'BSCR', 'CDI2', 'Traffic Management and Accident Investigation', 3, '', '19:00:00', '20:00:00', 'FG610', 'D', 45, 25, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '7159', '1', '2018-2019', 'BSCR', 'FORSCI4', 'Questioned Documents Exam', 4, '', '20:00:00', '21:00:00', 'FG610', 'D', 45, 25, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CR', 'S', 'mn', NULL),
(1, 0, NULL, '3', '7160', '1', '2018-2019', 'BSCR', 'CRIM6', 'Criminilogical Research & Statistics', 3, '', '15:00:00', '16:00:00', 'FG610', 'D', 45, 45, 1, '0000-00-00', '11:01:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '3041', '1', '2018-2019', 'BSA', 'ACCTG32', 'Advanced Accounting 1', 6, '', '17:00:00', '19:00:00', 'AG201', 'B', 30, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '3044', '1', '2018-2019', 'BSA', 'TAX2', 'Business & Transfer Taxes', 3, '', '14:00:00', '15:00:00', 'AG201', 'D', 30, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3051', '1', '2018-2019', 'BSA', 'ACCTG32', 'Advanced Accounting 1', 6, '', '17:00:00', '19:00:00', 'AG201', 'A', 30, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '3052', '1', '2018-2019', 'BSA', 'ACCTG23', 'Financial Accounting 3', 3, '', '15:00:00', '16:00:00', 'FG206', 'MWF', 45, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5061', '1', '2018-2019', 'BEED', 'EDUC333', 'Educational Technology 2', 3, '', '13:00:00', '14:00:00', 'COMB', 'D', 40, 3, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5145', '1', '2018-2019', 'BEED', 'FS311', 'Technology in the Learning Envi.', 1, '', '07:00:00', '08:00:00', 'EM306', 'M', 45, 20, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5146', '1', '2018-2019', 'BEED', 'MR', 'Methods of Research', 3, '', '19:00:00', '20:00:00', 'EM306', 'A', 45, 24, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5147', '1', '2018-2019', 'BEED', 'ENGL311', 'Children\'s Literature', 3, '', '18:00:00', '19:00:00', 'FG210', 'D', 45, 12, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5148', '1', '2018-2019', 'BEED', 'FIL205', 'Panitikan ng Pilipinas', 3, '', '17:00:00', '18:00:00', 'AG210', 'D', 37, 14, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5149', '1', '2018-2019', 'BEED', 'PS393', 'Astronomy', 3, '', '16:00:00', '17:00:00', 'FG607', 'D', 45, 14, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5150', '1', '2018-2019', 'BEED', 'SOCSC8', 'Basic Geography', 3, '', '15:00:00', '16:00:00', 'FG302', 'D', 45, 13, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5151', '1', '2018-2019', 'BEED', 'PS313', 'Phys for Health Science', 3, '', '14:00:00', '15:00:00', 'FG410', 'D', 45, 15, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5152', '1', '2018-2019', 'BEED', 'PEACEED', 'Peace Education', 3, '', '15:00:00', '16:00:00', 'AG210', 'D', 37, 14, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5153', '1', '2018-2019', 'BEED', 'EDUC333', 'Educational Technology 2', 3, '', '16:00:00', '17:00:00', 'COMC', 'D', 35, 16, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5154', '1', '2018-2019', 'BEED', 'TSG1', 'Teaching Strategies 1 (Engl, Fil, AP)', 3, '', '18:00:00', '19:00:00', 'FG205', 'D', 45, 21, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5155', '1', '2018-2019', 'BEED', 'FS311', 'Technology in the Learning Envi.', 1, '', '07:00:00', '08:00:00', 'EM306', 'M', 45, 32, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5156', '1', '2018-2019', 'BEED', 'MR', 'Methods of Research', 3, '', '17:00:00', '18:00:00', 'EM306', 'B', 45, 34, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5157', '1', '2018-2019', 'BEED', 'ENGL311', 'Children\'s Literature', 3, '', '18:00:00', '19:00:00', 'FG210', 'D', 45, 29, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5158', '1', '2018-2019', 'BEED', 'FIL205', 'Panitikan ng Pilipinas', 3, '', '16:00:00', '17:00:00', 'FG610', 'D', 45, 34, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5159', '1', '2018-2019', 'BEED', 'PS393', 'Astronomy', 3, '', '15:00:00', '16:00:00', 'FG303', 'D', 45, 37, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5160', '1', '2018-2019', 'BEED', 'SOCSC8', 'Basic Geography', 3, '', '14:00:00', '15:00:00', 'AG210', 'D', 37, 31, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5161', '1', '2018-2019', 'BEED', 'PS313', 'Phys for Health Science', 3, '', '15:00:00', '16:00:00', 'EM306', 'D', 45, 32, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5162', '1', '2018-2019', 'BEED', 'PEACEED', 'Peace Education', 3, '', '16:00:00', '17:00:00', 'FG206', 'D', 45, 35, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5163', '1', '2018-2019', 'BEED', 'EDUC333', 'Educational Technology 2', 3, '', '13:00:00', '14:00:00', 'COMC', 'D', 35, 35, 1, '0000-00-00', '00:41:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5164', '1', '2018-2019', 'BEED', 'TSG1', 'Teaching Strategies 1 (Engl, Fil, AP)', 3, '', '18:00:00', '19:00:00', 'FG405', 'D', 45, 40, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5165', '1', '2018-2019', 'BEED', 'FS311', 'Technology in the Learning Envi.', 1, '', '07:00:00', '08:00:00', 'EM306', 'T', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5166', '1', '2018-2019', 'BEED', 'MR', 'Methods of Research', 3, '', '17:00:00', '18:00:00', 'EM306', 'B', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5167', '1', '2018-2019', 'BEED', 'SOCSC8', 'Basic Geography', 3, '', '13:00:00', '14:00:00', 'EM306', 'D', 45, 6, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5168', '1', '2018-2019', 'BEED', 'PS313', 'Phys for Health Science', 3, '', '12:00:00', '13:00:00', 'FG303', 'D', 45, 12, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5169', '1', '2018-2019', 'BEED', 'PEACEED', 'Peace Education', 3, '', '14:00:00', '15:00:00', 'AG210', 'D', 37, 13, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5170', '1', '2018-2019', 'BEED', 'EDUC333', 'Educational Technology 2', 3, '', '16:00:00', '17:00:00', 'COMC', 'D', 35, 10, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5171', '1', '2018-2019', 'BEED', 'ENGL311', 'Children\'s Literature', 3, '', '15:00:00', '16:00:00', 'EM305', 'D', 45, 10, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5172', '1', '2018-2019', 'BEED', 'FIL205', 'Panitikan ng Pilipinas', 3, '', '18:00:00', '19:00:00', 'FG312', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5173', '1', '2018-2019', 'BEED', 'PS393', 'Astronomy', 3, '', '17:00:00', '18:00:00', 'FG312', 'D', 45, 5, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5174', '1', '2018-2019', 'BEED', 'TSG1', 'Teaching Strategies 1 (Engl, Fil, AP)', 3, '', '19:00:00', '20:00:00', 'FG312', 'D', 45, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5175', '1', '2018-2019', 'BEED', 'FS311', 'Technology in the Learning Envi.', 1, '', '12:00:00', '13:00:00', 'EM306', 'S', 45, 34, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5176', '1', '2018-2019', 'BEED', 'MR', 'Methods of Research', 3, '', '18:00:00', '20:30:00', 'EM306', 'S', 45, 42, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5537', '1', '2018-2019', 'BSED', 'FS311', 'Technology in the Learning Envi.', 1, '', '08:00:00', '09:00:00', 'EM306', 'W', 45, 28, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5538', '1', '2018-2019', 'BSED', 'MR', 'Methods of Research', 3, '', '18:00:00', '19:00:00', 'EM306', 'A', 45, 34, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5539', '1', '2018-2019', 'BSED', 'ENGL313', 'Structure of the English', 3, '', '13:00:00', '14:00:00', 'AG210', 'D', 37, 34, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5540', '1', '2018-2019', 'BSED', 'EDUC302', 'Curriculum Development', 3, '', '16:00:00', '17:00:00', 'AG210', 'D', 37, 22, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5541', '1', '2018-2019', 'BSED', 'ENGL353', 'The Teaching of Speaking', 3, '', '14:00:00', '15:00:00', 'EM305', 'D', 45, 26, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5542', '1', '2018-2019', 'BSED', 'ENGL393', 'English and American Literature', 3, '', '15:00:00', '16:00:00', 'FG312', 'D', 45, 31, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5543', '1', '2018-2019', 'BSEU', 'HUM2', 'Philosophy of Man', 3, '', '17:00:00', '18:00:00', 'FG206', 'D', 45, 15, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5544', '1', '2018-2019', 'BSED', 'ENGL333', 'Literary Criticism', 3, '', '14:00:00', '15:00:00', 'EM305', 'D', 45, 21, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5545', '1', '2018-2019', 'BSED', 'EDUC333', 'Educational Technology 2', 3, '', '15:00:00', '16:00:00', 'COMB', 'D', 40, 23, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5546', '1', '2018-2019', 'BSED', 'TSE', 'Teaching Strategies in English', 3, '', '19:00:00', '20:00:00', 'FG206', 'D', 45, 25, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5547', '1', '2018-2019', 'BSED', 'FS311', 'Technology in the Learning Envi.', 1, '', '09:00:00', '10:00:00', 'EM306', 'M', 45, 16, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5548', '1', '2018-2019', 'BSED', 'MR', 'Methods of Research', 3, '', '20:00:00', '21:00:00', 'EM306', 'A', 45, 14, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5549', '1', '2018-2019', 'BSED', 'EDUC302', 'Curriculum Development', 3, '', '17:00:00', '18:00:00', 'FG210', 'D', 45, 9, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5550', '1', '2018-2019', 'BSED', 'FIL313', 'Panintikan', 3, '', '15:00:00', '16:00:00', 'AG210', 'D', 37, 9, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5551', '1', '2018-2019', 'BSED', 'FIL353', 'Panulaang Filipino', 3, '', '19:00:00', '20:00:00', 'FG205', 'D', 45, 6, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5552', '1', '2018-2019', 'BSED', 'EDUC333', 'Educational Technology 2', 3, '', '17:00:00', '18:00:00', 'COMC', 'D', 35, 16, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5553', '1', '2018-2019', 'BSED', 'FIL373', 'Pagtuturo at pagtataya sa pagbasa at pagsulat', 3, '', '14:00:00', '15:00:00', 'EM306', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5555', '1', '2018-2019', 'BSED', 'TSGF', 'Teching Strategies in Filipino', 3, '', '18:00:00', '19:00:00', 'FG211', 'D', 45, 16, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5556', '1', '2018-2019', 'BSED', 'FIL395', 'Intro sa Pananaliksik-wika at Panitikan', 3, '', '19:00:00', '20:00:00', 'FG210', 'D', 45, 6, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5557', '1', '2018-2019', 'BSED', 'FS311', 'Technology in the Learning Envi.', 1, '', '09:00:00', '10:00:00', 'EM306', 'M', 45, 23, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5558', '1', '2018-2019', 'BSED', 'MR', 'Methods of Research', 3, '', '20:00:00', '21:00:00', 'EM306', 'B', 45, 23, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5561', '1', '2018-2019', 'BSED', 'MATH201', 'Elementary Statistics', 3, '', '14:00:00', '15:00:00', 'EM306', 'D', 45, 9, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5562', '1', '2018-2019', 'BSED', 'MATH202', 'Plane Geometry', 3, '', '15:00:00', '16:00:00', 'EM306', 'D', 45, 11, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5563', '1', '2018-2019', 'BSED', 'MATH204', 'Probability', 3, '', '17:00:00', '18:00:00', 'AG208', 'D', 30, 16, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5564', '1', '2018-2019', 'BSED', 'TSGM', 'Teching Strategies in Mathematics', 3, '', '18:00:00', '19:00:00', 'FG211', 'D', 45, 19, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5565', '1', '2018-2019', 'BSED', 'MATH306', 'Abstract Algebra', 3, '', '16:00:00', '17:00:00', 'AG210', 'D', 37, 15, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5566', '1', '2018-2019', 'BSED', 'EDUC333', 'Educational Technology 2', 3, '', '15:00:00', '16:00:00', 'COMC', 'D', 35, 26, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5567', '1', '2018-2019', 'BSED', 'EDUC302', 'Curriculum Development', 3, '', '19:00:00', '20:00:00', 'FG211', 'D', 45, 15, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5568', '1', '2018-2019', 'BSED', 'LIT2', 'Literature of the World', 3, '', '12:00:00', '13:00:00', 'AG210', 'D', 37, 6, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL);
INSERT INTO `subjectssem120182019` (`OPEN`, `BLOCK`, `DISSOLVED`, `TERM`, `CN`, `SEM`, `SY`, `COURSE`, `SUBJECT`, `DESC`, `UNIT`, `CREDIT`, `TSTART`, `TEND`, `ROOM`, `SK`, `LIMIT`, `ENROLLED`, `CLOSED`, `CDATE`, `CTIME`, `LAB`, `AIR`, `MOD`, `C1`, `C2`, `C3`, `C4`, `PRN`, `AFLAG`, `DEPT`, `DEPARTMENT`, `PROGRAM`, `MAJOR`, `EMP_DP`, `EMP_NO`, `INSTRUCTOR`, `SSERVICE`, `SFCODE`, `STYPE`, `STP`, `NRLD`) VALUES
(1, 0, NULL, '3', '5569', '1', '2018-2019', 'BSED', 'PS315', 'Organic Chemistry', 3, '', '14:00:00', '15:00:00', 'CLAB', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'NE', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5570', '1', '2018-2019', 'BSED', 'PS333', 'Thermodynamics with Lab', 3, '', '16:00:00', '17:00:00', 'FG611', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5571', '1', '2018-2019', 'BSED', 'PS393', 'Astronomy', 3, '', '18:00:00', '19:00:00', 'FG302', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5177', '1', '2018-2019', 'BSED', 'ENGL311', 'Children\'s Literature', 3, '', '07:00:00', '09:30:00', 'EM305', 'S', 45, 33, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5178', '1', '2018-2019', 'BSED', 'FIL205', 'Panitikan ng Pilipinas', 3, '', '09:30:00', '12:00:00', 'EM305', 'S', 45, 34, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5179', '1', '2018-2019', 'BSED', 'PS393', 'Astronomy', 3, '', '13:00:00', '15:30:00', 'FG410', 'U', 45, 28, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5180', '1', '2018-2019', 'BSED', 'SOCSC8', 'Basic Geography', 3, '', '15:30:00', '18:00:00', 'EM305', 'S', 45, 27, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5181', '1', '2018-2019', 'BSED', 'PS313', 'Phys for Health Science', 3, '', '07:00:00', '09:30:00', 'FG410', 'U', 45, 31, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5182', '1', '2018-2019', 'BSED', 'PEACEED', 'Peace Education', 3, '', '09:30:00', '12:00:00', 'FG410', 'U', 45, 30, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5183', '1', '2018-2019', 'BEED', 'EDUC333', 'Educational Technology 2', 3, '', '15:30:00', '18:00:00', 'COMB', 'U', 40, 35, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5184', '1', '2018-2019', 'BEED', 'TSG1', 'Teaching Strategies 1 (Engl, Fil, AP)', 3, '', '13:00:00', '15:30:00', 'EM305', 'S', 45, 37, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5850', '1', '2018-2019', 'BEED', 'FS311', 'Technology in the Learning Envi.', 1, '', '08:00:00', '09:00:00', 'EM306', 'W', 45, 21, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5851', '1', '2018-2019', 'BEED', 'SPE110', 'Research in PE, Sports and Wellness', 3, '', '11:00:00', '12:00:00', 'EM306', 'A', 50, 21, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5852', '1', '2018-2019', 'BPE', 'TSPE', 'Teching Strategies in Physical Education', 3, '', '17:00:00', '18:00:00', 'FG211', 'D', 45, 25, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5853', '1', '2018-2019', 'BPE', 'SPE103', 'Intro to biomechanics & movement Ed', 3, '', '13:00:00', '14:00:00', 'EM305', 'D', 45, 22, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5855', '1', '2018-2019', 'BPE', 'SPE109', 'Int\'l Folk Dance', 3, '', '15:00:00', '16:00:00', 'EM305', 'D', 45, 19, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5856', '1', '2018-2019', 'BPE', 'SPE112', 'Comprehensive School Health Educ', 3, '', '13:00:00', '14:00:00', 'EM305', 'D', 45, 18, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5859', '1', '2018-2019', 'BPE', 'MUSIC1', 'Fundamentals of Music', 3, '', '12:00:00', '13:00:00', 'EM205', 'D', 25, 16, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5860', '1', '2018-2019', 'BPE', 'FS311', 'Technology in the Learning Envi.', 1, '', '08:00:00', '09:00:00', 'EM306', 'W', 45, 1, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5861', '1', '2018-2019', 'BPE', 'SPE110', 'Research in PE, Sports and Wellness', 3, '', '12:00:00', '13:00:00', 'EM306', 'A', 25, 0, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1057', '1', '2018-2019', 'ITE', 'IT316', 'Systems Analysis and Design', 3, '', '10:00:00', '13:00:00', 'COMA', 'F', 40, 7, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '1060', '1', '2018-2019', 'ITE', 'ITE311', 'IT Elective 1', 3, '', '18:00:00', '19:00:00', 'EM202', 'D', 30, 5, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1061', '1', '2018-2019', 'ITE', 'FCE311', 'Free Elective 1', 3, '', '18:00:00', '19:00:00', 'EM202', 'D', 30, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '7137', '1', '2018-2019', 'BSCR', 'FORSCI3', 'Forensic Ballistics', 4, '', '12:40:00', '13:00:00', 'FG509', 'D', 30, 30, 1, '0000-00-00', '11:03:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'CR', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5554', '1', '2018-2019', 'BSED', 'FIL393', 'Sanaysay at Talumpati', 3, '', '13:00:00', '14:00:00', 'EM306', 'D', 37, 12, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5560', '1', '2018-2019', 'BSED', 'HUM2', 'Philosophy of Man', 3, '', '13:00:00', '14:00:00', 'AG207', 'D', 37, 12, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5854', '1', '2018-2019', 'BPE', 'SPE115', 'Consumer Health, Drug & Safety', 3, '', '14:00:00', '15:00:00', 'AG214', 'D', 37, 19, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5857', '1', '2018-2019', 'BPE', 'EDUC206', 'Assessment of Student Learning 1', 3, '', '14:00:00', '15:00:00', 'AG214', 'D', 37, 16, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5862', '1', '2018-2019', 'BPE', 'MUSIC1', 'Fundamentals of Music', 3, '', '16:00:00', '17:00:00', 'EM205', 'D', 25, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5858', '1', '2018-2019', 'BSED', 'EDUC302', 'Curriculum Development', 3, '', '15:00:00', '16:00:00', 'AG212', 'D', 37, 11, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3063', '1', '2018-2019', 'BSA', 'FIN23', 'Financial Management 2', 3, '', '08:00:00', '09:00:00', 'FG312', 'MWF', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3064', '1', '2018-2019', 'BSA', 'TAX1', 'Income Taxation', 3, '', '09:00:00', '10:00:00', 'AG201', 'D', 30, 2, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3060', '1', '2018-2019', 'BSA', 'FIN23', 'Financial Management 2', 3, '', '12:00:00', '13:00:00', 'AG201', 'MWF', 30, 6, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3061', '1', '2018-2019', 'BSA', 'TAX1', 'Income Taxation', 3, '', '07:00:00', '08:00:00', 'FG306', 'D', 45, 6, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3062', '1', '2018-2019', 'BSA', 'FIN22', 'Financial Management 1', 3, '', '19:00:00', '20:00:00', 'FG303', 'MWF', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3065', '1', '2018-2019', 'BSA', 'ACCTG43', 'Management Accounting', 6, '', '11:00:00', '12:00:00', 'AG201', 'D', 30, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '3042', '1', '2018-2019', 'BSA', 'ACCTG23', 'Financial Accounting 3', 3, '', '15:00:00', '16:00:00', 'FG206', 'TTHS', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '3043', '1', '2018-2019', 'BSA', 'LAW3', 'Law on Negotiable Instruments', 3, '', '19:00:00', '20:00:00', 'AG201', 'MWF', 30, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1058', '1', '2018-2019', 'ITE', 'IT317', 'Internet and Web Development', 3, '', '16:00:00', '19:00:00', 'COMA', 'F', 40, 3, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '1', '5185', '1', '2018-2019', 'BEED', 'FS211', 'Learners Development & Environment', 1, '', '08:00:00', '09:00:00', 'SRED1', 'M', 45, 6, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5186', '1', '2018-2019', 'BEED', 'PE3', 'Fundl\'s of Games and Sports', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5187', '1', '2018-2019', 'BEED', 'ENGL2', 'Writing in the Disciplines', 3, '', '18:00:00', '19:00:00', 'FG410', 'D', 45, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5188', '1', '2018-2019', 'BEED', 'HUM2', 'Philosophy of Man', 3, '', '19:00:00', '20:00:00', 'FG405', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5189', '1', '2018-2019', 'BEED', 'SOCSC2', 'Basic Econ w/Tax. Land Ref. & Oth. Iss.', 3, '', '17:00:00', '18:00:00', 'RA122', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5190', '1', '2018-2019', 'BEED', 'EDUC213', 'Child & Adolescent Devt.', 3, '', '16:00:00', '17:00:00', 'EM305', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5191', '1', '2018-2019', 'BEED', 'EDUC233', 'Social Dimension of Education', 3, '', '18:00:00', '19:00:00', 'FG410', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5192', '1', '2018-2019', 'BEED', 'MATH201', 'Elementary Statistics', 3, '', '19:00:00', '20:00:00', 'FG602', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5193', '1', '2018-2019', 'BEED', 'LIT1', 'Literature of the Philippines', 3, '', '17:00:00', '18:00:00', 'RA122', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5194', '1', '2018-2019', 'BEED', 'EDUC253', 'Principle of Teaching 1', 3, '', '16:00:00', '17:00:00', 'FG409', 'D', 45, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5195', '1', '2018-2019', 'BEED', 'FS211', 'Learners Development & Environment', 1, '', '08:00:00', '09:00:00', 'SRED1', 'W', 45, 8, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5196', '1', '2018-2019', 'BEED', 'PE3', 'Fundl\'s of Games and Sports', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 7, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5205', '1', '2018-2019', 'BEED', 'FS211', 'Learners Development & Environment', 1, '', '08:00:00', '09:00:00', 'SRED1', 'T', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5206', '1', '2018-2019', 'BEED', 'PE3', 'Fundl\'s of Games and Sports', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5207', '1', '2018-2019', 'BEED', 'LIT1', 'Literature of the Philippines', 3, '', '20:00:00', '21:00:00', 'FG210', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5208', '1', '2018-2019', 'BEED', 'MATH201', 'Elementary Statistics', 3, '', '17:00:00', '18:00:00', 'RA212', 'D', 50, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5209', '1', '2018-2019', 'BEED', 'EDUC253', 'Principle of Teaching 1', 3, '', '19:00:00', '20:00:00', 'FG210', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5210', '1', '2018-2019', 'BEED', 'EDUC233', 'Social Dimension of Education', 3, '', '17:00:00', '18:00:00', 'EM305', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5211', '1', '2018-2019', 'BEED', 'SOCSC2', 'Basic Econ w/Tax. Land Ref. & Oth. Iss.', 3, '', '18:00:00', '19:00:00', 'FG512', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5212', '1', '2018-2019', 'BEED', 'HUM2', 'Philosophy of Man', 3, '', '19:00:00', '20:00:00', 'FG512', 'D', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5213', '1', '2018-2019', 'BEED', 'ENGL2', 'Writing in the Disciplines', 3, '', '20:00:00', '21:00:00', 'FG210', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5214', '1', '2018-2019', 'BEED', 'EDUC213', 'Child & Adolescent Devt.', 3, '', '18:00:00', '19:00:00', 'EM305', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5215', '1', '2018-2019', 'BEED', 'FS211', 'Learners Development & Environment', 1, '', '07:00:00', '08:00:00', 'SRED1', 'W', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5216', '1', '2018-2019', 'BEED', 'PE3', 'Fundl\'s of Games and Sports', 2, '', '06:00:00', '08:00:00', 'PC', 'S', 50, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5217', '1', '2018-2019', 'BEED', 'EDUC253', 'Principle of Teaching 1', 3, '', '18:00:00', '19:00:00', 'FG513', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5218', '1', '2018-2019', 'BEED', 'EDUC233', 'Social Dimension of Education', 3, '', '19:00:00', '20:00:00', 'FG603', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5219', '1', '2018-2019', 'BEED', 'MATH201', 'Elementary Statistics', 3, '', '16:00:00', '17:00:00', 'EM306', 'D', 45, 4, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '5220', '1', '2018-2019', 'BEED', 'LIT1', 'Literature of the Philippines', 3, '', '17:00:00', '18:00:00', 'RA124', 'D', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5221', '1', '2018-2019', 'BEED', 'ENGL2', 'Writing in the Disciplines', 3, '', '12:00:00', '13:00:00', 'FG312', 'D', 45, 3, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5222', '1', '2018-2019', 'BEED', 'EDUC213', 'Child & Adolescent Devt.', 3, '', '19:00:00', '20:00:00', 'FG311', 'D', 45, 2, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5223', '1', '2018-2019', 'BEED', 'SOCSC2', 'Basic Econ w/Tax. Land Ref. & Oth. Iss.', 3, '', '16:00:00', '17:00:00', 'FG607', 'D', 45, 4, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '5224', '1', '2018-2019', 'BEED', 'HUM2', 'Philosophy of Man', 3, '', '17:00:00', '18:00:00', 'RA214', 'D', 50, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8166', '1', '2018-2019', 'BSBA', 'MGT12', 'Human Resource Management', 3, '', '13:00:00', '14:00:00', 'AG106', 'D', 40, 30, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8171', '1', '2018-2019', 'BSBA', 'MKTG4', 'Distribution Management', 3, '', '11:00:00', '12:00:00', 'AG210', 'D', 40, 27, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '8169', '1', '2018-2019', 'BSBA', 'MGT13', 'Social Responsibility & Good Governance', 3, '', '14:00:00', '15:00:00', 'AG106', 'D', 40, 22, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '8175', '1', '2018-2019', 'BSBA', 'HUM3', 'Logic', 3, '', '16:00:00', '17:00:00', 'FG610', 'D', 45, 14, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '8151', '1', '2018-2019', 'BSBA', 'MKTG10', 'Entrepreneurial Management', 3, '', '13:00:00', '14:00:00', 'AG210', 'D', 37, 3, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '4081', '1', '2018-2019', 'BSCE', 'GE501', 'Science, Technology and Society', 3, '', '07:00:00', '08:00:00', 'FG210', 'D', 50, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4080', '1', '2018-2019', 'BSCE', 'MATH100', 'Precalculus', 6, '', '08:00:00', '10:00:00', 'EM303', 'D', 50, 45, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '4082', '1', '2018-2019', 'BSCE', 'GE401', 'Mathematics in the Modern World', 3, '', '12:00:00', '13:00:00', 'FG302', 'D', 50, 45, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4085', '1', '2018-2019', 'BSCE', 'BES112', 'Civil Engineering Orientation', 2, '', '07:00:00', '08:00:00', 'AG205', 'M-H', 50, 44, 0, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4083', '1', '2018-2019', 'BSCE', 'MATH114', 'Calculus 1', 4, '', '10:00:00', '12:00:00', 'AG205', 'M-H', 50, 45, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4086', '1', '2018-2019', 'BSCE', 'PE1', 'Health and Self Testing Activities', 2, '', '13:00:00', '15:00:00', 'PC', 'S', 50, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4087', '1', '2018-2019', 'BSCE', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'RA214', 'S', 50, 44, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4084', '1', '2018-2019', 'BSCE', 'CHEM114', 'Chemistry For Engineers', 4, '', '10:00:00', '12:00:00', 'EM302', 'D', 50, 45, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '2', '4089', '1', '2018-2019', 'BSCE', 'GE501', 'Science, Technology and Society', 3, '', '10:00:00', '11:00:00', 'FG205', 'D', 50, 37, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4088', '1', '2018-2019', 'BSCE', 'MATH100', 'Precalculus', 6, '', '10:00:00', '12:00:00', 'AG205', 'D', 50, 37, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '1', '4090', '1', '2018-2019', 'BSCE', 'GE401', 'Mathematics in the Modern World', 3, '', '08:00:00', '09:00:00', 'AG205', 'D', 50, 37, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '4093', '1', '2018-2019', 'BSCE', 'BES112', 'Civil Engineering Orientation', 2, '', '12:00:00', '13:00:00', 'AG205', 'M-H', 50, 37, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4091', '1', '2018-2019', 'BSCE', 'MATH114', 'Calculus 1', 4, '', '08:00:00', '10:00:00', 'AG205', 'M-H', 50, 37, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4092', '1', '2018-2019', 'BSCE', 'CHEM114', 'Chemistry For Engineers', 4, '', '07:00:00', '08:00:00', 'EM301', 'D', 50, 37, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mj', NULL),
(1, 0, NULL, '3', '4094', '1', '2018-2019', 'BSCE', 'PE1', 'Health and Self Testing Activities', 2, '', '13:00:00', '15:00:00', 'PC', 'S', 50, 37, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '4095', '1', '2018-2019', 'BSCE', 'NSTP1', 'National Service Training Program 1', 3, '', '08:00:00', '11:00:00', 'RA215', 'S', 50, 34, 0, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1064', '1', '2018-2019', 'ITE', 'GE101', 'Purposive Communication', 3, '', '10:00:00', '11:00:00', 'EM202', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1065', '1', '2018-2019', 'ITE', 'GE302', 'Indigenous Creative Crafts', 3, '', '10:00:00', '11:00:00', 'EM202', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '1066', '1', '2018-2019', 'ITE', 'GE204', 'Ethics', 3, '', '11:00:00', '12:00:00', 'FG603', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '1067', '1', '2018-2019', 'ITE', 'GE502', 'Enviromental Science', 3, '', '11:00:00', '12:00:00', 'FG406', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1062', '1', '2018-2019', 'ITE', 'CC101', 'Introduction to Computing', 3, '', '07:00:00', '10:00:00', 'COMA', 'T', 40, 3, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '3', '1063', '1', '2018-2019', 'ITE', 'CC102', 'Computer Programming 1', 3, '', '07:00:00', '10:00:00', 'COMA', 'H', 40, 4, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL),
(1, 0, NULL, '3', '1068', '1', '2018-2019', 'ITE', 'PE1', 'Movement Enhancement', 2, '', '10:00:00', '12:00:00', 'PC', 'S', 50, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'PE', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1069', '1', '2018-2019', 'ITE', 'CWTS1', 'National Service Training Program 1', 3, '', '13:00:00', '16:00:00', 'RA122', 'S', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'RO', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5225', '1', '2018-2019', 'BEED', 'FS211', 'Learners Development & Environment', 1, '', '07:00:00', '08:00:00', 'EM306', 'U', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5226', '1', '2018-2019', 'BEED', 'PE3', 'Fundl\'s of Games and Sports', 2, '', '06:00:00', '08:00:00', 'PC1', 'S', 50, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5227', '1', '2018-2019', 'BEED', 'ENGL2', 'Writing in the Disciplines', 3, '', '08:00:00', '10:30:00', 'RA122', 'S', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5228', '1', '2018-2019', 'BEED', 'HUM2', 'Philosophy of Man', 3, '', '10:30:00', '13:00:00', 'RA122', 'S', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5229', '1', '2018-2019', 'BEED', 'SOCSC2', 'Basic Econ w/Tax. Land Ref. & Oth. Iss.', 3, '', '13:30:00', '16:00:00', 'RA123', 'S', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5230', '1', '2018-2019', 'BEED', 'EDUC213', 'Child & Adolescent Devt.', 3, '', '16:00:00', '18:30:00', 'FG405', 'S', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5231', '1', '2018-2019', 'BEED', 'EDUC233', 'Social Dimension of Education', 3, '', '08:00:00', '10:30:00', 'FG512', 'U', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5232', '1', '2018-2019', 'BEED', 'MATH201', 'Elementary Statistics', 3, '', '10:30:00', '13:00:00', 'FG512', 'U', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5233', '1', '2018-2019', 'BEED', 'LIT1', 'Literature of the Philippines', 3, '', '13:00:00', '16:00:00', 'FG512', 'U', 45, NULL, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '5234', '1', '2018-2019', 'BEED', 'EDUC253', 'Principle of Teaching 1', 3, '', '16:00:00', '18:30:00', 'FG312', 'U', 45, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '2', '4039', '1', '2018-2019', 'BEED', 'PHILO2', 'Intro to Philosophy and Logic', 3, '', '14:00:00', '15:00:00', 'EM302', 'D', 45, 3, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '1', '6009', '1', '2018-2019', 'BSCA', 'CUST4', 'Warehousing, Economic and Freefprt Zone', 3, '', '12:00:00', '13:00:00', 'AG206', 'D', 45, 5, NULL, NULL, '00:00:00', 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, '', 'S', 'mn', NULL),
(1, 0, NULL, '3', '1016', '1', '2018-2019', 'ITE', 'CC104', 'Data Structures and Algorithm', 3, '', '10:00:00', '13:00:00', 'COMA', 'W', 40, 1, NULL, NULL, '00:00:00', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', 'U', '', 'UNASSIGNED', NULL, 'TY', 'S', 'mj', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','student','dean','teacher','cashier','finance','records') NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `student_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`, `status`, `student_id`, `created_at`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 'admin', 'approved', NULL, '2026-04-23 03:40:00'),
(4, 'dean01', '44eaab13ea356917986f6ad59bc402ae', 'dean', 'approved', NULL, '2026-04-27 06:48:16'),
(5, 'teacher01', 'bd128dc6aad0ba0b69d62f1258f66253', 'teacher', 'approved', NULL, '2026-04-27 06:48:27'),
(6, 'cashier01', '5e0fb950a170f26f6a071be306cb48ab', 'cashier', 'approved', NULL, '2026-04-27 06:48:39'),
(7, 'finance01', 'ede390aa6bb25025a134e7b5eceae59e', 'finance', 'approved', NULL, '2026-04-27 06:48:50'),
(8, 'dean', '48767461cb09465362c687ae0c44753b', 'dean', 'approved', NULL, '2026-05-01 21:00:38'),
(9, 'dean2', '48767461cb09465362c687ae0c44753b', 'dean', 'rejected', NULL, '2026-05-01 21:11:44'),
(10, 'jik', '49d46ecf58aa33473aff0feedc5a086c', 'teacher', 'rejected', NULL, '2026-05-02 15:18:43'),
(11, 'vikky@email.com', 'e10adc3949ba59abbe56e057f20f883e', 'student', 'approved', 6, '2026-05-05 13:28:47'),
(12, 'remmy@email.com', 'e10adc3949ba59abbe56e057f20f883e', 'student', 'approved', 7, '2026-05-05 13:59:53'),
(13, 'flame@email.com', 'e10adc3949ba59abbe56e057f20f883e', 'student', 'approved', 8, '2026-05-05 14:22:36'),
(14, 'remmy1@email.com', 'e10adc3949ba59abbe56e057f20f883e', 'student', 'approved', 9, '2026-05-05 15:07:18'),
(16, 'saidaljikiri@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'student', 'approved', 11, '2026-05-05 15:19:36'),
(17, 'records01', '2d6ea90d51c6e6bd05a454a4edab60bf', 'records', 'approved', NULL, '2026-05-06 14:22:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `billing_details`
--
ALTER TABLE `billing_details`
  ADD PRIMARY KEY (`billing_detail_id`),
  ADD KEY `billing_id` (`billing_id`);

--
-- Indexes for table `billing_master`
--
ALTER TABLE `billing_master`
  ADD PRIMARY KEY (`billing_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee_schedules`
--
ALTER TABLE `fee_schedules`
  ADD PRIMARY KEY (`fee_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `billing_id` (`billing_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `app_id` (`app_id`);

--
-- Indexes for table `student_subjects`
--
ALTER TABLE `student_subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `student_id` (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `billing_details`
--
ALTER TABLE `billing_details`
  MODIFY `billing_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `billing_master`
--
ALTER TABLE `billing_master`
  MODIFY `billing_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `fee_schedules`
--
ALTER TABLE `fee_schedules`
  MODIFY `fee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `student_subjects`
--
ALTER TABLE `student_subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `billing_details`
--
ALTER TABLE `billing_details`
  ADD CONSTRAINT `billing_details_ibfk_1` FOREIGN KEY (`billing_id`) REFERENCES `billing_master` (`billing_id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`billing_id`) REFERENCES `billing_master` (`billing_id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`app_id`) REFERENCES `applications` (`app_id`);

--
-- Constraints for table `student_subjects`
--
ALTER TABLE `student_subjects`
  ADD CONSTRAINT `student_subjects_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
