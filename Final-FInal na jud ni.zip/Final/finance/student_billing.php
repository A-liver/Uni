<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'finance') {
    exit("Access denied");
}

// Initialize variables
$student = null;
$searchPerformed = false;

// Handle search
if (isset($_POST['search'])) {
    $searchPerformed = true;
    $name = mysqli_real_escape_string($conn, $_POST['student']);
    $sy = mysqli_real_escape_string($conn, $_POST['sy']);
    $sem = mysqli_real_escape_string($conn, $_POST['sem']);
    
    $studentQuery = mysqli_query($conn, "
        SELECT * FROM students 
        WHERE student_id = '$name'
           OR fname LIKE '%$name%' 
           OR lname LIKE '%$name%'
        LIMIT 1
    ");
    
    if ($studentQuery && mysqli_num_rows($studentQuery) > 0) {
        $student = mysqli_fetch_assoc($studentQuery);
        $studentId = $student['student_id'];
        
        // Get student subjects for the specified period
        $subjectsQuery = mysqli_query($conn, "
            SELECT * FROM student_subjects 
            WHERE student_id = '$studentId' AND sy = '$sy' AND sem = '$sem'
        ");
        
        $totalUnits = 0;
        $subjects = [];
        if ($subjectsQuery) {
            while ($row = mysqli_fetch_assoc($subjectsQuery)) {
                $subjects[] = $row;
                $totalUnits += $row['units'];
            }
        }
        
        // Get billing information
        $billingQuery = mysqli_query($conn, "
            SELECT * FROM billing_master 
            WHERE student_id = '$studentId' AND sy = '$sy' AND sem = '$sem'
        ");
        $billing = mysqli_fetch_assoc($billingQuery);
        
        // Get fee schedules
        $feeSchedulesQuery = mysqli_query($conn, "
            SELECT * FROM fee_schedules
        ");
        
        // Initialize variables
        $totalPaid = 0;
        $payments = [];
        $balance = 0;
        
        // Only get billing details and payments if billing exists
        if ($billing) {
            // Get billing details
            $billingDetailsQuery = mysqli_query($conn, "
                SELECT bd.*, fs.fee_name, fs.category 
                FROM billing_details bd
                LEFT JOIN fee_schedules fs ON bd.fee_id = fs.fee_id
                WHERE bd.billing_id = '{$billing['billing_id']}'
            ");
            
            // Get payment history
            $paymentQuery = mysqli_query($conn, "
                SELECT * FROM payments 
                WHERE billing_id = '{$billing['billing_id']}'
                ORDER BY payment_date DESC
            ");
            
            if ($paymentQuery) {
                while ($row = mysqli_fetch_assoc($paymentQuery)) {
                    $payments[] = $row;
                    $totalPaid += $row['amount_paid'];
                }
            }
            
            $balance = ($billing['total_amount'] ?? 0) - $totalPaid;
        }
    }
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-search"></i> Student Billing Search
            </h1>
        </div>
    </div>

    <!-- Search Form -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-filter"></i> Search Criteria
            </h2>
        </div>
        <div class="card-body">
            <form method="POST" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="form-label">Student Name/ID:</label>
                    <input type="text" name="student" class="form-input" placeholder="Enter student name or ID" required 
                           value="<?= isset($_POST['student']) ? htmlspecialchars($_POST['student']) : '' ?>">
                </div>
                <div>
                    <label class="form-label">School Year:</label>
                    <input type="text" name="sy" class="form-input" placeholder="e.g., 2023-2024" required
                           value="<?= isset($_POST['sy']) ? htmlspecialchars($_POST['sy']) : '' ?>">
                </div>
                <div>
                    <label class="form-label">Semester:</label>
                    <input type="text" name="sem" class="form-input" placeholder="e.g., 1st" required
                           value="<?= isset($_POST['sem']) ? htmlspecialchars($_POST['sem']) : '' ?>">
                </div>
                <div class="flex items-end">
                    <button type="submit" name="search" class="btn btn-primary">
                        <i class="fas fa-search"></i> Search Billing
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($searchPerformed && $student): ?>
        <!-- Student Information -->
        <div class="card mb-6">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-user"></i> Student Information
                </h3>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                        <span class="text-secondary text-sm">Student ID</span>
                        <div class="font-semibold"><?= $student['student_id'] ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Full Name</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['lname'] . ', ' . $student['fname']) ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Course</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['course']) ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Period</span>
                        <div class="font-semibold"><?= htmlspecialchars($_POST['sy']) ?> - Semester <?= htmlspecialchars($_POST['sem']) ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Student Load Summary -->
        <div class="card mb-6">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-book"></i> Student Load Summary
                </h3>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-3 gap-4 mb-4">
                    <div class="text-center p-4 bg-blue-50 rounded">
                        <div class="text-2xl font-bold text-blue-600"><?= count($subjects) ?></div>
                        <div class="text-sm text-blue-500">Total Subjects</div>
                    </div>
                    <div class="text-center p-4 bg-green-50 rounded">
                        <div class="text-2xl font-bold text-green-600"><?= $totalUnits ?></div>
                        <div class="text-sm text-green-500">Total Units</div>
                    </div>
                    <div class="text-center p-4 bg-purple-50 rounded">
                        <div class="text-2xl font-bold text-purple-600"><?= $totalUnits * 300 ?></div>
                        <div class="text-sm text-purple-500">Tuition (₱300/unit)</div>
                    </div>
                </div>
                
                <?php if (!empty($subjects)): ?>
                    <h4 class="font-semibold mb-3">Enrolled Subjects</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Subject Code</th>
                                    <th>Units</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($subjects as $subject): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($subject['subject_code']) ?></td>
                                        <td><span class="badge badge-info"><?= $subject['units'] ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">No subjects found for this period.</div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Fee Schedules -->
        <div class="card mb-6">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-list"></i> Fee Schedules
                </h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Fee Name</th>
                                <th>Category</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $feeTotal = 0;
                            if ($feeSchedulesQuery && mysqli_num_rows($feeSchedulesQuery) > 0):
                                while ($fee = mysqli_fetch_assoc($feeSchedulesQuery)): 
                                    $feeTotal += $fee['amount'];
                            ?>
                                <tr>
                                    <td><?= htmlspecialchars($fee['fee_name']) ?></td>
                                    <td><span class="badge badge-secondary"><?= htmlspecialchars($fee['category']) ?></span></td>
                                    <td>₱<?= number_format($fee['amount'], 2) ?></td>
                                </tr>
                            <?php 
                                endwhile;
                            else:
                            ?>
                                <tr>
                                    <td colspan="3" class="text-center">No fee schedules configured</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="font-bold">
                                <td colspan="2">Total Fees</td>
                                <td>₱<?= number_format($feeTotal, 2) ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Billing Details -->
        <?php if ($billing): ?>
        <div class="card mb-6">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-file-invoice"></i> Billing Details
                </h3>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-4 gap-4 mb-4">
                    <div class="text-center p-4 bg-blue-50 rounded">
                        <div class="text-2xl font-bold text-blue-600">₱<?= number_format($billing['total_amount'], 2) ?></div>
                        <div class="text-sm text-blue-500">Total Amount</div>
                    </div>
                    <div class="text-center p-4 bg-green-50 rounded">
                        <div class="text-2xl font-bold text-green-600">₱<?= number_format($totalPaid, 2) ?></div>
                        <div class="text-sm text-green-500">Amount Paid</div>
                    </div>
                    <div class="text-center p-4 bg-red-50 rounded">
                        <div class="text-2xl font-bold text-red-600">₱<?= number_format($balance, 2) ?></div>
                        <div class="text-sm text-red-500">Balance</div>
                    </div>
                    <div class="text-center p-4 bg-yellow-50 rounded">
                        <div class="text-2xl font-bold text-yellow-600"><?= ucfirst($billing['status']) ?></div>
                        <div class="text-sm text-yellow-500">Status</div>
                    </div>
                </div>
                
                <?php if (!empty($payments)): ?>
                    <h4 class="font-semibold mb-3">Payment History</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Receipt</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($payments as $payment): ?>
                                    <tr>
                                        <td><?= date('M d, Y h:i A', strtotime($payment['payment_date'])) ?></td>
                                        <td>₱<?= number_format($payment['amount_paid'], 2) ?></td>
                                        <td>
                                            <a href="../cashier/receipt.php?id=<?= $payment['payment_id'] ?>" class="btn btn-outline btn-sm" target="_blank">
                                                <i class="fas fa-receipt"></i> View
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">No payments recorded yet.</div>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i> No billing record found for this student and period.
            </div>
        <?php endif; ?>
        
    <?php elseif ($searchPerformed && !$student): ?>
        <div class="alert alert-error">
            <i class="fas fa-times-circle"></i> Student not found. Please check the name or ID and try again.
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> Enter student details above to view billing information.
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
