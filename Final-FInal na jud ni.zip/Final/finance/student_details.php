<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'finance') {
    exit("Access denied");
}

// Get student ID from URL parameter
$studentId = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';

if (empty($studentId)) {
    echo "<div class='alert alert-error'>No student ID provided</div>";
    echo "<a href='finance_dashboard.php'>← Back to Dashboard</a>";
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

// Get student information
$studentQuery = mysqli_query($conn, "SELECT * FROM students WHERE student_id = '$studentId'");
$student = mysqli_fetch_assoc($studentQuery);

if (!$student) {
    echo "<div class='alert alert-error'>Student not found</div>";
    echo "<a href='finance_dashboard.php'>← Back to Dashboard</a>";
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

// Get billing records for this student
$billingQuery = mysqli_query($conn, "
    SELECT * FROM billing_master 
    WHERE student_id = '$studentId'
    ORDER BY sy DESC, sem DESC
");
$billingRecords = [];
if ($billingQuery) {
    while ($row = mysqli_fetch_assoc($billingQuery)) {
        $billingRecords[] = $row;
    }
}

// Get payment history
$paymentHistory = [];
if (!empty($billingRecords)) {
    $billingIds = array_column($billingRecords, 'billing_id');
    if (!empty($billingIds)) {
        $billingIdList = implode(',', $billingIds);
        $historyQuery = mysqli_query($conn, "
            SELECT p.*, bm.sy, bm.sem 
            FROM payments p
            JOIN billing_master bm ON bm.billing_id = p.billing_id
            WHERE p.billing_id IN ($billingIdList)
            ORDER BY p.payment_date DESC
        ");
        
        if ($historyQuery) {
            while ($row = mysqli_fetch_assoc($historyQuery)) {
                $paymentHistory[] = $row;
            }
        }
    }
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>👤 Student Financial Details</h1>
            <p class="text-secondary">View billing and payment information for <?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?></p>
        </div>
        <a href="finance_dashboard.php" class="btn btn-outline">
            ← Back to Dashboard
        </a>
    </div>

    <!-- Student Information -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">Student Information</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                    <span class="text-secondary text-sm">Student ID</span>
                    <div class="font-semibold"><?= $student['student_id'] ?></div>
                </div>
                <div>
                    <span class="text-secondary text-sm">Full Name</span>
                    <div class="font-semibold"><?= htmlspecialchars($student['lname'] . ', ' . $student['fname']) ?></div>
                </div>
                <div>
                    <span class="text-secondary text-sm">Course</span>
                    <div class="font-semibold"><?= htmlspecialchars($student['course'] ?? 'N/A') ?></div>
                </div>
                <div>
                    <span class="text-secondary text-sm">Email</span>
                    <div class="font-semibold"><?= htmlspecialchars($student['email'] ?? 'N/A') ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Billing Records -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">📋 Billing Records</h2>
        </div>
        <div class="card-body">
            <?php if (!empty($billingRecords)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>School Year</th>
                                <th>Semester</th>
                                <th>Total Units</th>
                                <th>Total Amount</th>
                                <th>Status</th>
                                <th>Balance</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($billingRecords as $billing): ?>
                                <?php
                                // Get payments for this billing
                                $paymentsQuery = mysqli_query($conn, "
                                    SELECT SUM(amount_paid) as total 
                                    FROM payments 
                                    WHERE billing_id = '{$billing['billing_id']}'
                                ");
                                $totalPaid = 0;
                                if ($paymentsQuery) {
                                    $paid = mysqli_fetch_assoc($paymentsQuery);
                                    $totalPaid = $paid['total'] ?? 0;
                                }
                                $balance = $billing['total_amount'] - $totalPaid;
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($billing['sy']) ?></td>
                                    <td><?= htmlspecialchars($billing['sem']) ?></td>
                                    <td><?= $billing['total_units'] ?? 0 ?></td>
                                    <td>₱<?= number_format($billing['total_amount'], 2) ?></td>
                                    <td>
                                        <span class="badge badge-<?= $billing['status'] == 'paid' ? 'success' : ($billing['status'] == 'partial' ? 'warning' : 'danger') ?>">
                                            <?= ucfirst($billing['status']) ?>
                                        </span>
                                    </td>
                                    <td>₱<?= number_format($balance, 2) ?></td>
                                    <td>
                                        <button onclick='showBillingDetails(<?= $billing['billing_id'] ?>)' class='btn btn-outline btn-sm'>
                                            📋 Details
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Financial Summary -->
                <?php
                $totalBilled = array_sum(array_column($billingRecords, 'total_amount'));
                $totalPaidAll = 0;
                foreach ($billingRecords as $billing) {
                    $paymentsQuery = mysqli_query($conn, "
                        SELECT SUM(amount_paid) as total 
                        FROM payments 
                        WHERE billing_id = '{$billing['billing_id']}'
                    ");
                    if ($paymentsQuery) {
                        $paid = mysqli_fetch_assoc($paymentsQuery);
                        $totalPaidAll += $paid['total'] ?? 0;
                    }
                }
                $totalBalance = $totalBilled - $totalPaidAll;
                ?>
                
                <div class="grid grid-cols-3 gap-4 mt-6">
                    <div class="text-center p-4 border rounded">
                        <h4>Total Billed</h4>
                        <div class="text-2xl font-bold text-primary">₱<?= number_format($totalBilled, 2) ?></div>
                    </div>
                    <div class="text-center p-4 border rounded">
                        <h4>Total Paid</h4>
                        <div class="text-2xl font-bold text-success">₱<?= number_format($totalPaidAll, 2) ?></div>
                    </div>
                    <div class="text-center p-4 border rounded">
                        <h4>Outstanding Balance</h4>
                        <div class="text-2xl font-bold text-danger">₱<?= number_format($totalBalance, 2) ?></div>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    No billing records found for this student.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Payment History -->
    <?php if (!empty($paymentHistory)): ?>
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">💳 Payment History</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>School Year</th>
                                <th>Semester</th>
                                <th>Amount</th>
                                <th>Receipt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($paymentHistory as $payment): ?>
                                <tr>
                                    <td><?= date('M d, Y h:i A', strtotime($payment['payment_date'])) ?></td>
                                    <td><?= htmlspecialchars($payment['sy']) ?></td>
                                    <td><?= htmlspecialchars($payment['sem']) ?></td>
                                    <td>₱<?= number_format($payment['amount_paid'], 2) ?></td>
                                    <td>
                                        <a href="../cashier/receipt.php?id=<?= $payment['id'] ?>" class="btn btn-outline btn-sm" target="_blank">
                                            🧾 Receipt
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Billing Details Modal -->
    <div id="billingDetailsModal" class="modal" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); z-index: 1000;">
        <div class="modal-content" style="position: relative; background-color: white; margin: 10% auto; padding: 20px; width: 80%; max-width: 800px; border-radius: 8px;">
            <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h3>Billing Details</h3>
                <button onclick='closeBillingDetails()' class="btn btn-outline">&times;</button>
            </div>
            <div class="modal-body" id="billingDetailsContent">
                <p>Loading billing details...</p>
            </div>
        </div>
    </div>

    <script>
    function showBillingDetails(billingId) {
        const modal = document.getElementById('billingDetailsModal');
        const content = document.getElementById('billingDetailsContent');
        
        content.innerHTML = '<p>Loading billing details...</p>';
        modal.style.display = 'block';
        
        // AJAX call to load billing details
        fetch('../cashier/get_billing_details.php?id=' + billingId)
            .then(response => response.text())
            .then(data => {
                content.innerHTML = data;
            })
            .catch(error => {
                content.innerHTML = '<p>Error loading billing details.</p>';
            });
    }
    
    function closeBillingDetails() {
        document.getElementById('billingDetailsModal').style.display = 'none';
    }
    </script>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
