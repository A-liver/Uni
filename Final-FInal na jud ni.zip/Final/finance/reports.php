<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'finance') {
    exit("Access denied");
}

// Get finance statistics for reports
$totalRevenueQuery = mysqli_query($conn, "
    SELECT SUM(amount_paid) as total_revenue, COUNT(*) as total_transactions
    FROM payments
");
$revenueStats = mysqli_fetch_assoc($totalRevenueQuery);

$pendingBillingQuery = mysqli_query($conn, "
    SELECT COUNT(*) as pending_count, SUM(total_amount) as pending_amount
    FROM billing_master
    WHERE status = 'unpaid' OR status = 'partial'
");
$pendingStats = mysqli_fetch_assoc($pendingBillingQuery);

// Get monthly revenue data
$monthlyRevenueQuery = mysqli_query($conn, "
    SELECT 
        DATE_FORMAT(payment_date, '%Y-%m') as month,
        SUM(amount_paid) as revenue,
        COUNT(*) as transactions
    FROM payments
    WHERE payment_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(payment_date, '%Y-%m')
    ORDER BY month DESC
");

$monthlyData = [];
while ($row = mysqli_fetch_assoc($monthlyRevenueQuery)) {
    $monthlyData[] = $row;
}

// Get fee category breakdown
$feeBreakdownQuery = mysqli_query($conn, "
    SELECT 
        fs.category,
        COUNT(*) as count,
        SUM(fs.amount) as total
    FROM fee_schedules fs
    GROUP BY fs.category
");

$feeCategories = [];
while ($row = mysqli_fetch_assoc($feeBreakdownQuery)) {
    $feeCategories[] = $row;
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-file-invoice"></i> Financial Reports
            </h1>
        </div>
    </div>

    <!-- Summary Statistics -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value">₱<?= number_format($revenueStats['total_revenue'] ?? 0, 2) ?></div>
            <div class="stat-label">
                <i class="fas fa-money-bill-wave"></i> Total Revenue
            </div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $revenueStats['total_transactions'] ?? 0 ?></div>
            <div class="stat-label">
                <i class="fas fa-exchange-alt"></i> Total Transactions
            </div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value">₱<?= number_format($pendingStats['pending_amount'] ?? 0, 2) ?></div>
            <div class="stat-label">
                <i class="fas fa-clock"></i> Outstanding Balance
            </div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= $pendingStats['pending_count'] ?? 0 ?></div>
            <div class="stat-label">
                <i class="fas fa-exclamation-triangle"></i> Pending Billings
            </div>
        </div>
    </div>

    <!-- Monthly Revenue Report -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-chart-bar"></i> Monthly Revenue Report
            </h2>
            <p class="text-sm text-secondary">Last 12 months revenue summary</p>
        </div>
        <div class="card-body">
            <?php if (!empty($monthlyData)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Month</th>
                                <th>Revenue</th>
                                <th>Transactions</th>
                                <th>Average per Transaction</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($monthlyData as $data): 
                                $avg = $data['transactions'] > 0 ? $data['revenue'] / $data['transactions'] : 0;
                            ?>
                                <tr>
                                    <td><?= date('F Y', strtotime($data['month'] . '-01')) ?></td>
                                    <td><span class="badge badge-success">₱<?= number_format($data['revenue'], 2) ?></span></td>
                                    <td><?= $data['transactions'] ?></td>
                                    <td>₱<?= number_format($avg, 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> No revenue data available for the last 12 months.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Fee Category Breakdown -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-pie-chart"></i> Fee Category Breakdown
            </h2>
            <p class="text-sm text-secondary">Distribution of fees by category</p>
        </div>
        <div class="card-body">
            <?php if (!empty($feeCategories)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Fee Count</th>
                                <th>Total Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $totalFees = 0;
                            foreach ($feeCategories as $category): 
                                $totalFees += $category['total'];
                            ?>
                                <tr>
                                    <td>
                                        <span class="badge badge-primary"><?= htmlspecialchars($category['category']) ?></span>
                                    </td>
                                    <td><?= $category['count'] ?></td>
                                    <td>₱<?= number_format($category['total'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr class="font-bold">
                                <td colspan="2">Total All Categories</td>
                                <td>₱<?= number_format($totalFees, 2) ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-circle"></i> No fee categories configured.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Print Report Button -->
    <div class="card">
        <div class="card-body text-center">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Print Report
            </button>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
