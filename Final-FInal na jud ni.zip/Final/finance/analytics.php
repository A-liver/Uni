<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'finance') {
    exit("Access denied");
}

// Get key analytics data
// Revenue trends
$revenueTrendQuery = mysqli_query($conn, "
    SELECT 
        DATE_FORMAT(payment_date, '%Y-%m') as month,
        SUM(amount_paid) as revenue
    FROM payments
    WHERE payment_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(payment_date, '%Y-%m')
    ORDER BY month ASC
");

$revenueTrend = [];
while ($row = mysqli_fetch_assoc($revenueTrendQuery)) {
    $revenueTrend[] = $row;
}

// Payment status distribution
$statusQuery = mysqli_query($conn, "
    SELECT 
        status,
        COUNT(*) as count,
        SUM(total_amount) as amount
    FROM billing_master
    GROUP BY status
");

$statusData = [];
while ($row = mysqli_fetch_assoc($statusQuery)) {
    $statusData[] = $row;
}

// Top paying students
$topStudentsQuery = mysqli_query($conn, "
    SELECT 
        s.student_id,
        CONCAT(s.lname, ', ', s.fname) as student_name,
        SUM(p.amount_paid) as total_paid,
        COUNT(p.payment_id) as payment_count
    FROM students s
    JOIN billing_master bm ON s.student_id = bm.student_id
    JOIN payments p ON bm.billing_id = p.billing_id
    GROUP BY s.student_id, s.lname, s.fname
    ORDER BY total_paid DESC
    LIMIT 10
");

$topStudents = [];
while ($row = mysqli_fetch_assoc($topStudentsQuery)) {
    $topStudents[] = $row;
}

// Course revenue analysis
$courseRevenueQuery = mysqli_query($conn, "
    SELECT 
        s.course,
        COUNT(DISTINCT s.student_id) as student_count,
        SUM(p.amount_paid) as total_revenue
    FROM students s
    JOIN billing_master bm ON s.student_id = bm.student_id
    JOIN payments p ON bm.billing_id = p.billing_id
    GROUP BY s.course
    ORDER BY total_revenue DESC
");

$courseRevenue = [];
while ($row = mysqli_fetch_assoc($courseRevenueQuery)) {
    $courseRevenue[] = $row;
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-chart-pie"></i> Financial Analytics
            </h1>
        </div>
    </div>

    <!-- Payment Status Distribution -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-chart-pie"></i> Payment Status Distribution
            </h2>
            <p class="text-sm text-secondary">Overview of billing statuses</p>
        </div>
        <div class="card-body">
            <?php if (!empty($statusData)): ?>
                <div class="stats-grid">
                    <?php foreach ($statusData as $status): 
                        $color = match($status['status']) {
                            'paid' => 'success',
                            'partial' => 'warning',
                            'unpaid' => 'danger',
                            default => 'secondary'
                        };
                    ?>
                        <div class="stat-card <?= $color ?>">
                            <div class="stat-value"><?= $status['count'] ?></div>
                            <div class="stat-label"><?= ucfirst($status['status']) ?> Billings</div>
                            <div class="text-sm mt-2">₱<?= number_format($status['amount'], 2) ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> No billing data available.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Revenue Trend -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-chart-line"></i> Revenue Trend (Last 6 Months)
            </h2>
            <p class="text-sm text-secondary">Monthly revenue progression</p>
        </div>
        <div class="card-body">
            <?php if (!empty($revenueTrend)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Month</th>
                                <th>Revenue</th>
                                <th>Trend</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $prevRevenue = 0;
                            foreach ($revenueTrend as $index => $data): 
                                $change = $prevRevenue > 0 ? (($data['revenue'] - $prevRevenue) / $prevRevenue) * 100 : 0;
                                $trendIcon = $change > 0 ? 'fa-arrow-up text-success' : ($change < 0 ? 'fa-arrow-down text-danger' : 'fa-minus text-secondary');
                                $trendText = $change > 0 ? '+' . number_format($change, 1) . '%' : number_format($change, 1) . '%';
                            ?>
                                <tr>
                                    <td><?= date('F Y', strtotime($data['month'] . '-01')) ?></td>
                                    <td><span class="badge badge-success">₱<?= number_format($data['revenue'], 2) ?></span></td>
                                    <td>
                                        <?php if ($index > 0): ?>
                                            <i class="fas <?= $trendIcon ?>"></i> <?= $trendText ?>
                                        <?php else: ?>
                                            <span class="text-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php 
                                $prevRevenue = $data['revenue'];
                            endforeach; 
                            ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> No revenue trend data available.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Top Paying Students -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-trophy"></i> Top Paying Students
            </h2>
            <p class="text-sm text-secondary">Students with highest payment amounts</p>
        </div>
        <div class="card-body">
            <?php if (!empty($topStudents)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Student</th>
                                <th>Total Paid</th>
                                <th>Payments</th>
                                <th>Average</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($topStudents as $index => $student): 
                                $avg = $student['payment_count'] > 0 ? $student['total_paid'] / $student['payment_count'] : 0;
                            ?>
                                <tr>
                                    <td>
                                        <?php if ($index < 3): ?>
                                            <span class="badge badge-warning">#<?= $index + 1 ?></span>
                                        <?php else: ?>
                                            <?= $index + 1 ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($student['student_name']) ?></td>
                                    <td><span class="badge badge-success">₱<?= number_format($student['total_paid'], 2) ?></span></td>
                                    <td><?= $student['payment_count'] ?></td>
                                    <td>₱<?= number_format($avg, 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> No payment data available.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Course Revenue Analysis -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-graduation-cap"></i> Revenue by Course
            </h2>
            <p class="text-sm text-secondary">Financial breakdown by academic course</p>
        </div>
        <div class="card-body">
            <?php if (!empty($courseRevenue)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Course</th>
                                <th>Student Count</th>
                                <th>Total Revenue</th>
                                <th>Revenue per Student</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($courseRevenue as $course): 
                                $perStudent = $course['student_count'] > 0 ? $course['total_revenue'] / $course['student_count'] : 0;
                            ?>
                                <tr>
                                    <td><span class="badge badge-primary"><?= htmlspecialchars($course['course']) ?></span></td>
                                    <td><?= $course['student_count'] ?></td>
                                    <td><span class="badge badge-success">₱<?= number_format($course['total_revenue'], 2) ?></span></td>
                                    <td>₱<?= number_format($perStudent, 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> No course revenue data available.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
