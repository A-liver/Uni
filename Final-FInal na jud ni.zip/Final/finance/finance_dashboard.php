<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'finance') {
    exit("Access denied");
}

// Get finance statistics
$totalRevenueQuery = mysqli_query($conn, "
    SELECT SUM(amount_paid) as total_revenue, COUNT(*) as total_transactions
    FROM payments
");
$revenueStats = mysqli_fetch_assoc($totalRevenueQuery);

$pendingBillingQuery = mysqli_query($conn, "
    SELECT COUNT(*) as pending_count
    FROM billing_master
    WHERE status = 'unpaid' OR status = 'partial'
");
$pendingStats = mysqli_fetch_assoc($pendingBillingQuery);
?>

<div class="fade-in">
    <h1>Finance Dashboard</h1>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value">₱<?= number_format($revenueStats['total_revenue'] ?? 0, 2) ?></div>
            <div class="stat-label">
                <i class="fas fa-money-bill-wave"></i> Total Revenue
            </div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $revenueStats['total_transactions'] ?? 0 ?></div>
            <div class="stat-label">
                <i class="fas fa-exchange-alt"></i> Total Transactions
            </div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= $pendingStats['pending_count'] ?? 0 ?></div>
            <div class="stat-label">
                <i class="fas fa-clock"></i> Pending Billings
            </div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= date('Y') ?></div>
            <div class="stat-label">
                <i class="fas fa-calendar"></i> Current Year
            </div>
        </div>
    </div>

    <!-- Important Notices -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 Finance Information</h2>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <strong>Billing Cycle:</strong> Generate student billings at the start of each semester.
            </div>
            <div class="alert alert-warning">
                <strong>Payment Tracking:</strong> Monitor outstanding balances and follow up on overdue payments.
            </div>
            <p class="text-secondary">
                For financial discrepancies or reporting issues, contact the system administrator.
            </p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>