<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'finance') {
    exit("Access denied");
}

// Get finance statistics
$totalRevenueQuery = mysqli_query($conn, "
    SELECT SUM(amount_paid) as total_revenue, COUNT(*) as total_transactions
    FROM payments
");
$revenueStats = mysqli_fetch_assoc($totalRevenueQuery);

$pendingBillingQuery = mysqli_query($conn, "
    SELECT COUNT(*) as pending_count
    FROM billing_master
    WHERE status = 'unpaid' OR status = 'partial'
");
$pendingStats = mysqli_fetch_assoc($pendingBillingQuery);

// Handle student search
$student = null;
$billingRecords = null;
$message = '';

if (isset($_POST['search'])) {
    $searchTerm = mysqli_real_escape_string($conn, $_POST['student']);
    
    // Simple student search
    $studentQuery = mysqli_query($conn, "
        SELECT * FROM students 
        WHERE student_id = '$searchTerm' 
        OR fname LIKE '%$searchTerm%' 
        OR lname LIKE '%$searchTerm%'
        LIMIT 1
    ");
    
    if ($studentQuery && mysqli_num_rows($studentQuery) > 0) {
        $student = mysqli_fetch_assoc($studentQuery);
        
        // Get billing records for this student
        $billingQuery = mysqli_query($conn, "
            SELECT * FROM billing_master 
            WHERE student_id = '{$student['student_id']}'
            ORDER BY sy DESC, sem DESC
        ");
        
        if ($billingQuery) {
            $billingRecords = [];
            while ($row = mysqli_fetch_assoc($billingQuery)) {
                $billingRecords[] = $row;
            }
        }
        
        $message = "Student found: " . htmlspecialchars($student['fname'] . ' ' . $student['lname']);
    } else {
        $message = "Student not found. Please try a different search term.";
    }
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>📊 Finance Dashboard</h1>
            <p class="text-secondary">View student billing and financial reports</p>
        </div>
        <a href="../auth/logout.php" class="btn btn-outline">
            🚪 Logout
        </a>
    </div>

    <!-- Statistics -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value">₱<?= number_format($revenueStats['total_revenue'] ?? 0, 2) ?></div>
            <div class="stat-label">Total Revenue</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $revenueStats['total_transactions'] ?? 0 ?></div>
            <div class="stat-label">Total Transactions</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= $pendingStats['pending_count'] ?? 0 ?></div>
            <div class="stat-label">Pending Billings</div>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= strpos($message, 'found') !== false ? 'success' : 'error' ?> mb-6">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Student Search -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">🔍 Search Student Billing</h2>
        </div>
        <div class="card-body">
            <form method="POST" class="flex gap-4">
                <div class="flex-1">
                    <input type="text" name="student" class="form-input" placeholder="Enter Student ID, First Name, or Last Name" required>
                </div>
                <button type="submit" name="search" class="btn btn-primary">
                    🔍 Search
                </button>
            </form>
        </div>
    </div>

    <!-- Student Information -->
    <?php if ($student): ?>
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">👤 Student Information</h2>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                        <span class="text-secondary text-sm">Student ID</span>
                        <div class="font-semibold"><?= $student['student_id'] ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Name</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['lname'] . ', ' . $student['fname']) ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Course</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['course'] ?? 'N/A') ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Email</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['email'] ?? 'N/A') ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Billing Records -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">📋 Billing Records</h2>
            </div>
            <div class="card-body">
                <?php if ($billingRecords && count($billingRecords) > 0): ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>School Year</th>
                                    <th>Semester</th>
                                    <th>Total Units</th>
                                    <th>Total Amount</th>
                                    <th>Status</th>
                                    <th>Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($billingRecords as $billing): ?>
                                    <?php
                                    // Get payments for this billing
                                    $paymentsQuery = mysqli_query($conn, "
                                        SELECT SUM(amount_paid) as total 
                                        FROM payments 
                                        WHERE billing_id = '{$billing['billing_id']}'
                                    ");
                                    $totalPaid = 0;
                                    if ($paymentsQuery) {
                                        $paid = mysqli_fetch_assoc($paymentsQuery);
                                        $totalPaid = $paid['total'] ?? 0;
                                    }
                                    $balance = $billing['total_amount'] - $totalPaid;
                                    ?>
                                    <tr>
                                        <td><?= htmlspecialchars($billing['sy']) ?></td>
                                        <td><?= htmlspecialchars($billing['sem']) ?></td>
                                        <td><?= $billing['total_units'] ?? 0 ?></td>
                                        <td>₱<?= number_format($billing['total_amount'], 2) ?></td>
                                        <td>
                                            <span class="badge badge-<?= $billing['status'] == 'paid' ? 'success' : ($billing['status'] == 'partial' ? 'warning' : 'danger') ?>">
                                                <?= ucfirst($billing['status']) ?>
                                            </span>
                                        </td>
                                        <td>₱<?= number_format($balance, 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Financial Summary -->
                    <?php
                    $totalBilled = array_sum(array_column($billingRecords, 'total_amount'));
                    $totalPaidAll = 0;
                    foreach ($billingRecords as $billing) {
                        $paymentsQuery = mysqli_query($conn, "
                            SELECT SUM(amount_paid) as total 
                            FROM payments 
                            WHERE billing_id = '{$billing['billing_id']}'
                        ");
                        if ($paymentsQuery) {
                            $paid = mysqli_fetch_assoc($paymentsQuery);
                            $totalPaidAll += $paid['total'] ?? 0;
                        }
                    }
                    $totalBalance = $totalBilled - $totalPaidAll;
                    ?>
                    
                    <div class="grid grid-cols-3 gap-4 mt-6">
                        <div class="text-center p-4 border rounded">
                            <h4>Total Billed</h4>
                            <div class="text-2xl font-bold text-primary">₱<?= number_format($totalBilled, 2) ?></div>
                        </div>
                        <div class="text-center p-4 border rounded">
                            <h4>Total Paid</h4>
                            <div class="text-2xl font-bold text-success">₱<?= number_format($totalPaidAll, 2) ?></div>
                        </div>
                        <div class="text-center p-4 border rounded">
                            <h4>Outstanding Balance</h4>
                            <div class="text-2xl font-bold text-danger">₱<?= number_format($totalBalance, 2) ?></div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">
                        No billing records found for this student.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Payment History -->
        <?php
        $paymentHistory = [];
        if ($billingRecords) {
            $billingIds = array_column($billingRecords, 'billing_id');
            if (!empty($billingIds)) {
                $billingIdList = implode(',', $billingIds);
                $historyQuery = mysqli_query($conn, "
                    SELECT p.*, bm.sy, bm.sem 
                    FROM payments p
                    JOIN billing_master bm ON bm.billing_id = p.billing_id
                    WHERE p.billing_id IN ($billingIdList)
                    ORDER BY p.payment_date DESC
                ");
                
                if ($historyQuery) {
                    while ($row = mysqli_fetch_assoc($historyQuery)) {
                        $paymentHistory[] = $row;
                    }
                }
            }
        }
        ?>
        
        <?php if (!empty($paymentHistory)): ?>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">💳 Payment History</h2>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>School Year</th>
                                    <th>Semester</th>
                                    <th>Amount</th>
                                    <th>Receipt</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($paymentHistory as $payment): ?>
                                    <tr>
                                        <td><?= date('M d, Y h:i A', strtotime($payment['payment_date'])) ?></td>
                                        <td><?= htmlspecialchars($payment['sy']) ?></td>
                                        <td><?= htmlspecialchars($payment['sem']) ?></td>
                                        <td>₱<?= number_format($payment['amount_paid'], 2) ?></td>
                                        <td>
                                            <a href="../cashier/receipt.php?id=<?= $payment['id'] ?>" class="btn btn-outline btn-sm" target="_blank">
                                                🧾 Receipt
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <!-- Quick Actions -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="#" onclick="window.print()" class="btn btn-outline">
                    🖨️ Print Dashboard
                </a>
                <a href="../auth/logout.php" class="btn btn-danger">
                    🚪 Logout
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
