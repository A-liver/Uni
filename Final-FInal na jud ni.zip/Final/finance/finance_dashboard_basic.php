<?php
require_once __DIR__ . '/../includes/header_basic.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'finance') {
    exit("Access denied");
}

// Get finance statistics
$totalRevenueQuery = mysqli_query($conn, "
    SELECT SUM(amount_paid) as total_revenue, COUNT(*) as total_transactions
    FROM payments
");
$revenueStats = mysqli_fetch_assoc($totalRevenueQuery);

$pendingBillingQuery = mysqli_query($conn, "
    SELECT COUNT(*) as pending_count
    FROM billing_master
    WHERE status = 'unpaid' OR status = 'partial'
");
$pendingStats = mysqli_fetch_assoc($pendingBillingQuery);
?>

<h1>Finance Dashboard</h1>
<p>Manage billing, payments, and financial reports</p>

<hr>

<!-- Statistics -->
<table border="1" cellpadding="10" cellspacing="0" width="100%">
    <tr>
        <td><strong>Total Revenue</strong></td>
        <td><strong>Total Transactions</strong></td>
        <td><strong>Pending Billings</strong></td>
        <td><strong>Current Year</strong></td>
    </tr>
    <tr>
        <td>₱<?= number_format($revenueStats['total_revenue'] ?? 0, 2) ?></td>
        <td><?= $revenueStats['total_transactions'] ?? 0 ?></td>
        <td><?= $pendingStats['pending_count'] ?? 0 ?></td>
        <td><?= date('Y') ?></td>
    </tr>
</table>

<br>

<!-- Student Search -->
<h2>Student Billing Search</h2>
<form method="POST">
    <table border="0" cellpadding="5">
        <tr>
            <td>Student Name:</td>
            <td><input type="text" name="student" placeholder="Enter student name" required></td>
        </tr>
        <tr>
            <td>School Year:</td>
            <td><input type="text" name="sy" placeholder="e.g., 2023-2024" required></td>
        </tr>
        <tr>
            <td>Semester:</td>
            <td><input type="text" name="sem" placeholder="e.g., 1st" required></td>
        </tr>
        <tr>
            <td colspan="2"><button type="submit" name="search">Search Billing</button></td>
        </tr>
    </table>
</form>

<?php
if (isset($_POST['search'])) {
    $name = mysqli_real_escape_string($conn, $_POST['student']);
    $sy = $_POST['sy'];
    $sem = $_POST['sem'];
    
    $student = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT * FROM students 
        WHERE fname LIKE '%$name%' OR lname LIKE '%$name%' 
        LIMIT 1
    ));
    
    if (!$student) {
        echo "<p style='color: red;'>Student not found</p>";
    } else {
        $sid = $student['student_id'];
        
        echo "<h3>Student: " . htmlspecialchars($student['fname'] . ' ' . $student['lname']) . "</h3>";
        
        // Student Load
        echo "<h4>Student Load:</h4>";
        $subjects = mysqli_query($conn, "
            SELECT * FROM student_subjects WHERE student_id='$sid'
        ");
        
        $units = 0;
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><th>Subject</th><th>Units</th></tr>";
        
        while ($s = mysqli_fetch_assoc($subjects)) {
            echo "<tr><td>" . htmlspecialchars($s['subject_code']) . "</td><td>" . $s['units'] . "</td></tr>";
            $units += $s['units'];
        }
        
        echo "</table>";
        echo "<p><strong>Total Units: $units</strong></p>";
        
        // Fee Schedule
        echo "<h4>Fee Schedule:</h4>";
        $fees = mysqli_query($conn, "SELECT * FROM fee_schedules");
        
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><th>Fee</th><th>Category</th><th>Amount</th></tr>";
        
        while ($f = mysqli_fetch_assoc($fees)) {
            echo "<tr>
                <td>" . htmlspecialchars($f['fee_name']) . "</td>
                <td>" . htmlspecialchars($f['category']) . "</td>
                <td>₱" . number_format($f['amount'], 2) . "</td>
            </tr>";
        }
        
        echo "</table>";
        
        // Billing Master
        echo "<h4>Billing Records:</h4>";
        $billing = mysqli_query($conn, "
            SELECT * FROM billing_master WHERE student_id='$sid'
        ");
        
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><th>School Year</th><th>Semester</th><th>Total Amount</th><th>Status</th></tr>";
        
        while ($b = mysqli_fetch_assoc($billing)) {
            echo "<tr>
                <td>" . htmlspecialchars($b['sy']) . "</td>
                <td>" . htmlspecialchars($b['sem']) . "</td>
                <td>₱" . number_format($b['total_amount'], 2) . "</td>
                <td>" . ucfirst($b['status']) . "</td>
            </tr>";
        }
        
        echo "</table>";
        
        // Billing Details & Payments
        echo "<h4>Payment History:</h4>";
        $payments = mysqli_query($conn, "
            SELECT p.*, bm.sy, bm.sem 
            FROM payments p
            JOIN billing_master bm ON bm.billing_id = p.billing_id
            WHERE p.student_id='$sid'
            ORDER BY p.payment_date DESC
        ");
        
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><th>Date</th><th>School Year</th><th>Semester</th><th>Amount</th><th>Receipt</th></tr>";
        
        while ($p = mysqli_fetch_assoc($payments)) {
            echo "<tr>
                <td>" . date('M d, Y h:i A', strtotime($p['payment_date'])) . "</td>
                <td>" . htmlspecialchars($p['sy']) . "</td>
                <td>" . htmlspecialchars($p['sem']) . "</td>
                <td>₱" . number_format($p['amount_paid'], 2) . "</td>
                <td><a href='../cashier/receipt.php?id=" . $p['id'] . "' target='_blank'>Receipt</a></td>
            </tr>";
        }
        
        echo "</table>";
        
        // Financial Summary
        $totalBilled = mysqli_fetch_assoc(mysqli_query($conn, "
            SELECT SUM(total_amount) as total FROM billing_master WHERE student_id='$sid'
        ))['total'] ?? 0;
        
        $totalPaid = mysqli_fetch_assoc(mysqli_query($conn, "
            SELECT SUM(amount_paid) as total FROM payments WHERE student_id='$sid'
        ))['total'] ?? 0;
        
        $totalBalance = $totalBilled - $totalPaid;
        
        echo "<h4>Financial Summary:</h4>";
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><td>Total Billed:</td><td>₱" . number_format($totalBilled, 2) . "</td></tr>";
        echo "<tr><td>Total Paid:</td><td>₱" . number_format($totalPaid, 2) . "</td></tr>";
        echo "<tr><td><strong>Outstanding Balance:</strong></td><td><strong>₱" . number_format($totalBalance, 2) . "</strong></td></tr>";
        echo "</table>";
    }
}
?>

<br>
<hr>
<p><a href="../cashier/student_billing_basic.php">Student Billing</a> | <a href="#" onclick="window.print()">Print Dashboard</a> | <a href="../auth/logout.php">Logout</a></p>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
