<?php
require_once __DIR__ . '/../includes/header.php';

/* 🔒 SECURITY CHECK */
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    header("Location: ../auth/login.php");
    exit();
}

/* 🔥 USE REAL STUDENT ID */
if (!isset($_SESSION['student_id'])) {
    die("Student session not found");
}

$student_id = $_SESSION['student_id'];

/* GET STUDENT INFO */
$studentQuery = mysqli_query($conn, "
    SELECT fname, lname, course, sy, sem
    FROM students
    WHERE student_id = '$student_id'
    LIMIT 1
");
$student = mysqli_fetch_assoc($studentQuery);

/* GET ENROLLED SUBJECTS */
$query = mysqli_query($conn, "
    SELECT *
    FROM student_subjects
    WHERE student_id = '$student_id'
    ORDER BY sy DESC, sem DESC, subject_code ASC
");

/* GET STATISTICS */
$statsQuery = mysqli_query($conn, "
    SELECT COUNT(*) as total_subjects, SUM(units) as total_units, AVG(final) as avg_grade
    FROM student_subjects
    WHERE student_id = '$student_id' AND final > 0
");
$stats = mysqli_fetch_assoc($statsQuery);

/* GET ERROR MESSAGES */
$error = '';
if (isset($_GET['error'])) {
    switch($_GET['error']) {
        case 'drop_failed':
            $error = "Failed to drop subject. Please try again.";
            break;
        case 'subject_not_found':
            $error = "Subject not found.";
            break;
        default:
            $error = "An error occurred.";
    }
}

$success = '';
if (isset($_GET['success'])) {
    switch($_GET['success']) {
        case 'dropped':
            $success = "Subject dropped successfully!";
            break;
        default:
            $success = "Operation completed successfully!";
    }
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-book"></i> My Enrolled Subjects
            </h1>
        </div>
        <div class="flex gap-2">
            <a href="add_subjects.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add Subject
            </a>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-error mb-6">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success mb-6">
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <!-- Student Information -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-user-circle"></i> Student Information
            </h2>
            <p class="text-sm text-secondary">Your academic details and current enrollment</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="info-card info-card-primary">
                    <span class="info-label">Student ID</span>
                    <div class="info-value"><?= $student_id ?></div>
                </div>
                <div class="info-card info-card-success">
                    <span class="info-label">Name</span>
                    <div class="info-value"><?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?></div>
                </div>
                <div class="info-card info-card-info">
                    <span class="info-label">Course</span>
                    <div class="info-value"><?= htmlspecialchars($student['course']) ?></div>
                </div>
                <div class="info-card info-card-warning">
                    <span class="info-label">Academic Year</span>
                    <div class="info-value"><?= htmlspecialchars($student['sy']) ?> - <?= htmlspecialchars($student['sem']) ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= mysqli_num_rows($query) ?></div>
            <div class="stat-label">
                <i class="fas fa-book"></i> Enrolled Subjects
            </div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $stats['total_units'] ?? 0 ?></div>
            <div class="stat-label">
                <i class="fas fa-tasks"></i> Total Units
            </div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= number_format($stats['avg_grade'] ?? 0, 2) ?></div>
            <div class="stat-label">
                <i class="fas fa-chart-line"></i> Average Grade
            </div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value">Active</div>
            <div class="stat-label">
                <i class="fas fa-check-circle"></i> Current Status
            </div>
        </div>
    </div>

    <!-- Enrolled Subjects Table -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-list"></i> Enrolled Subjects
            </h2>
            <p class="text-sm text-secondary">View and manage your current subject enrollments</p>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($query) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Class #</th>
                                <th>Subject Code</th>
                                <th>Description</th>
                                <th>Units</th>
                                <th>Room</th>
                                <th>Instructor</th>
                                <th>Term</th>
                                <th>Final Grade</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($query)) { ?>
                                <tr>
                                    <td><span class="badge badge-primary"><?= $row['cn'] ?></span></td>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($row['subject_code']) ?></div>
                                    </td>
                                    <td><?= htmlspecialchars($row['description']) ?></td>
                                    <td><?= $row['units'] ?></td>
                                    <td><?= htmlspecialchars($row['room']) ?></td>
                                    <td><?= htmlspecialchars($row['instructor']) ?></td>
                                    <td><?= htmlspecialchars($row['term']) ?></td>
                                    <td>
                                        <?php if ($row['final'] > 0): ?>
                                            <span class="badge badge-<?= $row['final'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= number_format($row['final'], 2) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Not Graded</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($row['final'] > 0): ?>
                                            <span class="badge badge-<?= $row['final'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= $row['final'] >= 75 ? 'Passed' : 'Failed' ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">In Progress</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="flex gap-2">
                                            <a href="grade.php?subject=<?= urlencode($row['subject_code']) ?>" class="btn btn-outline btn-sm">
                                                📊 Grades
                                            </a>
                                            <a href="drop_subject.php?id=<?= $row['id'] ?>" 
                                               onclick="return confirm('Are you sure you want to drop this subject? This action cannot be undone.')" 
                                               class="btn btn-danger btn-sm">
                                                🗑️ Drop
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No subjects enrolled.</strong> You haven't enrolled in any subjects yet.
                    <div class="mt-4">
                        <a href="add_subjects.php" class="btn btn-primary">
                            📚 Enroll in Subjects
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="add_subjects.php" class="btn btn-primary">
                    ➕ Add Subject
                </a>
                <a href="grade.php" class="btn btn-secondary">
                    📊 View Grades
                </a>
                <a href="billing.php" class="btn btn-outline">
                    💳 View Billing
                </a>
                <a href="exam_permit.php" class="btn btn-outline">
                    📝 Exam Permit
                </a>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Important Information</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Subject Management:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• You can add subjects during the enrollment period</li>
                        <li>• Dropping subjects may affect your billing and academic standing</li>
                        <li>• Consult with your academic advisor before making changes</li>
                        <li>• Some subjects may have prerequisites</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Academic Policies:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Minimum units required per semester: 12 units</li>
                        <li>• Maximum units allowed per semester: 24 units</li>
                        <li>• Add/drop period: First 2 weeks of classes</li>
                        <li>• Grades are finalized after the semester ends</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>