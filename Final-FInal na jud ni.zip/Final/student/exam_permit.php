<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    exit("Access denied");
}

$student_id = $_SESSION['student_id'] ?? 0;
if (!$student_id) exit("Session error");

$student = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT * FROM students WHERE student_id='$student_id'
"));

$sy = $student['sy'];
$sem = $student['sem'];

/* TOTAL BILL */
$subjects = mysqli_query($conn, "
    SELECT units FROM student_subjects
    WHERE student_id='$student_id' AND sy='$sy' AND sem='$sem'
");

$total_units = 0;
while ($s = mysqli_fetch_assoc($subjects)) {
    $total_units += $s['units'];
}

$tuition = ($total_units / 3) * 300;

$billing = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT billing_id FROM billing_master
    WHERE student_id='$student_id' AND sy='$sy' AND sem='$sem'
"));

$billing_id = $billing['billing_id'] ?? 0;

$other_total = 0;

if ($billing_id) {
    $fees = mysqli_query($conn, "
        SELECT amount FROM billing_details WHERE billing_id='$billing_id'
    ");

    while ($f = mysqli_fetch_assoc($fees)) {
        $other_total += $f['amount'];
    }
}

$total_bill = $tuition + $other_total;

/* PAYMENTS */
$paid = 0;

if ($billing_id) {
    $payments = mysqli_query($conn, "
        SELECT amount_paid FROM payments WHERE billing_id='$billing_id'
    ");

    while ($p = mysqli_fetch_assoc($payments)) {
        $paid += $p['amount_paid'];
    }
}

$one_third = $total_bill / 3;

$prelim_ok  = $paid >= $one_third;
$midterm_ok = $paid >= ($one_third * 2);
$final_ok   = $paid >= $total_bill;
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-certificate"></i> Exam Permit
            </h1>
        </div>
    </div>

    <!-- Student Information -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-user-circle"></i> Student Information
            </h2>
            <p class="text-sm text-secondary">Your academic details and current enrollment</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="info-card info-card-primary">
                    <span class="info-label">Student ID</span>
                    <div class="info-value"><?= $student_id ?></div>
                </div>
                <div class="info-card info-card-success">
                    <span class="info-label">Full Name</span>
                    <div class="info-value"><?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?></div>
                </div>
                <div class="info-card info-card-info">
                    <span class="info-label">Course</span>
                    <div class="info-value"><?= htmlspecialchars($student['course']) ?></div>
                </div>
                <div class="info-card info-card-warning">
                    <span class="info-label">Academic Year</span>
                    <div class="info-value"><?= htmlspecialchars($sy) ?> - <?= htmlspecialchars($sem) ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Payment Status Overview -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-credit-card"></i> Payment Status
            </h2>
            <p class="text-sm text-secondary">Your current payment status and exam eligibility</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Billing Summary</h4>
                    <div class="space-y-2">
                        <div class="flex justify-between">
                            <span class="text-secondary">Total Bill:</span>
                            <span class="font-semibold">₱<?= number_format($total_bill, 2) ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-secondary">Amount Paid:</span>
                            <span class="font-semibold text-success">₱<?= number_format($paid, 2) ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-secondary">Remaining Balance:</span>
                            <span class="font-semibold text-danger">₱<?= number_format($total_bill - $paid, 2) ?></span>
                        </div>
                    </div>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Payment Requirements</h4>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span>Prelim Permit:</span>
                            <span class="font-semibold">₱<?= number_format($one_third, 2) ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span>Midterm Permit:</span>
                            <span class="font-semibold">₱<?= number_format($one_third * 2, 2) ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span>Final Permit:</span>
                            <span class="font-semibold">₱<?= number_format($total_bill, 2) ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Exam Permit Options -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-file-invoice"></i> Generate Exam Permit
            </h2>
            <p class="text-sm text-secondary">Select the examination period permit you want to generate</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Prelim Permit -->
                <div class="permit-card <?= $prelim_ok ? 'permit-available' : 'permit-locked' ?>">
                    <div class="text-center">
                        <div class="text-3xl mb-3">📝</div>
                        <h3 class="font-semibold text-lg mb-2">Prelim Exam Permit</h3>
                        <div class="mb-4">
                            <?php if ($prelim_ok): ?>
                                <span class="badge badge-success">
                                    <i class="fas fa-check-circle"></i> Available
                                </span>
                            <?php else: ?>
                                <span class="badge badge-danger">
                                    <i class="fas fa-times-circle"></i> Payment Required
                                </span>
                            <?php endif; ?>
                        </div>
                        <p class="text-sm text-secondary mb-4">
                            Required payment: ₱<?= number_format($one_third, 2) ?><br>
                            Your payment: ₱<?= number_format($paid, 2) ?>
                        </p>
                        <?php if ($prelim_ok): ?>
                            <a href="print_permit.php?type=prelim" class="btn btn-primary btn-full">
                                🖨️ Print Prelim Permit
                            </a>
                        <?php else: ?>
                            <button class="btn btn-secondary btn-full" disabled>
                                🔒 Payment Required
                            </button>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Midterm Permit -->
                <div class="permit-card <?= $midterm_ok ? 'permit-available' : 'permit-locked' ?>">
                    <div class="text-center">
                        <div class="text-3xl mb-3">📊</div>
                        <h3 class="font-semibold text-lg mb-2">Midterm Exam Permit</h3>
                        <div class="mb-4">
                            <?php if ($midterm_ok): ?>
                                <span class="badge badge-success">✓ Available</span>
                            <?php else: ?>
                                <span class="badge badge-danger">✗ Payment Required</span>
                            <?php endif; ?>
                        </div>
                        <p class="text-sm text-secondary mb-4">
                            Required payment: ₱<?= number_format($one_third * 2, 2) ?><br>
                            Your payment: ₱<?= number_format($paid, 2) ?>
                        </p>
                        <?php if ($midterm_ok): ?>
                            <a href="print_permit.php?type=midterm" class="btn btn-primary btn-full">
                                🖨️ Print Midterm Permit
                            </a>
                        <?php else: ?>
                            <button class="btn btn-secondary btn-full" disabled>
                                🔒 Payment Required
                            </button>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Final Permit -->
                <div class="permit-card <?= $final_ok ? 'permit-available' : 'permit-locked' ?>">
                    <div class="text-center">
                        <div class="text-3xl mb-3">🎯</div>
                        <h3 class="font-semibold text-lg mb-2">Final Exam Permit</h3>
                        <div class="mb-4">
                            <?php if ($final_ok): ?>
                                <span class="badge badge-success">✓ Available</span>
                            <?php else: ?>
                                <span class="badge badge-danger">✗ Payment Required</span>
                            <?php endif; ?>
                        </div>
                        <p class="text-sm text-secondary mb-4">
                            Required payment: ₱<?= number_format($total_bill, 2) ?><br>
                            Your payment: ₱<?= number_format($paid, 2) ?>
                        </p>
                        <?php if ($final_ok): ?>
                            <a href="print_permit.php?type=final" class="btn btn-primary btn-full">
                                🖨️ Print Final Permit
                            </a>
                        <?php else: ?>
                            <button class="btn btn-secondary btn-full" disabled>
                                🔒 Payment Required
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Important Information</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Exam Permit Requirements:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• <strong>Prelim Permit:</strong> 1/3 of total fees paid</li>
                        <li>• <strong>Midterm Permit:</strong> 2/3 of total fees paid</li>
                        <li>• <strong>Final Permit:</strong> Full payment of all fees</li>
                        <li>• Permits are required before taking examinations</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Examination Guidelines:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Bring printed exam permit on examination day</li>
                        <li>• Present valid student ID with exam permit</li>
                        <li>• No permit, no examination policy strictly enforced</li>
                        <li>• Lost permits can be reprinted from this page</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>