<?php

require_once __DIR__ . '/../includes/header.php';



/* 🔒 SECURITY */

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {

    header("Location: ../auth/login.php");

    exit();

}



/* ✅ USE REAL STUDENT ID */

if (!isset($_SESSION['student_id'])) {

    die("Session error: student_id not found. Please login again.");

}



$student_id = $_SESSION['student_id'];



/* =========================

   GET STUDENT INFO

========================= */

$result = mysqli_query($conn, "

    SELECT * FROM students WHERE student_id='$student_id'

");



if (!$result) {

    die("Query error: " . mysqli_error($conn));

}



$student = mysqli_fetch_assoc($result);



if (!$student) {

    die("Student record not found.");

}



/* =========================

   OPTIONAL: USER INFO

========================= */

$username = $_SESSION['username'];



$result2 = mysqli_query($conn, "

    SELECT * FROM users WHERE username='$username'

");



$user = mysqli_fetch_assoc($result2);

?>



<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-user"></i> Student Dashboard
            </h1>
        </div>
    </div>

    <!-- Student Information Card -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-user-circle"></i> Student Information
            </h2>
            <p class="text-sm text-secondary">Your academic details and current status</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="info-card info-card-primary">
                    <span class="info-label">Student ID</span>
                    <div class="info-value"><?= $student_id ?></div>
                </div>
                <div class="info-card info-card-success">
                    <span class="info-label">Full Name</span>
                    <div class="info-value"><?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?></div>
                </div>
                <div class="info-card info-card-info">
                    <span class="info-label">Course</span>
                    <div class="info-value"><?= htmlspecialchars($student['course']) ?></div>
                </div>
                <div class="info-card info-card-warning">
                    <span class="info-label">Period</span>
                    <div class="info-value"><?= htmlspecialchars($student['sy']) ?> | SEM <?= htmlspecialchars($student['sem']) ?></div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>