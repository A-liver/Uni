<?php
require_once __DIR__ . '/../includes/header.php';

/* 🔒 SECURITY CHECK */
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    header("Location: login.php");
    exit();
}

/* 🔥 ENSURE STUDENT SESSION EXISTS */
if (!isset($_SESSION['student_id']) || $_SESSION['student_id'] <= 0) {
    die("Student session not found. Please login again.");
}

$student_id = (int) $_SESSION['student_id'];

/* GET SELECTED COURSE */
$selected_course = isset($_GET['course']) ? $_GET['course'] : "";

/* LOAD COURSES */
$courses = mysqli_query($conn, "
    SELECT DISTINCT COURSE 
    FROM subjectssem120182019 
    ORDER BY COURSE ASC
");

/* LOAD SUBJECTS */
$subjects = [];

if ($selected_course != "") {
    $selected_course = mysqli_real_escape_string($conn, $selected_course);

    $query = "
        SELECT * 
        FROM subjectssem120182019 
        WHERE COURSE='$selected_course' 
        ORDER BY SUBJECT ASC
    ";

    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $subjects[] = $row;
    }
}
?>

<div class="fade-in">
    <!-- Header Section -->
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-book-medical"></i> Add Subjects
            </h1>
        </div>
        <div class="flex gap-2">
            <a href="student_subjects.php" class="btn btn-outline">
                <i class="fas fa-list"></i> My Subjects
            </a>
        </div>
    </div>

    <!-- Course Selection Card -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-graduation-cap"></i> Course Selection
            </h2>
            <p class="text-sm text-secondary">Choose your course to see available subjects</p>
        </div>
        <div class="card-body">
            <form method="GET" class="flex flex-wrap gap-4 items-end">
                <div class="flex-1">
                    <label class="form-label">Select Course</label>
                    <select name="course" onchange="this.form.submit()" required class="form-input">
                        <option value="">-- Select a Course --</option>
                        <?php while ($c = mysqli_fetch_assoc($courses)) { ?>
                            <option value="<?php echo $c['COURSE']; ?>" <?php echo ($selected_course == $c['COURSE']) ? 'selected' : ''; ?>>
                                <?php echo $c['COURSE']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <!-- Subjects List -->
    <?php if ($selected_course != "") { ?>
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-list-alt"></i> Available Subjects
                </h2>
                <p class="text-sm text-secondary">Subjects for: <span class="badge badge-primary"><?php echo $selected_course; ?></span></p>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-hashtag"></i> CN</th>
                                <th><i class="fas fa-book"></i> Subject</th>
                                <th><i class="fas fa-align-left"></i> Description</th>
                                <th><i class="fas fa-coins"></i> Units</th>
                                <th><i class="fas fa-clock"></i> Schedule</th>
                                <th><i class="fas fa-door-open"></i> Room</th>
                                <th><i class="fas fa-plus"></i> Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($subjects as $s) { ?>
                                <tr>
                                    <td>
                                        <span class="badge badge-primary"><?php echo $s['CN']; ?></span>
                                    </td>
                                    <td>
                                        <div class="font-semibold"><?php echo $s['SUBJECT']; ?></div>
                                    </td>
                                    <td><?php echo $s['DESC']; ?></td>
                                    <td>
                                        <span class="badge badge-warning"><?php echo $s['UNIT']; ?> units</span>
                                    </td>
                                    <td>
                                        <div class="text-sm">
                                            <i class="fas fa-play text-success"></i> <?php echo $s['TSTART']; ?><br>
                                            <i class="fas fa-stop text-danger"></i> <?php echo $s['TEND']; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge badge-secondary"><?php echo $s['ROOM']; ?></span>
                                    </td>
                                    <td>
                                        <a href="enrolled_courses.php?id=<?php echo $s['CN']; ?>&course=<?php echo $s['COURSE']; ?>" class="btn btn-success btn-sm">
                                            <i class="fas fa-plus-circle"></i> Add
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Subject Count Card -->
        <div class="card mt-6">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-info-circle"></i> Subject Information
                </h2>
            </div>
            <div class="card-body">
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-value"><?php echo count($subjects); ?></div>
                        <div class="stat-label">
                            <i class="fas fa-book"></i> Total Subjects
                        </div>
                    </div>
                    <div class="stat-card success">
                        <div class="stat-value">
                            <?php 
                                $total_units = 0;
                                foreach ($subjects as $s) {
                                    $total_units += $s['UNIT'];
                                }
                                echo $total_units;
                            ?>
                        </div>
                        <div class="stat-label">
                            <i class="fas fa-coins"></i> Total Units
                        </div>
                    </div>
                    <div class="stat-card warning">
                        <div class="stat-value"><?php echo $selected_course; ?></div>
                        <div class="stat-label">
                            <i class="fas fa-graduation-cap"></i> Selected Course
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php } else { ?>
        <!-- No Course Selected -->
        <div class="card">
            <div class="card-body text-center py-12">
                <div class="empty-state">
                    <i class="fas fa-graduation-cap" style="font-size: 4rem; color: var(--text-secondary); margin-bottom: 1rem;"></i>
                    <h3 class="text-xl font-semibold mb-2">Select a Course</h3>
                    <p class="text-secondary">Please select a course from the dropdown above to view available subjects.</p>
                </div>
            </div>
        </div>
    <?php } ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>