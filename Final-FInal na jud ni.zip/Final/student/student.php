<?php
require_once __DIR__ . '/../includes/header.php';

/* 🔒 SECURITY CHECK */
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

/* GET STUDENT INFO */
$sql = "SELECT * FROM students WHERE email='$username'";
$result = mysqli_query($conn, $sql);
$student = mysqli_fetch_assoc($result);

/* GET USER INFO */
$sql2 = "SELECT * FROM users WHERE username='$username'";
$result2 = mysqli_query($conn, $sql2);
$user = mysqli_fetch_assoc($result2);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-user-cog"></i> My Profile
            </h1>
        </div>
    </div>

    <?php if ($student): ?>
        <!-- Profile Information -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-user-circle"></i> Personal Information
                </h2>
                <p class="text-sm text-secondary">Your academic and personal details</p>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Left Column -->
                    <div class="space-y-4">
                        <div class="info-card info-card-primary">
                            <span class="info-label">Full Name</span>
                            <div class="info-value"><?= htmlspecialchars($student['fname'] . " " . $student['lname']) ?></div>
                        </div>
                        <div class="info-card info-card-success">
                            <span class="info-label">Course</span>
                            <div class="info-value"><?= htmlspecialchars($student['course']) ?></div>
                        </div>
                        <div class="info-card info-card-info">
                            <span class="info-label">Major</span>
                            <div class="info-value"><?= htmlspecialchars($student['major']) ?></div>
                        </div>
                        <div class="info-card info-card-warning">
                            <span class="info-label">Birthdate</span>
                            <div class="info-value"><?= htmlspecialchars($student['bdate']) ?></div>
                        </div>
                    </div>

                    <!-- Right Column -->
                    <div class="space-y-4">
                        <div class="info-card info-card-danger">
                            <span class="info-label">Gender</span>
                            <div class="info-value"><?= htmlspecialchars($student['gender']) ?></div>
                        </div>
                        <div class="info-card info-card-secondary">
                            <span class="info-label">Email</span>
                            <div class="info-value"><?= htmlspecialchars($student['email']) ?></div>
                        </div>
                        <div class="info-card">
                            <span class="info-label">Address</span>
                            <div class="info-value"><?= htmlspecialchars($student['region'] . ", " . $student['city'] . ", " . $student['barangay']) ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Profile Image -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-camera"></i> Profile Picture
                </h2>
                <p class="text-sm text-secondary">Your current profile image</p>
            </div>
            <div class="card-body">
                <div class="text-center">
                    <?php if (!empty($student['image_path'])): ?>
                        <img src="/Final/upload/<?= htmlspecialchars(basename($student['image_path'])) ?>" 
                             alt="Profile Picture" 
                             class="rounded-lg shadow-lg mx-auto" 
                             style="max-width: 200px; height: auto; border: 4px solid var(--primary-color);">
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-user-circle" style="font-size: 4rem; color: var(--text-secondary);"></i>
                            <p style="color: var(--text-secondary); margin-top: 1rem;">No profile image uploaded</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    <?php else: ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-triangle"></i> No student record found.
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>