<?php
require_once __DIR__ . '/../includes/header.php';

/* SECURITY CHECK */
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['student_id']) || $_SESSION['student_id'] <= 0) {
    die("Student session not found");
}

$student_id = (int) $_SESSION['student_id'];

$enroll_id = $_GET['id'] ?? null;
if (!$enroll_id) die("No subject selected");

$enroll_id = (int)$enroll_id;

/* =========================
   GET STUDENT SY / SEM
========================= */
$studentQuery = mysqli_query($conn, "
    SELECT sy, sem 
    FROM students 
    WHERE student_id='$student_id'
    LIMIT 1
");

$student = mysqli_fetch_assoc($studentQuery);

$sy = $student['sy'];
$sem = $student['sem'];

/* =========================
   DELETE SUBJECT
========================= */
$delete = mysqli_query($conn, "
    DELETE FROM student_subjects
    WHERE id = $enroll_id
    AND student_id = $student_id
");

if (!$delete) {
    die("Delete failed: " . mysqli_error($conn));
}

/* =========================
   RECALCULATE TOTAL UNITS
========================= */
$unitQ = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT SUM(units) AS total_units
    FROM student_subjects
    WHERE student_id='$student_id'
    AND sy='$sy'
    AND sem='$sem'
"));

$total_units = $unitQ['total_units'] ?? 0;

/* =========================
   TUITION RULE
========================= */
$rate_per_3_units = 300;
$tuition = ($total_units / 3) * $rate_per_3_units;

/* =========================
   GET BILLING MASTER
========================= */
$bm = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT billing_id
    FROM billing_master
    WHERE student_id='$student_id'
    AND sy='$sy'
    AND sem='$sem'
    LIMIT 1
"));

if ($bm) {

    $billing_id = $bm['billing_id'];

    /* =========================
       UPDATE BILLING MASTER
    ========================= */
    mysqli_query($conn, "
        UPDATE billing_master
        SET total_units='$total_units',
            total_amount='$tuition'
        WHERE billing_id='$billing_id'
    ");
}

echo "<script>
    alert('Subject dropped successfully!');
    window.location.href='student_subjects.php';
</script>";
?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>