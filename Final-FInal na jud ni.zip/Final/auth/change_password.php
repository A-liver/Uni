<?php
require_once __DIR__ . '/../includes/header.php';

// must be logged in
if (!isset($_SESSION['username'])) {
    header("Location: ../auth/login.php");
    exit();
}

$username = $_SESSION['username'];

if (isset($_POST['change'])) {

    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    // get user
    $result = mysqli_query($conn, "SELECT password FROM users WHERE username='$username'");
    $user = mysqli_fetch_assoc($result);

    // check current password
    if (!password_verify($current, $user['password'])) {
        echo "Current password is wrong!";
    }
    else if ($current == $new) {
        echo "New password cannot be the same as current password!";
    }
    else if ($new != $confirm) {
        echo "New password does not match!";
    }
    else {

        $hashed = password_hash($new, PASSWORD_DEFAULT);

        mysqli_query($conn, "
            UPDATE users 
            SET password='$hashed' 
            WHERE username='$username'
        ");

        echo "Password changed successfully!";
    }
}
?>

<h2>Change Password</h2>

<form method="POST">
    <input type="password" name="current_password" placeholder="Current Password" required><br><br>
    <input type="password" name="new_password" placeholder="New Password" required><br><br>
    <input type="password" name="confirm_password" placeholder="Confirm Password" required><br><br>

    <button type="submit" name="change">Change Password</button>
</form>

<br>
<a href="../auth/logout.php">Logout</a>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>