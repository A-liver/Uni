<?php
require_once __DIR__ . '/../includes/init.php';

$error = '';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $username = mysqli_real_escape_string($conn, $username);

    $sql = "SELECT * FROM users 
            WHERE username='$username' 
            AND password='$password'";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    $user = mysqli_fetch_assoc($result);

    if ($user) {
        $_SESSION['role'] = $user['role'];
        $_SESSION['username'] = $user['username'];

        // Debug: Show what role was found
        error_log("User found with role: " . $user['role']);

        if ($user['role'] == 'student') {
            $res = mysqli_query($conn, "
                SELECT student_id 
                FROM students 
                WHERE email = '{$user['username']}' OR student_id = '{$user['username']}'
                LIMIT 1
            ");

            $student = mysqli_fetch_assoc($res);

            if (!$student) {
                die("No matching student record found for this username.");
            }

            $_SESSION['student_id'] = (int)$student['student_id'];
        }

        // routing
        if ($user['role'] == 'admin') {
            header("Location: ../admin/admin.php");
        } elseif ($user['role'] == 'teacher') {
            header("Location: ../teacher/teacher_dashboard.php");
        } elseif ($user['role'] == 'cashier') {
            header("Location: ../cashier/cashier_dashboard.php");
        } elseif ($user['role'] == 'finance') {
            header("Location: ../finance/finance_dashboard.php");
        } elseif ($user['role'] == 'dean') {
            header("Location: ../dean/dean_dashboard.php");
        } elseif ($user['role'] == 'records') {
            header("Location: ../records/records_dashboard.php");
        } else {
            header("Location: ../student/student_dashboard.php");
        }

        exit();
    } else {
        $error = 'Invalid username or password';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Login System</title>
    <link rel="stylesheet" href="/final/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="login-container">
        <div class="login-card fade-in">
            <div class="login-header">
                <div style="font-size: 3rem; margin-bottom: 1rem;">🎓</div>
                <h2>University Portal</h2>
                <p>Sign in to access your account</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="text-left">
                <div class="form-group">
                    <label for="username" class="form-label">Username or Email</label>
                    <input type="text" id="username" name="username" class="form-input" placeholder="Enter your username or email" required>
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password" class="form-input" placeholder="Enter your password" required>
                </div>

                <button type="submit" name="login" class="btn btn-primary btn-full btn-lg">
                    Sign In
                </button>
            </form>

            <div class="mt-6">
                <p class="text-secondary">
                    Don't have an account? 
                    <a href="signup.php" class="btn btn-outline btn-sm">Create Account</a>
                </p>
            </div>

            <div class="mt-8">
                <p class="text-secondary text-sm">
                    Access for: Admin • Dean • Teacher • Cashier • Finance • Records • Student
                </p>
            </div>
        </div>
    </div>
</body>
</html>
