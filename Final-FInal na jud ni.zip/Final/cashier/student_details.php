<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cashier') {
    exit("Access denied");
}

// Get student ID from URL parameter
$studentId = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';

if (empty($studentId)) {
    echo "<div class='alert alert-error'>No student ID provided</div>";
    echo "<a href='cashier_dashboard.php'>← Back to Dashboard</a>";
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

// Get student information
$studentQuery = mysqli_query($conn, "SELECT * FROM students WHERE student_id = '$studentId'");
$student = mysqli_fetch_assoc($studentQuery);

if (!$student) {
    echo "<div class='alert alert-error'>Student not found</div>";
    echo "<a href='cashier_dashboard.php'>← Back to Dashboard</a>";
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

// Handle billing selection
$selectedBilling = null;
if (isset($_POST['select_billing']) && isset($_POST['billing_id'])) {
    $billingId = mysqli_real_escape_string($conn, $_POST['billing_id']);
    $billingQuery = mysqli_query($conn, "SELECT * FROM billing_master WHERE billing_id = '$billingId'");
    if ($billingQuery) {
        $selectedBilling = mysqli_fetch_assoc($billingQuery);
    }
}

// Handle payment processing - redirect to student_billing.php
if (isset($_POST['process_payment'])) {
    $billingId = mysqli_real_escape_string($conn, $_POST['billing_id']);
    $studentId = mysqli_real_escape_string($conn, $_POST['student_id']);
    $amount = mysqli_real_escape_string($conn, $_POST['payment_amount']);
    
    // Validate amount is positive
    if ($amount <= 0) {
        echo "<div class='alert alert-error'>Payment amount must be greater than 0.</div>";
    } else {
        $insertQuery = mysqli_query($conn, "
            INSERT INTO payments (student_id, billing_id, amount_paid, payment_date)
            VALUES ('$studentId', '$billingId', '$amount', NOW())
        ");
        
        if ($insertQuery) {
            echo "<div class='alert alert-success'>✅ Payment of ₱" . number_format($amount, 2) . " processed successfully!</div>";
            
            // Update billing status if fully paid
            $updateQuery = mysqli_query($conn, "
                UPDATE billing_master 
                SET status = 'paid' 
                WHERE billing_id = '$billingId' AND total_amount <= (
                    SELECT COALESCE(SUM(amount_paid), 0) 
                    FROM payments 
                    WHERE billing_id = '$billingId'
                )
            ");
            
            // Redirect to student_billing.php with success message
            echo "<script>
                setTimeout(function() {
                    window.location.href = 'student_billing.php?student_id=" . urlencode($studentId) . "&payment_success=1&amount=" . urlencode($amount) . "';
                }, 1500);
            </script>";
        } else {
            echo "<div class='alert alert-error'>❌ Payment failed: " . mysqli_error($conn) . "</div>";
        }
    }
}

// Get billing records for this student
$billingQuery = mysqli_query($conn, "
    SELECT * FROM billing_master 
    WHERE student_id = '$studentId'
    ORDER BY sy DESC, sem DESC
");
$billingRecords = [];
if ($billingQuery) {
    while ($row = mysqli_fetch_assoc($billingQuery)) {
        $billingRecords[] = $row;
    }
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-user"></i> Student Details
            </h1>
        </div>
    </div>

    <!-- Student Information -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-user-circle"></i> Student Information
            </h2>
            <p class="text-sm text-secondary">Current student details and contact information</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="bg-blue-50 p-3 rounded-lg border border-blue-200">
                    <span class="text-secondary text-sm text-blue-600">Student ID</span>
                    <div class="font-semibold text-blue-800"><?= $student['student_id'] ?></div>
                </div>
                <div class="bg-green-50 p-3 rounded-lg border border-green-200">
                    <span class="text-secondary text-sm text-green-600">Full Name</span>
                    <div class="font-semibold text-green-800"><?= htmlspecialchars($student['lname'] . ', ' . $student['fname']) ?></div>
                </div>
                <div class="bg-purple-50 p-3 rounded-lg border border-purple-200">
                    <span class="text-secondary text-sm text-purple-600">Course</span>
                    <div class="font-semibold text-purple-800"><?= htmlspecialchars($student['course'] ?? 'N/A') ?></div>
                </div>
                <div class="bg-orange-50 p-3 rounded-lg border border-orange-200">
                    <span class="text-secondary text-sm text-orange-600">Email</span>
                    <div class="font-semibold text-orange-800"><?= htmlspecialchars($student['email'] ?? 'N/A') ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Billing Records -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-file-invoice"></i> Billing Records
            </h2>
            <p class="text-sm text-secondary">Available billing periods for this student</p>
        </div>
        <div class="card-body">
            <?php if (!empty($billingRecords)): ?>
                <form method="POST">
                    <input type="hidden" name="student_id" value="<?= $student['student_id'] ?>">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>School Year</th>
                                    <th>Semester</th>
                                    <th>Total Amount</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($billingRecords as $billing): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($billing['sy']) ?></td>
                                        <td><?= htmlspecialchars($billing['sem']) ?></td>
                                        <td>₱<?= number_format($billing['total_amount'], 2) ?></td>
                                        <td>
                                            <span class="badge badge-<?= $billing['status'] == 'paid' ? 'success' : ($billing['status'] == 'partial' ? 'warning' : 'danger') ?>">
                                                <?= ucfirst($billing['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="student_billing.php?student_id=<?= urlencode($student['student_id']) ?>&billing_id=<?= urlencode($billing['billing_id']) ?>" class="btn btn-primary btn-sm">
                                                📋 Process Payment
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </form>
            <?php else: ?>
                <div class="alert alert-warning">
                    No billing records found for this student.
                </div>
            <?php endif; ?>
        </div>
    </div>

    </div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
