<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cashier') {
    exit("Access denied");
}

// Handle student search
$student = null;
$billingRecords = null;
$message = '';

if (isset($_POST['search'])) {
    $searchTerm = mysqli_real_escape_string($conn, $_POST['student']);
    
    // Simple student search
    $studentQuery = mysqli_query($conn, "
        SELECT * FROM students 
        WHERE student_id = '$searchTerm' 
        OR fname LIKE '%$searchTerm%' 
        OR lname LIKE '%$searchTerm%'
        LIMIT 1
    ");
    
    if ($studentQuery && mysqli_num_rows($studentQuery) > 0) {
        $student = mysqli_fetch_assoc($studentQuery);
        
        // Get billing records for this student
        $billingQuery = mysqli_query($conn, "
            SELECT * FROM billing_master 
            WHERE student_id = '{$student['student_id']}'
            ORDER BY sy DESC, sem DESC
        ");
        
        if ($billingQuery) {
            $billingRecords = [];
            while ($row = mysqli_fetch_assoc($billingQuery)) {
                $billingRecords[] = $row;
            }
        }
        
        $message = "Student found: " . htmlspecialchars($student['fname'] . ' ' . $student['lname']);
    } else {
        $message = "Student not found. Please try a different search term.";
    }
}

// Handle billing selection
$selectedBilling = null;
if (isset($_POST['select_billing']) && isset($_POST['billing_id'])) {
    $billingId = mysqli_real_escape_string($conn, $_POST['billing_id']);
    $billingQuery = mysqli_query($conn, "
        SELECT * FROM billing_master WHERE billing_id = '$billingId'
    ");
    
    if ($billingQuery) {
        $selectedBilling = mysqli_fetch_assoc($billingQuery);
    }
}

// Handle payment
if (isset($_POST['process_payment'])) {
    $billingId = mysqli_real_escape_string($conn, $_POST['billing_id']);
    $studentId = mysqli_real_escape_string($conn, $_POST['student_id']);
    $amount = mysqli_real_escape_string($conn, $_POST['payment_amount']);
    
    // Insert payment
    $insertQuery = mysqli_query($conn, "
        INSERT INTO payments (billing_id, student_id, amount_paid, payment_date)
        VALUES ('$billingId', '$studentId', '$amount', NOW())
    ");
    
    if ($insertQuery) {
        $message = "Payment of ₱$amount processed successfully!";
        // Clear selection
        $selectedBilling = null;
    } else {
        $message = "Payment failed: " . mysqli_error($conn);
    }
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>👤 Student Billing</h1>
            <p class="text-secondary">Search students and process payments</p>
        </div>
        <a href="cashier_dashboard.php" class="btn btn-outline">
            ← Back to Dashboard
        </a>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-info mb-6">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Search Form -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">🔍 Search Student</h2>
        </div>
        <div class="card-body">
            <form method="POST" class="flex gap-4">
                <div class="flex-1">
                    <input type="text" name="student" class="form-input" placeholder="Enter Student ID, First Name, or Last Name" required>
                </div>
                <button type="submit" name="search" class="btn btn-primary">
                    🔍 Search
                </button>
            </form>
        </div>
    </div>

    <!-- Student Information -->
    <?php if ($student): ?>
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">👤 Student Information</h2>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                        <span class="text-secondary text-sm">Student ID</span>
                        <div class="font-semibold"><?= $student['student_id'] ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Name</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['lname'] . ', ' . $student['fname']) ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Course</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['course'] ?? 'N/A') ?></div>
                    </div>
                    <div>
                        <span class="text-secondary text-sm">Email</span>
                        <div class="font-semibold"><?= htmlspecialchars($student['email'] ?? 'N/A') ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Billing Records -->
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">📋 Billing Records</h2>
            </div>
            <div class="card-body">
                <?php if ($billingRecords && count($billingRecords) > 0): ?>
                    <form method="POST">
                        <input type="hidden" name="student_id" value="<?= $student['student_id'] ?>">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>School Year</th>
                                        <th>Semester</th>
                                        <th>Total Amount</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($billingRecords as $billing): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($billing['sy']) ?></td>
                                            <td><?= htmlspecialchars($billing['sem']) ?></td>
                                            <td>₱<?= number_format($billing['total_amount'], 2) ?></td>
                                            <td>
                                                <span class="badge badge-<?= $billing['status'] == 'paid' ? 'success' : ($billing['status'] == 'partial' ? 'warning' : 'danger') ?>">
                                                    <?= ucfirst($billing['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button type="submit" name="select_billing" value="<?= $billing['billing_id'] ?>" class="btn btn-primary btn-sm">
                                                    📋 View Details
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="alert alert-warning">
                        No billing records found for this student.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Billing Details -->
    <?php if ($selectedBilling): ?>
        <?php
        // Get payment history
        $paymentsQuery = mysqli_query($conn, "
            SELECT * FROM payments 
            WHERE billing_id = '{$selectedBilling['billing_id']}'
            ORDER BY payment_date DESC
        ");
        
        $totalPaid = 0;
        $payments = [];
        if ($paymentsQuery) {
            while ($row = mysqli_fetch_assoc($paymentsQuery)) {
                $payments[] = $row;
                $totalPaid += $row['amount_paid'];
            }
        }
        
        $balance = $selectedBilling['total_amount'] - $totalPaid;
        ?>
        
        <div class="card mb-6">
            <div class="card-header">
                <h2 class="card-title">🧾 Billing Details - <?= $selectedBilling['sy'] ?> Semester <?= $selectedBilling['sem'] ?></h2>
            </div>
            <div class="card-body">
                <!-- Summary -->
                <div class="grid grid-cols-3 gap-4 mb-6">
                    <div class="text-center p-4 bg-blue-50 rounded">
                        <div class="text-2xl font-bold text-blue-600">₱<?= number_format($selectedBilling['total_amount'], 2) ?></div>
                        <div class="text-sm text-blue-500">Total Amount</div>
                    </div>
                    <div class="text-center p-4 bg-green-50 rounded">
                        <div class="text-2xl font-bold text-green-600">₱<?= number_format($totalPaid, 2) ?></div>
                        <div class="text-sm text-green-500">Amount Paid</div>
                    </div>
                    <div class="text-center p-4 bg-red-50 rounded">
                        <div class="text-2xl font-bold text-red-600">₱<?= number_format($balance, 2) ?></div>
                        <div class="text-sm text-red-500">Balance</div>
                    </div>
                </div>

                <!-- Payment Form -->
                <?php if ($balance > 0): ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">💳 Process Payment</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="billing_id" value="<?= $selectedBilling['billing_id'] ?>">
                                <input type="hidden" name="student_id" value="<?= $student['student_id'] ?>">
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="form-label">Payment Amount (₱)</label>
                                        <input type="number" name="payment_amount" class="form-input" step="0.01" min="0.01" max="<?= $balance ?>" required>
                                        <small class="text-secondary">Maximum: ₱<?= number_format($balance, 2) ?></small>
                                    </div>
                                    <div class="flex items-end">
                                        <button type="submit" name="process_payment" class="btn btn-success">
                                            💰 Process Payment
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success">
                        <strong>✅ Fully Paid!</strong> This billing has been completely paid.
                    </div>
                <?php endif; ?>

                <!-- Payment History -->
                <?php if (!empty($payments)): ?>
                    <div class="mt-6">
                        <h4 class="font-semibold mb-3">💳 Payment History</h4>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Receipt</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($payments as $payment): ?>
                                        <tr>
                                            <td><?= date('M d, Y h:i A', strtotime($payment['payment_date'])) ?></td>
                                            <td>₱<?= number_format($payment['amount_paid'], 2) ?></td>
                                            <td>
                                                <a href="receipt.php?id=<?= $payment['id'] ?>" class="btn btn-outline btn-sm" target="_blank">
                                                    🧾 Receipt
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
