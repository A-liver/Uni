<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cashier') {
    exit("Access denied");
}

/* =========================
   TODAY'S COLLECTION STATS
========================= */
$todayQuery = mysqli_query($conn, "
    SELECT 
        SUM(amount_paid) AS today_total,
        COUNT(*) AS today_count
    FROM payments
    WHERE DATE(payment_date) = CURDATE()
");

$todayStats = $todayQuery
    ? mysqli_fetch_assoc($todayQuery)
    : ['today_total' => 0, 'today_count' => 0];

$message = '';
$students_found = [];

/* =========================
   STUDENT SEARCH (GET)
========================= */
if (isset($_GET['search'])) {

    $student_name = mysqli_real_escape_string($conn, $_GET['student_name']);
    $school_year = mysqli_real_escape_string($conn, $_GET['school_year']);
    $semester = mysqli_real_escape_string($conn, $_GET['semester']);

    $sql = "
        SELECT *
        FROM students
        WHERE CONCAT(fname, ' ', lname) LIKE '%$student_name%'
    ";

    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {

        while ($student = mysqli_fetch_assoc($result)) {

            $students_found[] = [
                'student' => $student,
                'school_year' => $school_year,
                'semester' => $semester
            ];
        }

        $message = "Found " . count($students_found) . " student(s).";

    } else {
        $message = "No student found.";
    }
}

/* =========================
   PROCESS PAYMENT
========================= */
if (isset($_POST['make_payment']) && !empty($_POST['student_id'])) {

    $student_id = intval($_POST['student_id']);
    $billing_id = intval($_POST['billing_id']);
    $amount = floatval($_POST['payment_amount']);

    $insert_payment = "
        INSERT INTO payments
        (student_id, billing_id, amount_paid, payment_date)
        VALUES
        ($student_id, $billing_id, $amount, NOW())
    ";

    if (mysqli_query($conn, $insert_payment)) {

        $payment_id = mysqli_insert_id($conn);

        $message = "
            <p style='color:green;'>
                Payment of ₱" . number_format($amount, 2) . " received successfully!
            </p>

            <p>
                <a href='receipt.php?id=$payment_id' target='_blank'>
                    🖨️ Print Receipt
                </a>
            </p>
        ";

    } else {

        $message = "
            <p style='color:red;'>
                Error recording payment:
                " . mysqli_error($conn) . "
            </p>
        ";
    }
}
?>

<div class="fade-in">

    <!-- HEADER -->
    <div class="flex justify-between items-center mb-6">

        <div>
            <h1>💳 Cashier Dashboard</h1>

            <p class="text-secondary">
                Welcome Cashier:
                <?= htmlspecialchars($_SESSION['username']) ?>
            </p>
        </div>

        <a href="../auth/logout.php" class="btn btn-outline">
            🚪 Logout
        </a>

    </div>

    <!-- STATS -->
    <div class="stats-grid mb-6">

        <div class="stat-card">
            <div class="stat-value">
                ₱<?= number_format($todayStats['today_total'] ?? 0, 2) ?>
            </div>

            <div class="stat-label">
                Today's Collection
            </div>
        </div>

        <div class="stat-card success">
            <div class="stat-value">
                <?= $todayStats['today_count'] ?? 0 ?>
            </div>

            <div class="stat-label">
                Today's Transactions
            </div>
        </div>

    </div>

    <!-- MESSAGE -->
    <?php if ($message): ?>
        <div class="alert mb-6">
            <?= $message ?>
        </div>
    <?php endif; ?>

    <!-- SEARCH -->
    <div class="card mb-6">

        <div class="card-header">
            <h2 class="card-title">🔍 Search Student</h2>
        </div>

        <div class="card-body">

            <form method="GET" class="grid grid-cols-4 gap-4">

                <div>
                    <label class="form-label">Student Name</label>

                    <input
                        type="text"
                        name="student_name"
                        class="form-input"
                        placeholder="Search name..."
                        value="<?= $_GET['student_name'] ?? '' ?>"
                        required
                    >
                </div>

                <div>
                    <label class="form-label">School Year</label>

                    <select name="school_year" class="form-input" required>

                        <option value="2024-2025"
                        <?= (($_GET['school_year'] ?? '') == '2024-2025') ? 'selected' : '' ?>>
                            2024-2025
                        </option>

                        <option value="2025-2026"
                        <?= (($_GET['school_year'] ?? '') == '2025-2026') ? 'selected' : '' ?>>
                            2025-2026
                        </option>

                        <option value="2026-2027"
                        <?= (($_GET['school_year'] ?? '') == '2026-2027') ? 'selected' : '' ?>>
                            2026-2027
                        </option>

                    </select>
                </div>

                <div>
                    <label class="form-label">Semester</label>

                    <select name="semester" class="form-input" required>

                        <option value="1st"
                        <?= (($_GET['semester'] ?? '') == '1st') ? 'selected' : '' ?>>
                            1st Semester
                        </option>

                        <option value="2nd"
                        <?= (($_GET['semester'] ?? '') == '2nd') ? 'selected' : '' ?>>
                            2nd Semester
                        </option>

                    </select>
                </div>

                <div class="flex items-end">

                    <button type="submit" name="search" class="btn btn-primary">
                        🔍 Search
                    </button>

                </div>

            </form>

        </div>
    </div>

    <!-- STUDENT RESULTS -->
    <?php if (!empty($students_found)): ?>

        <?php foreach ($students_found as $data): ?>

            <?php
            $student = $data['student'];
            $school_year = $data['school_year'];
            $semester = $data['semester'];
            $student_id = $student['student_id'];

            /* BILLING */
            $billing_sql = "
                SELECT *
                FROM billing_master
                WHERE student_id = $student_id
                AND sy = '$school_year'
                AND sem = '$semester'
            ";

            $billing_result = mysqli_query($conn, $billing_sql);

            $billing = null;
            $total_billing = 0;

            if ($billing_result && mysqli_num_rows($billing_result) > 0) {

                while ($bill = mysqli_fetch_assoc($billing_result)) {

                    $total_billing += $bill['total_amount'];

                    if (!$billing) {
                        $billing = $bill;
                    }
                }
            }

            /* PAYMENTS */
            $payment_sql = "
                SELECT p.*
                FROM payments p
                INNER JOIN billing_master b
                    ON p.billing_id = b.billing_id
                WHERE p.student_id = $student_id
                AND b.sy = '$school_year'
                AND b.sem = '$semester'
            ";

            $payment_result = mysqli_query($conn, $payment_sql);

            $total_payments = 0;

            if ($payment_result && mysqli_num_rows($payment_result) > 0) {

                while ($pay = mysqli_fetch_assoc($payment_result)) {
                    $total_payments += $pay['amount_paid'];
                }

                mysqli_data_seek($payment_result, 0);
            }

            $balance = $total_billing - $total_payments;
            ?>

            <div class="card mb-6">

                <div class="card-header">

                    <h3 class="card-title">
                        👤 <?= htmlspecialchars($student['fname'] . ' ' . $student['lname']) ?>
                    </h3>

                </div>

                <div class="card-body">

                    <p><strong>Student ID:</strong> <?= $student['student_id'] ?></p>
                    <p><strong>Course:</strong> <?= htmlspecialchars($student['course']) ?></p>
                    <p><strong>School Year:</strong> <?= htmlspecialchars($school_year) ?></p>
                    <p><strong>Semester:</strong> <?= htmlspecialchars($semester) ?></p>

                    <hr>

                    <p>
                        <strong>Total Billing:</strong>
                        ₱<?= number_format($total_billing, 2) ?>
                    </p>

                    <p>
                        <strong>Total Paid:</strong>
                        ₱<?= number_format($total_payments, 2) ?>
                    </p>

                    <p>
                        <strong>Balance:</strong>
                        ₱<?= number_format($balance, 2) ?>
                    </p>

                    <hr>

                    <?php if ($payment_result && mysqli_num_rows($payment_result) > 0): ?>

                        <table border="1" width="100%" cellpadding="5">

                            <tr>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Receipt</th>
                            </tr>

                            <?php while ($pay = mysqli_fetch_assoc($payment_result)): ?>

                                <tr>

                                    <td>
                                        ₱<?= number_format($pay['amount_paid'], 2) ?>
                                    </td>

                                    <td>
                                        <?= $pay['payment_date'] ?>
                                    </td>

                                    <td>
                                        <a href="receipt.php?id=<?= $pay['payment_id'] ?>" target="_blank">
                                            Print Receipt
                                        </a>
                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        </table>

                    <?php endif; ?>

                    <hr>

                    <?php if ($balance > 0 && $billing): ?>

                        <form method="POST">

                            <input type="hidden" name="student_id" value="<?= $student_id ?>">
                            <input type="hidden" name="billing_id" value="<?= $billing['billing_id'] ?>">

                            <input
                                type="number"
                                step="0.01"
                                name="payment_amount"
                                placeholder="Enter payment"
                                required
                            >

                            <button type="submit" name="make_payment">
                                💰 Pay Now
                            </button>

                        </form>

                    <?php else: ?>

                        <p>✅ Fully Paid</p>

                    <?php endif; ?>

                </div>

            </div>

        <?php endforeach; ?>

    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>