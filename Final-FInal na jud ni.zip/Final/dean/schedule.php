<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

$data = mysqli_query($conn, "
    SELECT *
    FROM subjectssem120182019
    WHERE INSTRUCTOR IS NOT NULL
    ORDER BY COURSE ASC, SUBJECT ASC
");

/* GET STATISTICS */
$statsQuery = mysqli_query($conn, "
    SELECT 
        COUNT(*) as scheduled_classes,
        COUNT(DISTINCT ROOM) as unique_rooms,
        COUNT(DISTINCT INSTRUCTOR) as unique_instructors,
        COUNT(DISTINCT COURSE) as courses_with_schedule
    FROM subjectssem120182019
    WHERE INSTRUCTOR IS NOT NULL
");
$stats = mysqli_fetch_assoc($statsQuery);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>📅 Class Schedule Management</h1>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= $stats['scheduled_classes'] ?? 0 ?></div>
            <div class="stat-label">Scheduled Classes</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $stats['unique_rooms'] ?? 0 ?></div>
            <div class="stat-label">Unique Rooms</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= $stats['unique_instructors'] ?? 0 ?></div>
            <div class="stat-label">Unique Instructors</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= $stats['courses_with_schedule'] ?? 0 ?></div>
            <div class="stat-label">Courses with Schedule</div>
        </div>
    </div>

    <!-- Schedule Table -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 Class Schedule</h2>
            <p class="text-sm text-secondary">All scheduled classes with assigned instructors</p>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($data) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Class #</th>
                                <th>Course</th>
                                <th>Subject Code</th>
                                <th>Description</th>
                                <th>Room</th>
                                <th>Schedule</th>
                                <th>Instructor</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($r = mysqli_fetch_assoc($data)) { ?>
                                <tr>
                                    <td><span class="badge badge-primary"><?= $r['CN'] ?></span></td>
                                    <td>
                                        <span class="badge badge-secondary"><?= htmlspecialchars($r['COURSE']) ?></span>
                                    </td>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($r['SUBJECT']) ?></div>
                                    </td>
                                    <td><?= htmlspecialchars($r['DESC']) ?></td>
                                    <td><?= htmlspecialchars($r['ROOM']) ?></td>
                                    <td>
                                        <div class="text-sm">
                                            <?= htmlspecialchars($r['TSTART'] ?? 'TBA') ?> - <?= htmlspecialchars($r['TEND'] ?? 'TBA') ?><br>
                                            <span class="text-secondary"><?= htmlspecialchars($r['DAYS'] ?? 'TBA') ?></span>
                                        </div>
                                    </td>
                                    <td><?= htmlspecialchars($r['INSTRUCTOR']) ?></td>
                                    <td>
                                        <div class="flex gap-2">
                                            <button class="btn btn-outline btn-sm">
                                                ✏️ Edit Schedule
                                            </button>
                                            <button class="btn btn-primary btn-sm">
                                                👥 View Students
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No scheduled classes found.</strong> There are currently no classes with assigned instructors in the system.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="assign_teacher.php" class="btn btn-primary">
                    👨‍🏫 Assign Teachers
                </a>
                <a href="subjects.php" class="btn btn-secondary">
                    📖 Manage Subjects
                </a>
                <a href="courses.php" class="btn btn-outline">
                    📚 Manage Courses
                </a>
                <a href="dean_dashboard.php" class="btn btn-outline">
                    ← Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Schedule Management Guidelines</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Scheduling Best Practices:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Ensure no room conflicts for same time slots</li>
                        <li>• Verify instructor availability before assignment</li>
                        <li>• Maintain balanced class sizes across courses</li>
                        <li>• Consider student course requirements when scheduling</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Academic Calendar:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Finalize schedules before enrollment period</li>
                        <li>• Provide schedule changes before add/drop period</li>
                        <li>• Coordinate with department heads for conflicts</li>
                        <li>• Update room assignments as needed</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>