<?php
require_once __DIR__ . '/../config/db_connection.php';

$db = new Database();
$conn = $db->getConnection();

session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'dean') {
    header("Location: ../auth/login.php");
    exit();
}

$application_id = intval($_GET['id']);

// Get application details before updating
$appQuery = mysqli_query($conn, "SELECT fname, lname FROM applications WHERE app_id = $application_id");
$application = mysqli_fetch_assoc($appQuery);

if (!$application) {
    $_SESSION['message'] = 'Application not found';
    $_SESSION['message_type'] = 'error';
} else {
    // Update application status to rejected
    $result = mysqli_query($conn, "UPDATE applications SET status='rejected' WHERE app_id = $application_id");

    if ($result) {
        $_SESSION['message'] = "Application for {$application['fname']} {$application['lname']} has been rejected.";
        $_SESSION['message_type'] = 'success';
    } else {
        $_SESSION['message'] = 'Error rejecting application: ' . mysqli_error($conn);
        $_SESSION['message_type'] = 'error';
    }
}

header("Location: students.php");
exit();
?>
