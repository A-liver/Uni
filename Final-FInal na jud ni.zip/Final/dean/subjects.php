<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

$message = '';
$messageType = '';

/* ADD */
if (isset($_POST['add'])) {
    $course = mysqli_real_escape_string($conn, $_POST['course']);
    $code = mysqli_real_escape_string($conn, $_POST['code']);
    $desc = mysqli_real_escape_string($conn, $_POST['desc']);
    $units = mysqli_real_escape_string($conn, $_POST['units']);
    $room = mysqli_real_escape_string($conn, $_POST['room']);
    $term = mysqli_real_escape_string($conn, $_POST['term']);
    
    $result = mysqli_query($conn, "
        INSERT INTO subjectssem120182019
        (COURSE, SUBJECT, `DESC`, UNIT, ROOM, TERM)
        VALUES (
            '$course',
            '$code',
            '$desc',
            '$units',
            '$room',
            '$term'
        )
    ");
    
    if ($result) {
        $message = "Subject added successfully!";
        $messageType = 'success';
    } else {
        $message = "Error adding subject: " . mysqli_error($conn);
        $messageType = 'error';
    }
}

/* DELETE */
if (isset($_GET['del'])) {
    $cn = mysqli_real_escape_string($conn, $_GET['del']);
    $subject = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUBJECT FROM subjectssem120182019 WHERE CN='$cn'"));
    
    $result = mysqli_query($conn, "DELETE FROM subjectssem120182019 WHERE CN='$cn'");
    
    if ($result) {
        $message = "Subject '{$subject['SUBJECT']}' deleted successfully!";
        $messageType = 'warning';
    } else {
        $message = "Error deleting subject: " . mysqli_error($conn);
        $messageType = 'error';
    }
}

$data = mysqli_query($conn, "SELECT * FROM subjectssem120182019 ORDER BY COURSE ASC, SUBJECT ASC");

/* GET STATISTICS */
$statsQuery = mysqli_query($conn, "
    SELECT 
        COUNT(*) as total_subjects,
        COUNT(DISTINCT COURSE) as unique_courses,
        SUM(UNIT) as total_units,
        COUNT(DISTINCT TERM) as unique_terms
    FROM subjectssem120182019
");
$stats = mysqli_fetch_assoc($statsQuery);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1>📖 Subjects Catalog Management</h1>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?> mb-6">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= $stats['total_subjects'] ?? 0 ?></div>
            <div class="stat-label">Total Subjects</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $stats['unique_courses'] ?? 0 ?></div>
            <div class="stat-label">Unique Courses</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= $stats['total_units'] ?? 0 ?></div>
            <div class="stat-label">Total Units</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= $stats['unique_terms'] ?? 0 ?></div>
            <div class="stat-label">Unique Terms</div>
        </div>
    </div>

    <!-- Add New Subject -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">➕ Add New Subject</h2>
            <p class="text-sm text-secondary">Create a new subject for the catalog</p>
        </div>
        <div class="card-body">
            <form method="POST" class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                    <label class="form-label">Course <span class="required">*</span></label>
                    <input type="text" name="course" class="form-input" placeholder="e.g., BSIT" required>
                </div>
                <div>
                    <label class="form-label">Subject Code <span class="required">*</span></label>
                    <input type="text" name="code" class="form-input" placeholder="e.g., IT101" required>
                </div>
                <div>
                    <label class="form-label">Description <span class="required">*</span></label>
                    <input type="text" name="desc" class="form-input" placeholder="e.g., Introduction to IT" required>
                </div>
                <div>
                    <label class="form-label">Units <span class="required">*</span></label>
                    <input type="number" name="units" class="form-input" placeholder="e.g., 3" required>
                </div>
                <div>
                    <label class="form-label">Room</label>
                    <input type="text" name="room" class="form-input" placeholder="e.g., Room 101">
                </div>
                <div>
                    <label class="form-label">Term</label>
                    <input type="text" name="term" class="form-input" placeholder="e.g., 1st Semester">
                </div>
                <div class="md:col-span-3">
                    <button type="submit" name="add" class="btn btn-primary">
                        ➕ Add Subject
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Subjects List -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 Subjects Catalog</h2>
            <p class="text-sm text-secondary">Complete list of all available subjects</p>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($data) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Class #</th>
                                <th>Course</th>
                                <th>Subject Code</th>
                                <th>Description</th>
                                <th>Units</th>
                                <th>Room</th>
                                <th>Term</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($s = mysqli_fetch_assoc($data)) { ?>
                                <tr>
                                    <td><span class="badge badge-primary"><?= $s['CN'] ?></span></td>
                                    <td>
                                        <span class="badge badge-secondary"><?= htmlspecialchars($s['COURSE']) ?></span>
                                    </td>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($s['SUBJECT']) ?></div>
                                    </td>
                                    <td><?= htmlspecialchars($s['DESC']) ?></td>
                                    <td><?= $s['UNIT'] ?></td>
                                    <td><?= htmlspecialchars($s['ROOM']) ?></td>
                                    <td><?= htmlspecialchars($s['TERM']) ?></td>
                                    <td>
                                        <div class="flex gap-2">
                                            <button class="btn btn-outline btn-sm">
                                                ✏️ Edit
                                            </button>
                                            <a href="?del=<?= $s['CN'] ?>" 
                                               onclick="return confirm('Are you sure you want to delete this subject? This action cannot be undone.')" 
                                               class="btn btn-danger btn-sm">
                                                🗑️ Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No subjects found.</strong> Start by adding your first subject using the form above.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="courses.php" class="btn btn-primary">
                    📚 Manage Courses
                </a>
                <a href="enrollment.php" class="btn btn-secondary">
                    👥 Student Enrollment
                </a>
                <a href="assign_teacher.php" class="btn btn-outline">
                    👨‍🏫 Assign Teachers
                </a>
                <a href="dean_dashboard.php" class="btn btn-outline">
                    ← Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Subject Management Guidelines</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Adding Subjects:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Use standard subject codes (e.g., IT101, MATH201)</li>
                        <li>• Provide clear, descriptive subject names</li>
                        <li>• Specify appropriate units (typically 1-4 units)</li>
                        <li>• Assign room locations for scheduling</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Important Notes:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Deleting a subject removes all related enrollments</li>
                        <li>• Subjects are used in student enrollment and grading</li>
                        <li>• Regular review of subject catalog recommended</li>
                        <li>• Coordinate with department heads for updates</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>