<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

/* STATS */
$students = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM students"))['c'];
$courses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM courses"))['c'];
$enrolled = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM student_subjects"))['c'];
$pendingApps = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM applications WHERE status='pending' OR status IS NULL"))['c'];

$activeSY = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT sy, sem, COUNT(*) AS c
    FROM student_subjects
    GROUP BY sy, sem
    ORDER BY sy DESC
    LIMIT 1
"));
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-graduation-cap"></i> Dean Dashboard
            </h1>
        </div>
    </div>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?> mb-6">
            <i class="fas fa-info-circle"></i> <?php
            echo htmlspecialchars($_SESSION['message']);
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
            ?>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= number_format($students) ?></div>
            <div class="stat-label">
                <i class="fas fa-user-graduate"></i> Total Students
            </div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= number_format($courses) ?></div>
            <div class="stat-label">
                <i class="fas fa-book"></i> Active Courses
            </div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= number_format($enrolled) ?></div>
            <div class="stat-label">
                <i class="fas fa-tasks"></i> Enrolled Subjects
            </div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= number_format($pendingApps) ?></div>
            <div class="stat-label">
                <i class="fas fa-clock"></i> Pending Applications
            </div>
        </div>
    </div>

    <!-- Pending Applications Alert -->
    <?php if ($pendingApps > 0): ?>
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-user-clock"></i> Pending Student Applications
            </h2>
            <p class="text-sm text-secondary">You have <?= number_format($pendingApps) ?> pending student application(s) requiring approval</p>
        </div>
        <div class="card-body">
            <div class="flex gap-4">
                <a href="students.php" class="btn btn-primary">
                    <i class="fas fa-check-circle"></i> Review Applications
                </a>
                <a href="students.php" class="btn btn-outline">
                    <i class="fas fa-arrow-right"></i> View All Students
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Quick Actions -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-tachometer-alt"></i> Academic Management
            </h2>
            <p class="text-sm text-secondary">Quick access to academic administration tools</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <a href="students.php" class="btn btn-primary">
                    <i class="fas fa-users"></i> Student Records
                </a>
                <a href="courses.php" class="btn btn-secondary">
                    <i class="fas fa-book"></i> Courses Management
                </a>
                <a href="subjects.php" class="btn btn-outline">
                    <i class="fas fa-book-open"></i> Subjects Management
                </a>
                <a href="enrollment.php" class="btn btn-success">
                    <i class="fas fa-user-plus"></i> Enrollment Control
                </a>
                <a href="teacher_subject.php" class="btn btn-info">
                    <i class="fas fa-chalkboard-teacher"></i> Teacher Assignments
                </a>
                <a href="schedule.php" class="btn btn-warning">
                    <i class="fas fa-calendar-alt"></i> Schedule Management
                </a>
            </div>
        </div>
    </div>

    <!-- Academic Overview -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-chart-bar"></i> Academic Overview
            </h2>
            <p class="text-sm text-secondary">Key statistics and academic information</p>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-4">
                        <i class="fas fa-user-graduate"></i> Student Statistics
                    </h4>
                    <ul class="space-y-2">
                        <li class="flex justify-between">
                            <span>Total Enrolled:</span>
                            <span class="badge badge-primary"><?= number_format($students) ?></span>
                        </li>
                        <li class="flex justify-between">
                            <span>Active Enrollments:</span>
                            <span class="badge badge-success"><?= number_format($enrolled) ?></span>
                        </li>
                        <li class="flex justify-between">
                            <span>Avg. Subjects/Student:</span>
                            <span class="badge badge-warning"><?= $students > 0 ? round($enrolled / $students, 1) : 0 ?></span>
                        </li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">
                        <i class="fas fa-info-circle"></i> Curriculum Information
                    </h4>
                    <ul class="space-y-2">
                        <li class="flex justify-between">
                            <span>Total Courses:</span>
                            <span class="badge badge-primary"><?= number_format($courses) ?></span>
                        </li>
                        <li class="flex justify-between">
                            <span>Current School Year:</span>
                            <span class="badge badge-info"><?= $activeSY['sy'] ?? 'Not Set' ?></span>
                        </li>
                        <li class="flex justify-between">
                            <span>Current Semester:</span>
                            <span class="badge badge-info"><?= $activeSY['sem'] ?? 'Not Set' ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-bell"></i> System Status
            </h2>
            <p class="text-sm text-secondary">Current academic period and system information</p>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> <strong>Academic Period:</strong> School Year <?= $activeSY['sy'] ?? 'Not Set' ?>, Semester <?= $activeSY['sem'] ?? 'Not Set' ?> is currently active.
            </div>
            <p class="text-secondary">
                Monitor enrollment progress, course availability, and teacher assignments through the management tools above.
            </p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>