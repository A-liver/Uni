<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'dean') exit("Access denied");

/* LIST */
$data = mysqli_query($conn, "
    SELECT ss.*, s.lname, s.fname
    FROM student_subjects ss
    JOIN students s ON s.student_id = ss.student_id
    ORDER BY s.lname ASC
");

/* GET STATISTICS */
$statsQuery = mysqli_query($conn, "
    SELECT 
        COUNT(*) as total_enrollments,
        COUNT(DISTINCT student_id) as unique_students,
        COUNT(DISTINCT subject_code) as unique_subjects,
        COUNT(DISTINCT sy) as academic_years
    FROM student_subjects
");
$stats = mysqli_fetch_assoc($statsQuery);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-user-plus"></i> Student Enrollment Management
            </h1>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value"><?= $stats['total_enrollments'] ?? 0 ?></div>
            <div class="stat-label">Total Enrollments</div>
        </div>
        <div class="stat-card success">
            <div class="stat-value"><?= $stats['unique_students'] ?? 0 ?></div>
            <div class="stat-label">Unique Students</div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value"><?= $stats['unique_subjects'] ?? 0 ?></div>
            <div class="stat-label">Unique Subjects</div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value"><?= $stats['academic_years'] ?? 0 ?></div>
            <div class="stat-label">Academic Years</div>
        </div>
    </div>

    <!-- Enrollment List -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📋 All Enrollments</h2>
            <p class="text-sm text-secondary">Complete list of student enrollments</p>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($data) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Subject Code</th>
                                <th>Description</th>
                                <th>School Year</th>
                                <th>Semester</th>
                                <th>Instructor</th>
                                <th>Units</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($r = mysqli_fetch_assoc($data)) { ?>
                                <tr>
                                    <td>
                                        <div class="font-semibold"><?= htmlspecialchars($r['lname'] . ', ' . $r['fname']) ?></div>
                                        <div class="text-sm text-secondary">ID: <?= $r['student_id'] ?></div>
                                    </td>
                                    <td>
                                        <span class="badge badge-primary"><?= htmlspecialchars($r['subject_code']) ?></span>
                                    </td>
                                    <td><?= htmlspecialchars($r['description']) ?></td>
                                    <td><?= htmlspecialchars($r['sy']) ?></td>
                                    <td>
                                        <span class="badge badge-secondary"><?= htmlspecialchars($r['sem']) ?></span>
                                    </td>
                                    <td><?= htmlspecialchars($r['instructor']) ?></td>
                                    <td><?= $r['units'] ?></td>
                                    <td>
                                        <div class="flex gap-2">
                                            <button class="btn btn-outline btn-sm">
                                                📊 View Grades
                                            </button>
                                            <button class="btn btn-danger btn-sm">
                                                🗑️ Remove
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No enrollments found.</strong> There are currently no student enrollments in the system.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="courses.php" class="btn btn-primary">
                    📚 Manage Courses
                </a>
                <a href="subjects.php" class="btn btn-secondary">
                    📖 Manage Subjects
                </a>
                <a href="students.php" class="btn btn-outline">
                    👥 View Students
                </a>
                <a href="assign_teacher.php" class="btn btn-outline">
                    👨‍🏫 Assign Teachers
                </a>
            </div>
        </div>
    </div>

    <!-- Important Information -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">📋 Enrollment Guidelines</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Enrollment Process:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Verify student eligibility before enrollment</li>
                        <li>• Check subject prerequisites and availability</li>
                        <li>• Ensure class capacity limits are not exceeded</li>
                        <li>• Update student billing after enrollment changes</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Academic Policies:</h4>
                    <ul class="space-y-2 text-sm text-secondary">
                        <li>• Maximum units per semester: 24 units</li>
                        <li>• Minimum units for full-time status: 12 units</li>
                        <li>• Add/drop period: First 2 weeks of classes</li>
                        <li>• Late enrollment requires dean's approval</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>