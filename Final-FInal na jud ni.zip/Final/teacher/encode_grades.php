<?php
require_once __DIR__ . '/../includes/header.php';

if ($_SESSION['role'] != 'teacher') exit("Access denied");

$cn = mysqli_real_escape_string($conn, $_GET['cn']);
$sy = mysqli_real_escape_string($conn, $_GET['sy']);
$sem = mysqli_real_escape_string($conn, $_GET['sem']);
$sub = mysqli_real_escape_string($conn, $_GET['sub']);

// Get class information
$classInfo = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT description, instructor 
    FROM student_subjects 
    WHERE cn = '$cn' AND sy = '$sy' AND sem = '$sem' AND subject_code = '$sub'
    LIMIT 1
"));

$students = mysqli_query($conn, "
    SELECT ss.*, s.fname, s.lname
    FROM student_subjects ss
    INNER JOIN students s ON ss.student_id = s.student_id
    WHERE ss.cn='$cn'
    AND ss.sy='$sy'
    AND ss.sem='$sem'
    AND ss.subject_code='$sub'
    ORDER BY s.lname ASC, s.fname ASC
");

$studentCount = mysqli_num_rows($students);
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-edit"></i> Encode Grades
            </h1>
        </div>
    </div>

    <!-- Class Information -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-info-circle"></i> Class Information
            </h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="info-card info-card-primary">
                    <span class="info-label">Class Number</span>
                    <div class="info-value"><?= htmlspecialchars($cn) ?></div>
                </div>
                <div class="info-card info-card-success">
                    <span class="info-label">Subject</span>
                    <div class="info-value"><?= htmlspecialchars($sub) ?></div>
                </div>
                <div class="info-card info-card-info">
                    <span class="info-label">School Year</span>
                    <div class="info-value"><?= htmlspecialchars($sy) ?></div>
                </div>
                <div class="info-card info-card-warning">
                    <span class="info-label">Semester</span>
                    <div class="info-value"><?= htmlspecialchars($sem) ?></div>
                </div>
            </div>
            <?php if ($classInfo): ?>
                <div class="mt-4">
                    <span class="text-secondary text-sm">Description:</span>
                    <div class="font-semibold"><?= htmlspecialchars($classInfo['description']) ?></div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Grading Guidelines -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">📋 Grading Guidelines</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold mb-3">Grading System:</h4>
                    <ul class="space-y-2 text-sm">
                        <li>• <strong>75.00 and above:</strong> PASSED</li>
                        <li>• <strong>Below 75.00:</strong> FAILED</li>
                        <li>• <strong>Final Grade:</strong> Average of G1, G2, G3</li>
                        <li>• <strong>Grades:</strong> Input values from 0.00 to 100.00</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-3">Grade Components:</h4>
                    <ul class="space-y-2 text-sm">
                        <li>• <strong>G1 (Prelim):</strong> First grading period</li>
                        <li>• <strong>G2 (Midterm):</strong> Second grading period</li>
                        <li>• <strong>G3 (Final):</strong> Third grading period</li>
                        <li>• <strong>Remarks:</strong> Auto-calculated based on final grade</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Grade Encoding Form -->
    <?php if ($studentCount > 0): ?>
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">🎯 Grade Entry</h2>
                <p class="text-sm text-secondary">Enter grades for each student. Final grades and remarks are calculated automatically.</p>
            </div>
            <div class="card-body">
                <form method="POST" action="save_grades.php" id="gradeForm">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Student ID</th>
                                    <th>Name</th>
                                    <th>G1 (Prelim)</th>
                                    <th>G2 (Midterm)</th>
                                    <th>G3 (Final)</th>
                                    <th>Final Grade</th>
                                    <th>Remarks</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $gradedCount = 0;
                                while($s = mysqli_fetch_assoc($students)) {
                                    $isGraded = ($s['g1'] > 0 && $s['g2'] > 0 && $s['g3'] > 0);
                                    if ($isGraded) $gradedCount++;
                                ?>
                                    <tr>
                                        <td>
                                            <span class="badge badge-primary"><?= $s['student_id'] ?></span>
                                            <input type="hidden" name="id[]" value="<?= $s['id'] ?>">
                                        </td>
                                        <td>
                                            <div class="font-semibold"><?= htmlspecialchars($s['lname']) . ', ' . htmlspecialchars($s['fname']) ?></div>
                                        </td>
                                        <td>
                                            <input type="number" 
                                                   step="0.01" 
                                                   min="0" 
                                                   max="100" 
                                                   class="form-input g1 grade-input" 
                                                   name="g1[<?= $s['id'] ?>]" 
                                                   value="<?= $s['g1'] ?>"
                                                   placeholder="0.00"
                                                   style="width: 100px;">
                                        </td>
                                        <td>
                                            <input type="number" 
                                                   step="0.01" 
                                                   min="0" 
                                                   max="100" 
                                                   class="form-input g2 grade-input" 
                                                   name="g2[<?= $s['id'] ?>]" 
                                                   value="<?= $s['g2'] ?>"
                                                   placeholder="0.00"
                                                   style="width: 100px;">
                                        </td>
                                        <td>
                                            <input type="number" 
                                                   step="0.01" 
                                                   min="0" 
                                                   max="100" 
                                                   class="form-input g3 grade-input" 
                                                   name="g3[<?= $s['id'] ?>]" 
                                                   value="<?= $s['g3'] ?>"
                                                   placeholder="0.00"
                                                   style="width: 100px;">
                                        </td>
                                        <td>
                                            <input type="text" 
                                                   class="form-input final-grade" 
                                                   name="final[<?= $s['id'] ?>]" 
                                                   value="<?= $s['final'] ?>" 
                                                   readonly
                                                   style="width: 80px; background: var(--bg-secondary);">
                                        </td>
                                        <td>
                                            <input type="text" 
                                                   class="form-input remarks-input" 
                                                   name="remarks[<?= $s['id'] ?>]" 
                                                   value="<?= $s['remarks'] ?>" 
                                                   readonly
                                                   style="width: 80px; background: var(--bg-secondary);">
                                        </td>
                                        <td>
                                            <span class="grade-status badge badge-<?= $isGraded ? 'success' : 'secondary' ?>">
                                                <?= $isGraded ? '✓ Complete' : '⏳ Pending' ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-6 flex justify-between items-center">
                        <div class="text-sm text-secondary">
                            <strong>Progress:</strong> <?= $gradedCount ?> / <?= $studentCount ?> students graded
                        </div>
                        <div class="flex gap-2">
                            <button type="button" onclick="clearAllGrades()" class="btn btn-outline btn-sm">
                                🔄 Clear All
                            </button>
                            <button type="submit" class="btn btn-primary">
                                💾 Save All Grades
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-body">
                <div class="alert alert-info">
                    <strong>No students enrolled</strong> in this class yet.
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Quick Actions -->
    <div class="card mt-6">
        <div class="card-header">
            <h2 class="card-title">⚡ Quick Actions</h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-3 gap-4">
                <a href="class_list.php?cn=<?= $cn ?>&sy=<?= $sy ?>&sem=<?= $sem ?>&sub=<?= $sub ?>" class="btn btn-secondary">
                    ← View Class List
                </a>
                <a href="print_grades.php?cn=<?= $cn ?>&sy=<?= $sy ?>&sem=<?= $sem ?>&sub=<?= $sub ?>" class="btn btn-outline">
                    🖨️ Print Grades
                </a>
                <a href="teacher_dashboard.php" class="btn btn-outline">
                    Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced Auto Calculation Script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const gradeRows = document.querySelectorAll('tbody tr');
    
    gradeRows.forEach(row => {
        const g1 = row.querySelector('.g1');
        const g2 = row.querySelector('.g2');
        const g3 = row.querySelector('.g3');
        const final = row.querySelector('.final-grade');
        const remarks = row.querySelector('.remarks-input');
        const status = row.querySelector('.grade-status');
        
        function computeGrades() {
            const v1 = parseFloat(g1?.value || 0);
            const v2 = parseFloat(g2?.value || 0);
            const v3 = parseFloat(g3?.value || 0);
            
            if (v1 >= 0 && v2 >= 0 && v3 >= 0 && v1 <= 100 && v2 <= 100 && v3 <= 100) {
                const avg = (v1 + v2 + v3) / 3;
                final.value = avg.toFixed(2);
                
                const passed = avg >= 75;
                remarks.value = passed ? 'PASSED' : 'FAILED';
                
                // Update status badge
                if (status) {
                    status.className = `grade-status badge badge-${v1 > 0 && v2 > 0 && v3 > 0 ? 'success' : 'secondary'}`;
                    status.textContent = v1 > 0 && v2 > 0 && v3 > 0 ? '✓ Complete' : '⏳ Pending';
                }
                
                // Add color coding to final grade
                final.style.background = passed ? 'var(--bg-success)' : 'var(--bg-danger)';
                final.style.color = 'white';
                remarks.style.background = passed ? 'var(--bg-success)' : 'var(--bg-danger)';
                remarks.style.color = 'white';
            }
        }
        
        // Add event listeners
        if (g1 && g2 && g3) {
            [g1, g2, g3].forEach(input => {
                input.addEventListener('input', computeGrades);
                input.addEventListener('blur', function() {
                    // Validate input range
                    const value = parseFloat(this.value);
                    if (value < 0 || value > 100 || isNaN(value)) {
                        this.value = '';
                        computeGrades();
                    }
                });
            });
            
            // Initial calculation
            computeGrades();
        }
    });
});

function clearAllGrades() {
    if (confirm('Are you sure you want to clear all grades for this class?')) {
        document.querySelectorAll('.grade-input').forEach(input => {
            input.value = '';
        });
        document.querySelectorAll('.final-grade, .remarks-input').forEach(input => {
            input.value = '';
            input.style.background = 'var(--bg-secondary)';
            input.style.color = '';
        });
        document.querySelectorAll('.grade-status').forEach(badge => {
            badge.className = 'grade-status badge badge-secondary';
            badge.textContent = '⏳ Pending';
        });
    }
}

// Form submission validation
document.getElementById('gradeForm').addEventListener('submit', function(e) {
    const incompleteGrades = [];
    const rows = document.querySelectorAll('tbody tr');
    
    rows.forEach((row, index) => {
        const g1 = row.querySelector('.g1');
        const g2 = row.querySelector('.g2');
        const g3 = row.querySelector('.g3');
        
        if (g1 && g2 && g3) {
            const v1 = parseFloat(g1.value || 0);
            const v2 = parseFloat(g2.value || 0);
            const v3 = parseFloat(g3.value || 0);
            
            if (v1 === 0 || v2 === 0 || v3 === 0) {
                const studentId = row.querySelector('.badge-primary').textContent;
                incompleteGrades.push(studentId);
            }
        }
    });
    
    if (incompleteGrades.length > 0) {
        const confirmMsg = `The following students have incomplete grades:\n${incompleteGrades.join(', ')}\n\nDo you want to save anyway?`;
        if (!confirm(confirmMsg)) {
            e.preventDefault();
        }
    }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>