<?php
require_once __DIR__ . '/../includes/header.php';

// Check role
if ($_SESSION['role'] != 'teacher') exit("Access denied");

$cn  = mysqli_real_escape_string($conn, $_GET['cn'] ?? '');
$sy  = mysqli_real_escape_string($conn, $_GET['sy'] ?? '');
$sem = mysqli_real_escape_string($conn, $_GET['sem'] ?? '');
$sub = mysqli_real_escape_string($conn, $_GET['sub'] ?? '');

// Use INNER JOIN to get fname from the students table
$students = mysqli_query($conn, "
    SELECT ss.*, s.fname, s.lname
    FROM student_subjects ss
    INNER JOIN students s ON ss.student_id = s.student_id
    WHERE ss.cn = '$cn'
    AND ss.sy = '$sy'
    AND ss.sem = '$sem'
    AND ss.subject_code = '$sub'
    ORDER BY s.student_id ASC
");
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-users"></i> Class List
            </h1>
        </div>
        <div class="flex gap-2">
            <a href="encode_grades.php?cn=<?= $cn ?>&sy=<?= $sy ?>&sem=<?= $sem ?>&sub=<?= $sub ?>" class="btn btn-success">
                <i class="fas fa-edit"></i> Encode Grades
            </a>
            <a href="print_grades.php?cn=<?= $cn ?>&sy=<?= $sy ?>&sem=<?= $sem ?>&sub=<?= $sub ?>" class="btn btn-outline">
                <i class="fas fa-print"></i> Print Grades
            </a>
        </div>
    </div>

    <!-- Class Info -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-info-circle"></i> Class Information
            </h2>
        </div>
        <div class="card-body">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="info-card info-card-primary">
                    <span class="info-label">Subject Code</span>
                    <div class="info-value"><?= htmlspecialchars($sub) ?></div>
                </div>
                <div class="info-card info-card-success">
                    <span class="info-label">Class Number</span>
                    <div class="info-value"><?= htmlspecialchars($cn) ?></div>
                </div>
                <div class="info-card info-card-info">
                    <span class="info-label">School Year</span>
                    <div class="info-value"><?= htmlspecialchars($sy) ?></div>
                </div>
                <div class="info-card info-card-warning">
                    <span class="info-label">Semester</span>
                    <div class="info-value"><?= htmlspecialchars($sem) ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Students List -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-user-graduate"></i> Enrolled Students
            </h2>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($students) > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Prelim</th>
                                <th>Midterm</th>
                                <th>Final</th>
                                <th>Average</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($s = mysqli_fetch_assoc($students)) { ?>
                                <tr>
                                    <td>
                                        <span class="badge badge-primary"><?= htmlspecialchars($s['student_id']) ?></span>
                                    </td>
                                    <td><?= htmlspecialchars($s['fname']) ?></td>
                                    <td><?= htmlspecialchars($s['lname']) ?></td>
                                    <td><?= $s['g1'] ?? '-' ?></td>
                                    <td><?= $s['g2'] ?? '-' ?></td>
                                    <td><?= $s['g3'] ?? '-' ?></td>
                                    <td>
                                        <?php if ($s['final']): ?>
                                            <span class="badge badge-<?= $s['final'] >= 75 ? 'success' : 'danger' ?>">
                                                <?= $s['final'] ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-secondary">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($s['remarks']): ?>
                                            <span class="badge badge-<?= $s['remarks'] == 'PASSED' ? 'success' : 'danger' ?>">
                                                <?= $s['remarks'] ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-secondary">Not encoded</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <strong>No students enrolled.</strong> There are no students assigned to this class.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>