<?php
// Start session and get DB connection without output
require_once __DIR__ . '/../config/db_connection.php';

$db = new Database();
$conn = $db->getConnection();

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $success_count = 0;
    $error_count = 0;
    $errors = [];

    foreach ($_POST['g1'] as $id => $val) {
        $id = mysqli_real_escape_string($conn, $id);
        $g1 = mysqli_real_escape_string($conn, $_POST['g1'][$id]);
        $g2 = mysqli_real_escape_string($conn, $_POST['g2'][$id]);
        $g3 = mysqli_real_escape_string($conn, $_POST['g3'][$id]);
        $final = mysqli_real_escape_string($conn, $_POST['final'][$id]);
        $remarks = mysqli_real_escape_string($conn, $_POST['remarks'][$id]);

        // Validate grades
        if (!is_numeric($g1) || $g1 < 0 || $g1 > 100) $errors[] = "Invalid G1 grade for ID: $id";
        if (!is_numeric($g2) || $g2 < 0 || $g2 > 100) $errors[] = "Invalid G2 grade for ID: $id";
        if (!is_numeric($g3) || $g3 < 0 || $g3 > 100) $errors[] = "Invalid G3 grade for ID: $id";
        if (!is_numeric($final) || $final < 0 || $final > 100) $errors[] = "Invalid Final grade for ID: $id";

        if (empty($errors)) {
            $result = mysqli_query($conn, "
                UPDATE student_subjects SET
                    g1='$g1',
                    g2='$g2',
                    g3='$g3',
                    final='$final',
                    remarks='$remarks'
                WHERE id='$id'
            ");

            if ($result) {
                $success_count++;
            } else {
                $error_count++;
                $errors[] = "Failed to update ID: $id - " . mysqli_error($conn);
            }
        }
    }

    // Set session message for display on redirect
    if ($error_count === 0) {
        $_SESSION['success_message'] = "All $success_count grades saved successfully!";
        $_SESSION['success_type'] = 'success';
    } else {
        $_SESSION['error_message'] = "Saved $success_count grades, but $error_count failed. Please check the grades and try again.";
        $_SESSION['error_type'] = 'warning';
        if (!empty($errors)) {
            $_SESSION['error_details'] = $errors;
        }
    }

    // Redirect back to the referring page
    $redirect_url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'teacher_dashboard.php';
    header("Location: $redirect_url");
    exit();
} else {
    // If not POST request, redirect to dashboard
    header("Location: teacher_dashboard.php");
    exit();
}
?>