<?php
require_once __DIR__ . '/../config/db_connection.php';

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: records_dashboard.php");
    exit();
}

$id = mysqli_real_escape_string($conn, $_POST['student_id']);
$fname = mysqli_real_escape_string($conn, $_POST['fname']);
$mname = mysqli_real_escape_string($conn, $_POST['mname']);
$lname = mysqli_real_escape_string($conn, $_POST['lname']);
$bdate = mysqli_real_escape_string($conn, $_POST['bdate']);
$city = mysqli_real_escape_string($conn, $_POST['city']);

// Validate required fields
if (empty($id) || empty($fname) || empty($lname)) {
    $_SESSION['error_message'] = "Student ID, First Name, and Last Name are required fields.";
    $_SESSION['error_type'] = 'error';
    header("Location: records_dashboard.php");
    exit();
}

// Handle image upload
$image_updated = false;
$image_error = '';

if (!empty($_FILES['image']['name'])) {
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
    $file_ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    
    if (!in_array($file_ext, $allowed_types)) {
        $image_error = "Invalid file type. Only JPG, JPEG, PNG, and GIF files are allowed.";
    } elseif ($_FILES['image']['size'] > 5000000) { // 5MB limit
        $image_error = "File size too large. Maximum size is 5MB.";
    } else {
        $img = time() . "_" . basename($_FILES['image']['name']);
        $upload_path = "../upload/$img";
        
        // Create upload directory if it doesn't exist
        if (!file_exists("../upload")) {
            mkdir("../upload", 0755, true);
        }
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
            $image_updated = true;
        } else {
            $image_error = "Failed to upload image. Please try again.";
        }
    }
}

// Update student information
$update_query = "
    UPDATE students
    SET fname='$fname',
        mname='$mname',
        lname='$lname',
        bdate='$bdate',
        city='$city'
";

if ($image_updated) {
    $img = mysqli_real_escape_string($conn, $img);
    $update_query .= ", image_path='$img'";
}

$update_query .= " WHERE student_id='$id'";

$result = mysqli_query($conn, $update_query);

if ($result) {
    if ($image_updated) {
        $_SESSION['success_message'] = "Student information and profile picture updated successfully!";
    } else {
        $_SESSION['success_message'] = "Student information updated successfully!";
    }
    $_SESSION['success_type'] = 'success';
    
    if ($image_error) {
        $_SESSION['warning_message'] = "Student updated but: " . $image_error;
        $_SESSION['warning_type'] = 'warning';
    }
} else {
    $_SESSION['error_message'] = "Failed to update student information: " . mysqli_error($conn);
    $_SESSION['error_type'] = 'error';
}

header("Location: records_dashboard.php");
exit();
?>