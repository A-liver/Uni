<?php
// Start session and get DB connection without output
require_once __DIR__ . '/../config/db_connection.php';

$db = new Database();
$conn = $db->getConnection();

session_start();

// Check permissions
if ($_SESSION['role'] != 'records' && $_SESSION['role'] != 'dean') {
    $_SESSION['error_message'] = "Access denied. You don't have permission to update grades.";
    $_SESSION['error_type'] = 'error';
    header("Location: records_dashboard.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: records_dashboard.php");
    exit();
}

$id = mysqli_real_escape_string($conn, $_POST['id']);
$g1 = mysqli_real_escape_string($conn, $_POST['g1']);
$g2 = mysqli_real_escape_string($conn, $_POST['g2']);
$g3 = mysqli_real_escape_string($conn, $_POST['g3']);
$final = mysqli_real_escape_string($conn, $_POST['final']);
$remarks = mysqli_real_escape_string($conn, $_POST['remarks']);

// Validate grades
$errors = [];
if (!is_numeric($g1) || $g1 < 0 || $g1 > 100) $errors[] = "Invalid G1 grade";
if (!is_numeric($g2) || $g2 < 0 || $g2 > 100) $errors[] = "Invalid G2 grade";
if (!is_numeric($g3) || $g3 < 0 || $g3 > 100) $errors[] = "Invalid G3 grade";
if (!is_numeric($final) || $final < 0 || $final > 100) $errors[] = "Invalid Final grade";

if (!empty($errors)) {
    $_SESSION['error_message'] = "Validation errors: " . implode(', ', $errors);
    $_SESSION['error_type'] = 'error';
    header("Location: records_dashboard.php");
    exit();
}

// Get student and subject info for logging
$grade_info = mysqli_query($conn, "
    SELECT ss.student_id, ss.subject_code, s.fname, s.lname
    FROM student_subjects ss
    JOIN students s ON s.student_id = ss.student_id
    WHERE ss.id='$id'
    LIMIT 1
");

$grade_data = mysqli_fetch_assoc($grade_info);

// Update grades
$result = mysqli_query($conn, "
    UPDATE student_subjects
    SET g1='$g1',
        g2='$g2',
        g3='$g3',
        final='$final',
        remarks='$remarks'
    WHERE id='$id'
");

if ($result) {
    // Log the update
    $student_name = $grade_data['fname'] . ' ' . $grade_data['lname'];
    $subject = $grade_data['subject_code'];
    
    $_SESSION['success_message'] = "Grades updated successfully for $student_name in $subject!";
    $_SESSION['success_type'] = 'success';
    
    // Additional validation for remarks
    if ($final >= 75 && $remarks != 'PASSED') {
        $_SESSION['warning_message'] = "Grade updated but remarks should be 'PASSED' for grades ≥ 75.";
        $_SESSION['warning_type'] = 'warning';
    } elseif ($final < 75 && $final > 0 && $remarks != 'FAILED') {
        $_SESSION['warning_message'] = "Grade updated but remarks should be 'FAILED' for grades < 75.";
        $_SESSION['warning_type'] = 'warning';
    }
} else {
    $_SESSION['error_message'] = "Failed to update grades: " . mysqli_error($conn);
    $_SESSION['error_type'] = 'error';
}

header("Location: records_dashboard.php");
exit();
?>