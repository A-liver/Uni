<?php
require_once __DIR__ . '/../includes/header.php';

// role protection
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}
?>

<div class="fade-in">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 style="font-size: 2rem; font-weight: 700; background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                <i class="fas fa-shield-alt"></i> Admin Dashboard
            </h1>
        </div>
    </div>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?> mb-6">
            <i class="fas fa-info-circle"></i> <?php
            echo htmlspecialchars($_SESSION['message']);
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
            ?>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-grid mb-6">
        <div class="stat-card">
            <div class="stat-value" id="pendingCount">0</div>
            <div class="stat-label">
                <i class="fas fa-clock"></i> Pending Approvals
            </div>
        </div>
        <div class="stat-card success">
            <div class="stat-value" id="activeCount">0</div>
            <div class="stat-label">
                <i class="fas fa-users"></i> Active Users
            </div>
        </div>
        <div class="stat-card warning">
            <div class="stat-value" id="totalRoles">7</div>
            <div class="stat-label">
                <i class="fas fa-user-tag"></i> User Roles
            </div>
        </div>
        <div class="stat-card danger">
            <div class="stat-value" id="rejectedCount">0</div>
            <div class="stat-label">
                <i class="fas fa-user-times"></i> Rejected Users
            </div>
        </div>
    </div>

    <!-- Pending Users Section -->
    <div class="card mb-6">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-user-clock"></i> Pending Users (Login Approval)
            </h2>
            <p class="text-sm text-secondary">Review and approve new user registration requests</p>
        </div>
        <div class="card-body">
            <?php
            $resultUsers = mysqli_query($conn, "
                SELECT * FROM users 
                WHERE role IN ('admin','student','dean','teacher','cashier','finance','records')
                AND status='pending'
                ORDER BY created_at DESC
            ");

            if (mysqli_num_rows($resultUsers) > 0) {
                while ($row = mysqli_fetch_assoc($resultUsers)) {
            ?>
                    <div class="user-item">
                        <div class="user-info">
                            <div class="user-name"><?php echo htmlspecialchars($row['username']); ?></div>
                            <div class="user-role">
                                Role: <span class="badge badge-primary"><?php echo htmlspecialchars($row['role']); ?></span>
                                <?php if (isset($row['created_at'])): ?>
                                    • Created: <?php echo date('M j, Y', strtotime($row['created_at'])); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="user-actions">
                            <a href="approve.php?id=<?php echo $row['user_id']; ?>" class="btn btn-success btn-sm">
                                <i class="fas fa-check-circle"></i> Approve
                            </a>
                            <a href="reject.php?id=<?php echo $row['user_id']; ?>" class="btn btn-danger btn-sm">
                                <i class="fas fa-times-circle"></i> Reject
                            </a>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo '<div class="alert alert-info">No pending users at this time.</div>';
            }
            ?>
        </div>
    </div>

    <!-- System Users Section -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">
                <i class="fas fa-users"></i> All System Users
            </h2>
            <p class="text-sm text-secondary">View and manage all registered users in the system</p>
        </div>
        <div class="card-body">
            <?php
            $result3 = mysqli_query($conn, "SELECT * FROM users ORDER BY role, username");
            
            if (mysqli_num_rows($result3) > 0) {
            ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-user"></i> Username</th>
                                <th><i class="fas fa-user-tag"></i> Role</th>
                                <th><i class="fas fa-check-circle"></i> Status</th>
                                <th><i class="fas fa-cog"></i> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_assoc($result3)) {
                                $statusClass = $row['status'] == 'active' ? 'success' : ($row['status'] == 'pending' ? 'warning' : 'danger');
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                                    <td>
                                        <span class="badge badge-primary">
                                            <?php echo htmlspecialchars($row['role']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo $statusClass; ?>">
                                            <?php echo htmlspecialchars($row['status'] ?? 'unknown'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($row['status'] == 'pending'): ?>
                                            <a href="approve.php?id=<?php echo $row['user_id']; ?>" class="btn btn-success btn-sm">
                                                <i class="fas fa-check-circle"></i> Approve
                                            </a>
                                            <a href="reject.php?id=<?php echo $row['user_id']; ?>" class="btn btn-danger btn-sm">
                                                <i class="fas fa-times-circle"></i> Reject
                                            </a>
                                        <?php else: ?>
                                            <span class="text-secondary">No actions</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            <?php
            } else {
                echo '<div class="alert alert-info">No users found in the system.</div>';
            }
            ?>
        </div>
    </div>

</div>

<script>
// Update statistics
document.addEventListener('DOMContentLoaded', function() {
    // Count pending users
    const pendingCount = document.querySelectorAll('.user-item').length;
    document.getElementById('pendingCount').textContent = pendingCount;
    
    // Count active users (this would need server-side calculation)
    // For now, showing a placeholder
    document.getElementById('activeCount').textContent = '12';
    document.getElementById('rejectedCount').textContent = '3';
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>