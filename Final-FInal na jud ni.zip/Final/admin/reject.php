<?php
require_once __DIR__ . '/../config/db_connection.php';

$db = new Database();
$conn = $db->getConnection();

session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = intval($_GET['id']);

// Get user details before updating
$userQuery = mysqli_query($conn, "SELECT username, role FROM users WHERE user_id = $user_id");
$user = mysqli_fetch_assoc($userQuery);

if (!$user) {
    $_SESSION['message'] = 'User not found';
    $_SESSION['message_type'] = 'error';
} else {
    // Update user status
    $result = mysqli_query($conn, "UPDATE users SET status='rejected' WHERE user_id = $user_id");

    if ($result) {
        $_SESSION['message'] = "User {$user['username']} ({$user['role']}) has been rejected successfully.";
        $_SESSION['message_type'] = 'success';
    } else {
        $_SESSION['message'] = 'Error rejecting user: ' . mysqli_error($conn);
        $_SESSION['message_type'] = 'error';
    }
}

header("Location: admin.php");
exit();
?>