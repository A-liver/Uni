<?php
require_once __DIR__ . '/init.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College University</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-dark: #1e40af;
            --secondary-color: #64748b;
            --success-color: #10b981;
            --danger-color: #ef4444;
            --warning-color: #f59e0b;
            --info-color: #0ea5e9;
            --dark-color: #1f2937;
            --light-color: #f8fafc;
            --border-color: #e2e8f0;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --radius: 0.5rem;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --bg-body: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --bg-navbar: rgba(255, 255, 255, 0.95);
            --bg-main: rgba(255, 255, 255, 0.95);
            --text-color: var(--dark-color);
            --text-secondary: var(--secondary-color);
        }

        /* Dark Mode Variables */
        [data-theme="dark"] {
            --primary-color: #3b82f6;
            --primary-dark: #60a5fa;
            --secondary-color: #94a3b8;
            --success-color: #34d399;
            --danger-color: #f87171;
            --warning-color: #fbbf24;
            --info-color: #38bdf8;
            --dark-color: #f1f5f9;
            --light-color: #0f172a;
            --border-color: #334155;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.3);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.4);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.4);
            --bg-body: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
            --bg-navbar: rgba(15, 23, 42, 0.95);
            --bg-main: rgba(15, 23, 42, 0.98);
            --text-color: #f1f5f9;
            --text-secondary: #94a3b8;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg-body);
            min-height: 100vh;
            color: var(--text-color);
            line-height: 1.6;
            transition: var(--transition);
        }

        /* Theme Toggle Button */
        .theme-toggle {
            background: var(--light-color);
            border: 1px solid var(--border-color);
            color: var(--text-color);
            cursor: pointer;
            padding: 0.5rem;
            border-radius: var(--radius);
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            font-size: 1.1rem;
        }

        .theme-toggle:hover {
            transform: scale(1.1);
            box-shadow: var(--shadow-md);
        }

        .theme-toggle .fa-sun {
            display: none;
        }

        [data-theme="dark"] .theme-toggle .fa-sun {
            display: block;
        }

        [data-theme="dark"] .theme-toggle .fa-moon {
            display: none;
        }

        .navbar {
            background: var(--bg-navbar);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow-md);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .logo {
            font-weight: 800;
            font-size: 1.75rem;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            letter-spacing: -0.5px;
        }

        .logo i {
            -webkit-text-fill-color: var(--primary-color);
            font-size: 1.5rem;
        }

        /* Minimal Header */
        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--light-color);
            border-radius: var(--radius);
            border: 1px solid var(--border-color);
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: -280px;
            width: 280px;
            height: 100vh;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            transition: var(--transition);
            z-index: 1001;
            box-shadow: var(--shadow-lg);
            overflow-y: auto;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar-header {
            padding: 2rem 1.5rem;
            border-bottom: 1px solid var(--border-color);
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
        }

        .sidebar-content {
            padding: 1.5rem;
        }

        .sidebar-section {
            margin-bottom: 2rem;
        }

        .sidebar-section-title {
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--secondary-color);
            margin-bottom: 0.75rem;
            letter-spacing: 0.05em;
        }

        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            color: var(--dark-color);
            padding: 0.75rem 1rem;
            text-decoration: none;
            border-radius: var(--radius);
            margin-bottom: 0.25rem;
            transition: var(--transition);
            font-weight: 500;
        }

        .sidebar-link:hover {
            background: var(--light-color);
            color: var(--primary-color);
            transform: translateX(4px);
        }

        .sidebar-link.active {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            box-shadow: var(--shadow-md);
        }

        .sidebar-link.active:hover {
            transform: translateX(4px);
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
        }

        /* Sidebar tooltip for collapsed state */
        .sidebar-link {
            position: relative;
        }

        .sidebar-link::after {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 3px;
            background: var(--primary-color);
            transform: scaleY(0);
            transition: transform 0.3s ease;
        }

        .sidebar-link:hover::after,
        .sidebar-link.active::after {
            transform: scaleY(1);
        }

        /* Sidebar badge for notifications */
        .sidebar-badge {
            margin-left: auto;
            background: var(--danger-color);
            color: white;
            font-size: 0.65rem;
            padding: 0.125rem 0.5rem;
            border-radius: 9999px;
            font-weight: 600;
        }

        /* Pulse animation for attention */
        .main-content {
            margin-left: 0;
            padding: 2rem;
            transition: var(--transition);
            max-width: 1400px;
            margin: 0 auto;
        }

        .main-content.sidebar-active {
            margin-left: 280px;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--border-color);
            transition: var(--transition);
        }

        .card:hover {
            box-shadow: var(--shadow-lg);
            transform: translateY(-2px);
        }

        .card-header {
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 1rem;
            margin-bottom: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-title {
            margin: 0;
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: 0;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1.5rem;
            background: white;
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }

        .table th, .table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .table th {
            background: var(--light-color);
            font-weight: 600;
            color: var(--dark-color);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .table tr:hover {
            background: var(--light-color);
        }

        .form-input {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 2px solid var(--border-color);
            border-radius: var(--radius);
            font-size: 0.875rem;
            transition: var(--transition);
            background: white;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--dark-color);
            font-size: 0.875rem;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: var(--radius);
            cursor: pointer;
            font-size: 0.875rem;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transition: var(--transition);
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            box-shadow: var(--shadow-md);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .btn-secondary {
            background: var(--secondary-color);
            color: white;
        }

        .btn-success {
            background: var(--success-color);
            color: white;
        }

        .btn-danger {
            background: var(--danger-color);
            color: white;
        }

        .btn-outline {
            background: transparent;
            border: 2px solid var(--primary-color);
            color: var(--primary-color);
        }

        .btn-outline:hover {
            background: var(--primary-color);
            color: white;
        }

        .alert {
            padding: 1rem 1.5rem;
            border-radius: var(--radius);
            margin-bottom: 1.5rem;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                transform: translateX(-100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .alert-error {
            background: #fef2f2;
            color: var(--danger-color);
            border-left-color: var(--danger-color);
        }

        .alert-success {
            background: #f0fdf4;
            color: var(--success-color);
            border-left-color: var(--success-color);
        }

        .alert-info {
            background: #f0f9ff;
            color: var(--info-color);
            border-left-color: var(--info-color);
        }

        .alert-warning {
            background: #fffbeb;
            color: var(--warning-color);
            border-left-color: var(--warning-color);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 1.5rem;
            border-radius: 1rem;
            text-align: center;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--border-color);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--primary-dark));
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card.success::before { background: var(--success-color); }
        .stat-card.warning::before { background: var(--warning-color); }
        .stat-card.danger::before { background: var(--danger-color); }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .badge-primary { background: var(--primary-color); color: white; }
        .badge-success { background: var(--success-color); color: white; }
        .badge-warning { background: var(--warning-color); color: white; }
        .badge-danger { background: var(--danger-color); color: white; }
        .badge-info { background: var(--info-color); color: white; }
        .badge-secondary { background: var(--secondary-color); color: white; }

        /* Info Cards - Dark Mode Compatible */
        .info-card {
            padding: 0.75rem;
            border-radius: var(--radius);
            border: 1px solid var(--border-color);
            background: var(--light-color);
        }
        .info-card-primary { border-left: 4px solid var(--primary-color); }
        .info-card-success { border-left: 4px solid var(--success-color); }
        .info-card-info { border-left: 4px solid var(--info-color); }
        .info-card-warning { border-left: 4px solid var(--warning-color); }
        .info-card-danger { border-left: 4px solid var(--danger-color); }
        .info-card-secondary { border-left: 4px solid var(--secondary-color); }
        .info-label {
            font-size: 0.75rem;
            color: var(--text-secondary);
            display: block;
            margin-bottom: 0.25rem;
        }
        .info-value {
            font-weight: 600;
            color: var(--text-color);
        }

        /* Permit Cards */
        .permit-card {
            border: 2px solid var(--border-color);
            border-radius: var(--radius);
            padding: 1.5rem;
            background: var(--bg-main);
            transition: var(--transition);
        }
        .permit-available {
            border-color: var(--success-color);
            background: rgba(16, 185, 129, 0.1);
        }
        .permit-locked {
            border-color: var(--border-color);
            background: var(--light-color);
            opacity: 0.8;
        }

        /* Text color utilities */
        .text-success { color: var(--success-color); }
        .text-danger { color: var(--danger-color); }
        .text-warning { color: var(--warning-color); }
        .text-info { color: var(--info-color); }

        /* Stat Highlights */
        .stat-highlight {
            text-align: center;
            padding: 1rem;
            border-radius: var(--radius);
            background: var(--light-color);
            border: 1px solid var(--border-color);
        }
        .stat-highlight-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-color);
        }
        .stat-highlight-label {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }
        .stat-highlight-success { border-left: 4px solid var(--success-color); }
        .stat-highlight-primary { border-left: 4px solid var(--primary-color); }
        .stat-highlight-warning { border-left: 4px solid var(--warning-color); }
        .stat-highlight-danger { border-left: 4px solid var(--danger-color); }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 2rem;
            background: var(--light-color);
            border-radius: var(--radius);
            border: 1px solid var(--border-color);
        }

        /* Progress Bar */
        .progress-bar {
            width: 100%;
            background: var(--border-color);
            border-radius: var(--radius);
            height: 0.5rem;
            overflow: hidden;
        }
        .progress-bar-fill {
            height: 100%;
            background: var(--success-color);
            border-radius: var(--radius);
            transition: width 0.3s ease;
        }

        .fade-in {
            animation: fadeIn 0.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .grid {
            display: grid;
            gap: 1.5rem;
        }

        .grid-cols-2 { grid-template-columns: repeat(2, 1fr); }
        .grid-cols-3 { grid-template-columns: repeat(3, 1fr); }
        .grid-cols-4 { grid-template-columns: repeat(4, 1fr); }
        .grid-cols-5 { grid-template-columns: repeat(5, 1fr); }

        .flex {
            display: flex;
            align-items: center;
        }

        .flex-1 { flex: 1; }
        .justify-center { justify-content: center; }
        .justify-between { justify-content: space-between; }
        .items-center { align-items: center; }
        .items-end { align-items: flex-end; }

        .gap-2 { gap: 0.5rem; }
        .gap-4 { gap: 1rem; }

        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-secondary { color: var(--text-secondary); }
        .text-sm { font-size: 0.875rem; }
        .text-success { color: var(--success-color); }
        .text-danger { color: var(--danger-color); }
        .text-warning { color: var(--warning-color); }
        .text-info { color: var(--info-color); }
        .text-primary { color: var(--primary-color); }

        .font-semibold { font-weight: 600; }
        .font-bold { font-weight: 700; }

        .table-responsive {
            overflow-x: auto;
        }

        @media (max-width: 768px) {
            .navbar {
                padding: 1rem;
            }

            .main-content {
                padding: 1rem;
            }

            .main-content.sidebar-active {
                margin-left: 0;
            }

            .sidebar {
                width: 100%;
                left: -100%;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .grid-cols-2,
            .grid-cols-3,
            .grid-cols-4,
            .grid-cols-5 {
                grid-template-columns: 1fr;
            }
        }

        @media print {
            body {
                background: white;
            }

            .navbar,
            .sidebar {
                display: none;
            }

            .main-content {
                margin: 0;
                padding: 0;
            }

            .card {
                box-shadow: none;
                border: 1px solid #ccc;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <i class="fas fa-university"></i>
            College University
        </div>
        <div class="nav-right">
            <button class="theme-toggle" id="theme-toggle" onclick="toggleTheme()" aria-label="Toggle theme" title="Toggle Dark/Light Mode">
                <i class="fas fa-moon"></i>
                <i class="fas fa-sun"></i>
            </button>
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo isset($_SESSION['role']) ? strtoupper(substr($_SESSION['role'], 0, 1)) : 'U'; ?>
                </div>
                <div>
                    <div style="font-weight: 600; font-size: 0.875rem;">
                        <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'User'; ?>
                    </div>
                    <div style="font-size: 0.75rem; color: var(--secondary-color);">
                        <?php echo isset($_SESSION['role']) ? ucfirst($_SESSION['role']) : 'Guest'; ?>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <?php include_once __DIR__ . '/sidebar.php'; ?>

    <main class="main-content" id="main-content">
    <script>
        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Theme Toggle Functionality
        function toggleTheme() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        }

        // Load saved theme on page load
        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme) {
                document.documentElement.setAttribute('data-theme', savedTheme);
            }
        });
    </script>

<!-- MAIN CONTENT -->
<div class="main-content">