<?php

// Start session safely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Load database config
require_once __DIR__ . '/../config/db_connection.php';

// Create DB connection globally
$db = new Database();
$conn = $db->getConnection();