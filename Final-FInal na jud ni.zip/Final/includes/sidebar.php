<?php
// sidebar.php - Role-based navigation sidebar
if (!isset($_SESSION['role'])) return;

$role = $_SESSION['role'];
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// Define navigation items for each role
$nav_items = [
    'admin' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => '../admin/admin.php'],
    ],
    'dean' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => '../dean/dean_dashboard.php'],
        ['icon' => 'fa-users', 'label' => 'Students', 'link' => '../dean/students.php'],
        ['icon' => 'fa-book', 'label' => 'Courses', 'link' => '../dean/courses.php'],
        ['icon' => 'fa-book-open', 'label' => 'Subjects', 'link' => '../dean/subjects.php'],
        ['icon' => 'fa-user-plus', 'label' => 'Enrollment', 'link' => '../dean/enrollment.php'],
        ['icon' => 'fa-chalkboard-teacher', 'label' => 'Teachers', 'link' => '../dean/teacher_subject.php'],
        ['icon' => 'fa-calendar-alt', 'label' => 'Schedule', 'link' => '../dean/schedule.php'],
    ],
    'cashier' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => '../cashier/cashier_dashboard.php'],
        ['icon' => 'fa-chart-line', 'label' => 'Collection Report', 'link' => '../cashier/collection_report.php'],
    ],
    'finance' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => '../finance/finance_dashboard.php'],
        ['icon' => 'fa-user-graduate', 'label' => 'Student Billing', 'link' => '../finance/student_billing.php'],
        ['icon' => 'fa-file-invoice', 'label' => 'Reports', 'link' => '../finance/reports.php'],
        ['icon' => 'fa-chart-pie', 'label' => 'Analytics', 'link' => '../finance/analytics.php'],
    ],
    'teacher' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => '../teacher/teacher_dashboard.php'],
    ],
    'student' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => '../student/student_dashboard.php'],
        ['icon' => 'fa-list', 'label' => 'My Subjects', 'link' => '../student/student_subjects.php'],
        ['icon' => 'fa-book-medical', 'label' => 'Add Subjects', 'link' => '../student/add_subjects.php'],
        ['icon' => 'fa-chart-line', 'label' => 'My Grades', 'link' => '../student/grade.php'],
        ['icon' => 'fa-user', 'label' => 'My Profile', 'link' => '../student/student.php'],
        ['icon' => 'fa-file-alt', 'label' => 'Exam Permit', 'link' => '../student/exam_permit.php'],
    ],
    'records' => [
        ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard', 'link' => '../records/records_dashboard.php'],
        ],
];

$items = $nav_items[$role] ?? [];
?>

<!-- Sidebar Navigation -->
<aside class="app-sidebar" id="app-sidebar">
    <!-- Collapse/Expand Button (Desktop) -->
    <button class="sidebar-collapse-btn" id="sidebar-collapse-btn" onclick="toggleSidebarCollapse()" aria-label="Collapse sidebar" title="Collapse Menu">
        <i class="fas fa-chevron-left collapse-icon"></i>
        <i class="fas fa-chevron-right expand-icon" style="display: none;"></i>
    </button>
    
    <!-- Mobile Toggle Button -->
    <button class="sidebar-toggle" id="sidebar-toggle" onclick="toggleAppSidebar()" aria-label="Toggle menu">
        <div class="hamburger-lines">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </button>
    
    <div class="sidebar-nav-section">
        <nav class="sidebar-nav">
            <?php foreach ($items as $item): 
                $is_active = strpos($_SERVER['PHP_SELF'], $item['link']) !== false;
            ?>
                <a href="<?php echo $item['link']; ?>" class="nav-link <?php echo $is_active ? 'active' : ''; ?>" title="<?php echo $item['label']; ?>">
                    <span class="nav-icon">
                        <i class="fas <?php echo $item['icon']; ?>"></i>
                    </span>
                    <span class="nav-label"><?php echo $item['label']; ?></span>
                    <?php if ($is_active): ?>
                        <span class="active-dot"></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </nav>
    </div>
    
    <!-- System Section -->
    <div class="sidebar-nav-section system-section">
        <nav class="sidebar-nav">
            <a href="#" onclick="window.print(); return false;" class="nav-link" title="Print Page">
                <span class="nav-icon"><i class="fas fa-print"></i></span>
                <span class="nav-label">Print Page</span>
            </a>
            <a href="../auth/logout.php" class="nav-link logout-link" title="Logout">
                <span class="nav-icon"><i class="fas fa-sign-out-alt"></i></span>
                <span class="nav-label">Logout</span>
            </a>
        </nav>
    </div>
</aside>

<style>
/* Sidebar Styles */
.app-sidebar {
    position: fixed;
    top: 70px;
    left: 0;
    width: 260px;
    height: calc(100vh - 70px);
    background: var(--bg-navbar);
    backdrop-filter: blur(10px);
    border-right: 1px solid var(--border-color);
    z-index: 999;
    overflow-y: auto;
    padding: 0.5rem 0;
    box-shadow: 4px 0 15px rgba(0, 0, 0, 0.1);
    transition: var(--transition);
}

/* Collapse/Expand Button (Desktop) */
.sidebar-collapse-btn {
    display: none;
    background: transparent;
    border: none;
    color: var(--secondary-color);
    cursor: pointer;
    padding: 0.5rem;
    border-radius: var(--radius);
    transition: var(--transition);
    margin: 0.5rem 1rem;
    width: calc(100% - 2rem);
    height: 36px;
    font-size: 1rem;
    align-items: center;
    justify-content: flex-end;
}

.sidebar-collapse-btn:hover {
    background: var(--light-color);
    color: var(--primary-color);
}

/* Toggle Button in Sidebar (Mobile) */
.sidebar-toggle {
    display: none;
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    border: none;
    color: white;
    cursor: pointer;
    padding: 0.75rem;
    border-radius: var(--radius);
    transition: var(--transition);
    box-shadow: var(--shadow-md);
    margin: 0.5rem 1rem 1rem;
    width: calc(100% - 2rem);
    height: 44px;
    position: relative;
    overflow: hidden;
}

.sidebar-toggle:hover {
    transform: scale(1.02);
    box-shadow: var(--shadow-lg);
}

.sidebar-toggle .hamburger-lines {
    display: flex;
    flex-direction: column;
    gap: 5px;
    width: 20px;
    height: 16px;
    justify-content: center;
    margin: 0 auto;
}

.sidebar-toggle .hamburger-lines span {
    display: block;
    height: 2px;
    width: 100%;
    background: white;
    border-radius: 2px;
    transition: var(--transition);
    transform-origin: center;
}

/* Hamburger to X animation */
.sidebar-toggle.active .hamburger-lines span:nth-child(1) {
    transform: rotate(45deg) translate(5px, 5px);
}

.sidebar-toggle.active .hamburger-lines span:nth-child(2) {
    opacity: 0;
}

.sidebar-toggle.active .hamburger-lines span:nth-child(3) {
    transform: rotate(-45deg) translate(5px, -5px);
}

/* COLLAPSED SIDEBAR STATE (Desktop) */
@media (min-width: 1025px) {
    .sidebar-collapse-btn {
        display: flex;
    }
    
    /* Collapsed state */
    .app-sidebar.collapsed {
        width: 70px;
        overflow: visible;
    }
    
    .app-sidebar.collapsed .sidebar-collapse-btn {
        justify-content: center;
    }
    
    .app-sidebar.collapsed .collapse-icon {
        display: none;
    }
    
    .app-sidebar.collapsed .expand-icon {
        display: block !important;
    }
    
    .app-sidebar.collapsed .nav-label {
        display: none;
    }
    
    .app-sidebar.collapsed .nav-link {
        justify-content: center;
        padding: 0.875rem 0.5rem;
    }
    
    .app-sidebar.collapsed .nav-icon {
        margin: 0;
    }
    
    .app-sidebar.collapsed .active-dot {
        right: 0.5rem;
    }
    
    /* Tooltip on hover for collapsed sidebar */
    .app-sidebar.collapsed .nav-link:hover::after {
        content: attr(title);
        position: absolute;
        left: 75px;
        top: 50%;
        transform: translateY(-50%);
        background: var(--dark-color);
        color: white;
        padding: 0.5rem 0.75rem;
        border-radius: var(--radius);
        font-size: 0.875rem;
        white-space: nowrap;
        z-index: 10000;
        box-shadow: var(--shadow-md);
        font-weight: 500;
    }
    
    .app-sidebar.collapsed .nav-link:hover::before {
        content: '';
        position: absolute;
        left: 65px;
        top: 50%;
        transform: translateY(-50%);
        border: 6px solid transparent;
        border-right-color: var(--dark-color);
        z-index: 10000;
    }
    
    /* Adjust main content when sidebar is collapsed */
    .app-sidebar.collapsed ~ .main-content {
        margin-left: 70px !important;
    }
}

.sidebar-nav-section {
    padding: 0 1rem 1rem;
    border-bottom: 1px solid var(--border-color);
    margin-bottom: 1rem;
}

.sidebar-nav-section:last-of-type {
    border-bottom: none;
}

.sidebar-nav {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.nav-link {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.875rem 1rem;
    color: var(--dark-color);
    text-decoration: none;
    border-radius: var(--radius);
    transition: all 0.2s ease;
    position: relative;
    font-weight: 500;
    font-size: 0.9rem;
}

.nav-link:hover {
    background: var(--light-color);
    color: var(--primary-color);
    transform: translateX(4px);
}

.nav-link.active {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    color: white;
    box-shadow: var(--shadow-md);
}

.nav-link.active:hover {
    transform: translateX(4px);
}

.nav-icon {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius);
    background: rgba(37, 99, 235, 0.1);
    transition: all 0.2s ease;
}

.nav-link.active .nav-icon {
    background: rgba(255, 255, 255, 0.2);
}

.nav-link:hover .nav-icon {
    background: var(--primary-color);
    color: white;
}

.active-dot {
    position: absolute;
    right: 1rem;
    width: 8px;
    height: 8px;
    background: white;
    border-radius: 50%;
    animation: pulse-dot 1.5s ease-in-out infinite;
}

@keyframes pulse-dot {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.5; transform: scale(1.2); }
}

/* System Section */
.system-section {
    margin-top: auto;
}

.logout-link:hover {
    background: rgba(239, 68, 68, 0.1) !important;
    color: var(--danger-color) !important;
}

.logout-link:hover .nav-icon {
    background: var(--danger-color) !important;
    color: white !important;
}

/* Mobile: Show toggle button */
@media (max-width: 1024px) {
    .app-sidebar {
        transform: translateX(-100%);
        transition: transform 0.3s ease;
        top: 60px;
        height: calc(100vh - 60px);
        width: 280px;
    }
    
    .app-sidebar.active {
        transform: translateX(0);
    }
    
    .sidebar-toggle {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .main-content {
        margin-left: 0 !important;
    }
}

/* Desktop: Always show sidebar */
@media (min-width: 1025px) {
    .app-sidebar {
        transform: translateX(0) !important;
    }
    
    .main-content {
        margin-left: 260px;
    }
}
</style>

<script>
// Desktop: Collapse/Expand sidebar
function toggleSidebarCollapse() {
    const sidebar = document.getElementById('app-sidebar');
    const btn = document.getElementById('sidebar-collapse-btn');
    const isCollapsed = sidebar.classList.toggle('collapsed');
    
    // Update button title
    btn.setAttribute('title', isCollapsed ? 'Expand Menu' : 'Collapse Menu');
    btn.setAttribute('aria-label', isCollapsed ? 'Expand sidebar' : 'Collapse sidebar');
    
    // Save preference to localStorage
    localStorage.setItem('sidebarCollapsed', isCollapsed ? 'true' : 'false');
}

// Mobile sidebar toggle
function toggleAppSidebar() {
    const sidebar = document.getElementById('app-sidebar');
    const toggle = document.getElementById('sidebar-toggle');
    
    sidebar.classList.toggle('active');
    toggle.classList.toggle('active');
    
    // Update aria-label
    const isOpen = sidebar.classList.contains('active');
    toggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
}

// Close sidebar when clicking outside on mobile
document.addEventListener('click', function(event) {
    const sidebar = document.getElementById('app-sidebar');
    const toggle = document.getElementById('sidebar-toggle');
    
    if (window.innerWidth <= 1024 && 
        sidebar.classList.contains('active') &&
        !sidebar.contains(event.target) &&
        !toggle.contains(event.target)) {
        toggleAppSidebar();
    }
});

// ESC key to close
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const sidebar = document.getElementById('app-sidebar');
        if (sidebar.classList.contains('active')) {
            toggleAppSidebar();
        }
    }
});

// Restore sidebar state on page load
document.addEventListener('DOMContentLoaded', function() {
    // Only apply on desktop
    if (window.innerWidth >= 1025) {
        const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
        const sidebar = document.getElementById('app-sidebar');
        const btn = document.getElementById('sidebar-collapse-btn');
        
        if (isCollapsed && sidebar) {
            sidebar.classList.add('collapsed');
            if (btn) {
                btn.setAttribute('title', 'Expand Menu');
                btn.setAttribute('aria-label', 'Expand sidebar');
            }
        }
    }
});

// Handle window resize
document.addEventListener('resize', function() {
    const sidebar = document.getElementById('app-sidebar');
    if (window.innerWidth <= 1024) {
        // Remove collapsed class on mobile
        sidebar.classList.remove('collapsed');
    }
});
</script>
